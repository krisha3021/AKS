# D. Database schema · E. API contract · F. UX flows

## D. Schema

Migrations are in `backend/migrations/versions/`:
- `af57926117fe_initial_schema.py`: every table below
- `b1c2d3e4f5a6_search_index.py`: the SQLite FTS5 table `jobs_fts`. It does nothing on Postgres.

`tests/test_migrations.py` checks that the migrated schema matches the SQLAlchemy models.

| Table | Purpose | Key columns |
|---|---|---|
| `users` | Accounts | `email` (unique), argon2 `password_hash`, `ai_consent_at` (null means no consent), `retention_days` |
| `auth_sessions` | Server-side sessions | `token_hash` (SHA-256 of the cookie token), `expires_at` |
| `documents` | Uploaded files (CV, job lists) | `storage_key` (AES-GCM encrypted file on disk), `sha256`, `text_encrypted` (extracted CV text, AES-GCM) |
| `profiles` | Structured profile | `fields` (JSON list of `{kind, value, evidence[{document_id,page,start,end,quote}], confidence, origin, flags, confirmed, rejected}`), `preferences`, `version` |
| `jobs` | One normalised vacancy per user | Every field in spec section 6: `posted_date` (source only), `first_seen_at`, `last_seen_at`, `last_checked_at`, `last_verified_at`, `deadline_at` (UTC) + `deadline_tz` + `deadline_text` + `deadline_kind` (closing / review_begins / priority / open_until_filled / unknown), `visa_sponsorship` (stated_yes / stated_no / not_stated), `status`, `consecutive_missing`, `missing_since`, `content_hash`, `is_synthetic` |
| `job_sources` | Provenance: one row per sighting. Merges move these rows and never delete them | `source_key`, `source_url`, `source_job_id`, `import_id`, `import_row`, `raw` (original values, unmodified) |
| `job_changes` | Change history | `field`, `old_value`, `new_value`, `material` |
| `imports` | Spreadsheet imports | `mapping`, counts, `errors` (row number, raw values, messages) |
| `match_results` | Cached scores | `score`, `components`, `explanation` (includes `matcher_version`), `deal_breaker`, `profile_version` |
| `applications` | Kanban tracking | `stage`, `notes`, `applied_at`, `reminder_at`, `required_documents`, `contacts`, `history` |
| `drafts` | Application text | `content`, `missing_info`, `approved_at`, `approved_sha256` (approved drafts are frozen) |
| `sources` | Connector instances the user has enabled | `connector_key`, `config`, `interval_minutes`, health fields, `etag`/`last_modified` |
| `tasks` | Durable queue | `dedupe_key` (unique, so enqueueing twice is harmless), `status` pending/running/done/dead, `attempts`, `run_at` |
| `notifications` | Alerts | `kind` new_match / deadline_changed / closed / requirements_changed / score_changed |
| `audit_log` | Security audit trail | `action`, `target`, `meta`. Holds counts only, never CV text. Kept after account deletion (user id only) |

Tenant isolation: every user-owned table has a `user_id` column, and every query filters on the signed-in user's id. Jobs are stored per user, so a vacancy found by two users exists as two rows.

## E. API contract

The machine-readable contract is in [`E-openapi.json`](E-openapi.json), exported from the running app. The typed models are the Pydantic classes in `backend/app/routers/*.py` and the TypeScript interfaces in `frontend/src/types.ts`.

Conventions:
- Sessions use an HttpOnly, SameSite=Strict cookie (`cr_session`).
- Every POST/PUT/PATCH/DELETE must send the header `x-cr-csrf: 1`, or it gets a 403.
- Errors come back as `{"detail": "..."}`. Status codes: 401 (not signed in), 403 (CSRF or signature), 404 (not found, or not yours; the two are deliberately indistinguishable), 409 (frozen draft), 413/415 (upload rejected), 422 (validation), 429 (rate limit or refresh throttle).

| Area | Endpoints |
|---|---|
| Auth & privacy | `POST /api/auth/register`, `login`, `logout`, `consent`; `GET /api/auth/me`, `export`; `DELETE /api/auth/account` |
| Profile | `GET /api/profile`, `POST /api/profile/cv`, `PATCH /api/profile/fields/{id}`, `POST /api/profile/fields`, `PUT /api/profile/preferences` |
| Documents | `POST /api/documents/{id}/link` (signed link, valid 5 min), `GET .../download`, `GET .../text`, `DELETE` |
| Import | `POST /api/imports/preview` (multipart), `POST /api/imports/{document_id}/commit` `{mapping}`, `GET /api/imports[/{id}]` |
| Jobs | `GET /api/jobs` (filters: q, scope, country, city, arrangement, employer, status[], deadline_before/after, seen_after, posted_after, min_score, visa_stated, salary_min, employment_type, rank, discipline, academic, include_closed, sort, offset, limit), `GET /api/jobs/{id}` (match, explanation, provenance, changes), `POST /api/jobs` (add a vacancy URL as a lead), `POST /api/jobs/{id}/refresh`, `DELETE`, `GET /api/jobs/export/csv` |
| Tracking | `GET/POST /api/applications`, `PATCH/DELETE /api/applications/{id}` |
| Drafts | `GET/POST /api/drafts`, `PUT /api/drafts/{id}`, `POST /api/drafts/{id}/approve`. **No endpoint sends or submits anything** (enforced by a test) |
| Sources | `GET /api/sources/capabilities` (the source-access matrix), `GET/POST /api/sources`, `PATCH/DELETE /api/sources/{id}`, `POST /api/sources/{id}/refresh`, `GET /api/sources/queue` |
| Live | `GET /api/events` (Server-Sent Events: `hello`, `jobs_changed`, `source_health`, `notification`), `GET /api/notifications`, `POST /api/notifications/read` |
| Ops | `GET /api/health/live`, `GET /api/health/ready`, `GET /api/metrics` |

## F. UX flows and components

Code: `frontend/src/`. The app shell (`App.tsx`) has hash routes, a live-connection indicator, a notification bell and toasts.

1. **Onboarding:** register, then Profile & CV. Upload a CV (PDF/DOCX). Each extracted fact shows its evidence quote, page, confidence and any flags; the user can Confirm, Edit or mark it "Not correct". The page also shows an experience summary with overlapping periods merged and ambiguous dates flagged, and the preferences form.
2. **Import wizard** (`pages/Import.tsx`): upload, then map columns (dropdowns with suggested mappings and a 5-row preview), then commit. The result shows new / merged / failed counts and a table of row errors with the original values.
3. **Jobs** (`pages/Jobs.tsx`): All / National / International tabs, an Academic-mode toggle (adds a rank filter), search, sort and the full filter panel. Each card shows employer and title, location, score with a summary, source, last verification time, the deadline in the source's own wording, status, a DEMO badge where applicable, stale warnings, and "Open original listing".
4. **Evidence drawer:** deal-breakers, why it matches, the score breakdown with the "not a probability" note, each requirement with the vacancy quote and CV quote (supported / not supported / unknown), visa status, required documents, provenance and change history.
5. **Sources** (`pages/Sources.tsx`): health per source (healthy / failing / not run, last checked, last success, stale warning, errors labelled temporary vs. config), add-source form, and the source-access matrix with unsupported sources marked "manual import / link-out only".
6. **Applications** (`pages/Applications.tsx`): an 8-column Kanban (drag-and-drop plus a stage dropdown for keyboard users), notes, reminder, required-documents checklist, contacts, and draft generation with edit → approve (freeze) → copy.
7. **Settings:** AI-consent toggle with an explanation, JSON data export, sign-out, and delete account (typed confirmation).

Every view has loading, empty and error states, and stale or blocked-source warnings. Verified in the browser at 375 px width with no horizontal scroll.
