# A. Competitive research and source-access matrix

Access date for every URL below: **2026-10-13** unless stated otherwise.
Method: web search plus direct fetches of official pages, `robots.txt` files and
API docs. Where an official page refused automated access (HTTP 403) this is
recorded; the claim is then marked **unverified**, not guessed.

Legend: **V** = verified from an official page/doc fetched today ·
**C** = vendor claim (official marketing copy, not independently tested) ·
**3P** = third-party review only (often conflicting) · **?** = unknown / not verified.

## A1. Comparable products

| Capability | Jobright | Teal | Simplify | Jobscan |
|---|---|---|---|---|
| CV parsing | ? (not on homepage) | 3P | C (one profile reused) | 3P |
| Personalised discovery | C "Personalized AI Job Matches" | ✗ (tracker, not a job source) | C "matched to relevant roles" | ✗ |
| Academic-role support | ? not claimed | ✗ | ? | ✗ |
| Geographic coverage | ? (US default in search form) | n/a | ? | n/a |
| Explainable matching | 3P (score + keywords) | 3P (keyword match, Teal+) | ? | 3P (match rate + missing keywords) |
| Freshness verification | C "no fake listings" | ✗ | ? | ✗ |
| Excel/CSV import | ? | ? | ? | ? |
| Application tracking | C (footer "AI Job Tracker") | 3P core feature | C "Track every application" | 3P |
| Alerts | C "early alerts" | ? | ? | ✗ |
| Pricing | 3P conflicting ($29.99–$39.99/mo) | 3P conflicting; official page 403 | 3P ($39.99/mo Simplify+) | 3P ($49.95/mo); official page redirects to app login |
| Public API/feed | none found | none found | none found | none found |
| Privacy/retention controls | ? | ? | ? | ? |

**No pricing is listed as verified.** Every official pricing page was either
blocked (403) or behind a login, and the third-party figures disagree.

Sources:
- Jobright homepage (C) — https://jobright.ai/
- Simplify homepage (C) — https://simplify.jobs/
- Teal pricing (403) — https://www.tealhq.com/pricing ; 3P: https://www.loopcv.pro/directory/teal/
- Jobscan pricing (redirect to app) — https://www.jobscan.co/pricing ; 3P: https://www.loopcv.pro/directory/jobscan/
- Jobright 3P pricing: https://resumehog.com/blog/posts/jobright-ai-review-2026-is-this-job-search-copilot-worth-it.html , https://scoutify.com/blog/jobright-review
- Simplify 3P pricing: https://jobright.ai/blog/simplify-copilot-review-2026-features-pricing-and-top-alternatives/

### Unmet needs CareerRadar targets
1. **Academic mode.** None of the four CV-matching tools claims academic-rank or
   discipline-aware matching. The academic boards (below) have discovery but no CV matching.
2. **Provenance and freshness.** No product exposes *when* a listing was last
   verified or *where* each field came from.
3. **Spreadsheet import as leads.** No product verifiably imports a user's own CSV/XLSX
   of vacancies and tracks their verification status.
4. **Requirement-level evidence.** Existing tools show keyword overlap, not
   "requirement → CV evidence / missing / unknown".
5. **India + Gulf + international in one place**, with explicit "unsupported source"
   labelling instead of silent gaps.

## A2. Source-access matrix

| Source | Official API | Agreement needed | RSS/Atom | Automated retrieval permitted? | Plan in CareerRadar | Evidence |
|---|---|---|---|---|---|---|
| **Greenhouse** (employer boards) | **V** Job Board API, GET public, no auth | No for GET | — | **V** "publicly available, authentication not required for GET" | **Phase 2 connector** (per employer board token) | https://docs.greenhouse.io/job-board.html |
| **Lever** (employer boards) | **V** Postings API `api.lever.co/v0/postings/{site}` | No for GET | — | **V** published postings are public | **Phase 2 connector** | https://github.com/lever/postings-api |
| **Adzuna** (aggregator, incl. India) | **V** REST API, `app_id`+`app_key` | Free registration + ToS | — | Via API under ToS | **Phase 2 connector** (disabled until user adds keys). India `in` support is **3P only** — verify with key | https://developer.adzuna.com/overview ; 3P country list: https://github.com/folathecoder/adzuna-job-search-mcp |
| **HigherEdJobs** | none found | ? | **V** category feeds `/rss/categoryFeed.cfm?catID=N` | robots.txt does not block `/rss/`; page says "subscribe … using any RSS reader". Redistribution terms **unverified** (ToU page empty when fetched) | Connector built, **off by default**; personal use only until ToU reviewed | https://www.higheredjobs.com/rss/ , https://www.higheredjobs.com/robots.txt |
| **jobs.ac.uk** | none found | ? | **V** per-subject feed pages exist; exact XML URLs not retrieved (feed pages 404 to our fetcher) | ? | Generic RSS connector; user pastes the feed URL | https://www.jobs.ac.uk/feeds/subject-areas/computer-sciences (search result) |
| **Nature Careers** | none found | ? | Feed exists (`/naturecareers/jobsrss/`) | **No — robots.txt `Disallow: /naturecareers/jobsrss/`** | **Manual import / link-out only** | https://www.nature.com/robots.txt |
| **EURAXESS** | none found (only 3P scrapers) | ? | none found | robots.txt `Disallow: /jobs/*` | **Manual import / link-out only** | https://euraxess.ec.europa.eu/robots.txt , https://euraxess.ec.europa.eu/jobs/search |
| **AcademicJobsOnline** | none found | ? | none found | robots.txt Crawl-delay 5; job pages not disallowed; ToU not found | Single-URL verification only (user-supplied vacancy URL), throttled | https://academicjobsonline.org/robots.txt |
| **Academic Positions** | none found | ? | none found | robots.txt `Allow: /`, `ai-train=no`; site returns 403 to our fetcher | Manual import / link-out | https://academicpositions.com/robots.txt |
| **Naukri** | none public | Commercial | none found | **No** — ToU lists "automated means to crawl and/or scrape" as prohibited (search snippet; page 403 to fetcher) | **Manual import / link-out only** | https://www.naukri.com/termsconditions |
| **Naukrigulf** | none public | Commercial | none found | **No** — ToU prohibits bots/crawlers/scraping (search snippet; page timed out) | **Manual import / link-out only** | https://naukrigulf.com/terms-and-conditions |
| **Bayt** | employer posting API only (3P) | Commercial | none found | ? (ToU 403) | **Manual import / link-out only** | https://www.bayt.com/en/terms-of-use/ |
| **GulfTalent** | none found | ? | none found | ? (ToU 403) | **Manual import / link-out only** | https://www.gulftalent.com/terms-of-use |
| **LinkedIn** | Job *Posting* API, partners only | **Talent Solutions partnership** | none | No public job-search read API found | **Manual import / link-out only** | https://developer.linkedin.com/docs/v1/job-posting/linkedin-job-credits-partner-program |
| **University / employer career pages** | varies | — | often (e.g. `jobs.<uni>.ac.uk/RSS`) | per site | Generic RSS + schema.org `JobPosting` JSON-LD verification of user-supplied URLs | e.g. https://jobs.brighton.ac.uk/RSS |

"robots.txt allows it" is **not** treated as authorization on its own. Connectors
only run against sources with an official API/feed **and** a user who has enabled them.

## A3. Limitations of this research
- Official ToU pages for Naukri, Naukrigulf, Bayt, GulfTalent, Teal and HigherEdJobs
  could not be fetched automatically (403 / timeout / empty). Re-read them manually
  before enabling anything beyond manual import.
- No vendor product was used hands-on. All capability claims are from marketing
  pages or reviews, and are labelled that way.
- The Adzuna country list (incl. India) comes from third-party code. Check it against
  the live API once a key exists.
