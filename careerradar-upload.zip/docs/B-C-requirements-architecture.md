# B. Requirements & assumptions · C. Architecture & flows

## B1. Assumptions
1. **Single-machine, local-first MVP.** Docker, PostgreSQL and Redis are not installed on the
   dev machine, so the MVP runs on **SQLite (WAL + FTS5)** with a **database-backed task queue**.
   The Postgres + pgvector + Redis deployment is provided as `docker-compose.yml` and marked
   **untested** until Docker is available. All storage access goes through SQLAlchemy, so the
   switch is a config change plus a migration run.
2. **Python 3.12** (uv-managed, project-local), **Node 24** for the frontend.
3. **Claude API** is used only for CV field extraction and match-explanation wording, only
   after explicit per-user consent, and always behind schema validation. A deterministic
   rule-based extractor is the default and the fallback.
4. "Real-time" means: records are pushed to the dashboard over **SSE** as soon as they are
   processed. Upstream sources refresh on their own schedules (shown per source).
5. Only sources marked "connector" in `A-research.md` are fetched automatically. Everything else
   is manual import plus "Open original listing".
6. Synthetic demo data lives in `backend/app/fixtures/demo_*` and every record carries
   `is_synthetic = true`, shown as a **DEMO** badge in the UI.

## B2. MVP requirements (Phase 1 acceptance)
| # | Requirement | Verified by |
|---|---|---|
| R1 | Register/login; every query scoped by `user_id` | `test_tenant_isolation.py` |
| R2 | Upload CV (PDF/DOCX ≤ 10 MB, magic-byte check); extract profile with evidence + confidence; user edits | `test_cv_*` |
| R3 | CSV `scope,title,organisation,location,url` imports unchanged; aliases mapped; row-level errors; valid rows kept | `test_import_*` |
| R4 | Imported rows → status `imported_unverified`, never `open` | `test_import_status` |
| R5 | Duplicate merge keeps every source reference | `test_dedup_*` |
| R6 | Matching: hard constraints separate from preferences; requirement → supported / not supported / unknown, with evidence; mandatory mismatch caps score and is flagged | `test_matching_*` |
| R7 | Missing visa info stays `unknown` (never `false`) | `test_matching_visa_unknown` |
| R8 | Search + filters; saved jobs; application Kanban states | `test_search_*`, `test_applications_*` |
| R9 | CSV export neutralises formula injection | `test_export_injection` |
| R10 | Account deletion removes files + rows | `test_delete_account` |
| R11 | No external submission endpoint exists; drafts require explicit confirm and are never sent by the app | `test_no_submission` |

Phase 2 adds: connectors (Greenhouse, Lever, generic RSS/Atom, JSON-LD vacancy-URL verifier,
Adzuna with user key, HigherEdJobs off by default), scheduler, change detection, SSE, alerts.

## C1. Architecture

```
 Browser (Vite + React + TS + Tailwind)
   │  REST (JSON)   ▲ SSE /api/events
   ▼                │
 FastAPI app ───────┴──────────────────────────────────────────────┐
   ├─ auth        (argon2 passwords, HttpOnly session cookie)     │
   ├─ profile     (CV upload → extractor → evidence + confidence) │
   ├─ imports     (CSV/XLSX → mapping → rows → leads)             │
   ├─ jobs        (normalise, dedupe, provenance, search)         │
   ├─ matching    (filters → BM25/FTS5 → rules → score+explain)   │
   ├─ applications(Kanban, notes, reminders, drafts — no sending) │
   ├─ sources     (connector registry, health, schedules)         │
   └─ events      (SSE broadcaster)                               │
                                                                  │
 Worker loop (same codebase, separate process or in-process)       │
   tasks table: pending → running → done | retry(backoff+jitter) | dead
   discover → fetch → parse → normalize → dedupe → verify → rerank → notify
                                                                  │
 SQLite (dev) / PostgreSQL+pgvector (prod)   private file store (local dir / S3)
```

**Why Vite + React instead of Next.js:** the backend is FastAPI, so server rendering in
Next.js would be a second server with no SEO need (everything is behind login). A static SPA
served by FastAPI is one process to run and secure.

**Why a DB-backed queue instead of Celery + Redis for the MVP:** it is durable, idempotent
(unique `dedupe_key` per task) and needs no extra service. The `TaskQueue` interface can be
backed by Celery later without changing callers.

**Embeddings:** Phase 1 ranks with FTS5 BM25 plus deterministic requirement rules. Semantic
similarity sits behind an `Embedder` interface (Phase 3: local model or API, pgvector in prod)
and is never allowed to override a confirmed mandatory mismatch.

## C2. Connector interface
```python
class Connector(Protocol):
    key: str; capability: SourceCapability   # api|rss|jsonld|manual, interval, limits
    def discover(self, cfg) -> list[Lead]: ...
    def fetch(self, lead) -> RawDoc: ...       # via SafeHttpClient (SSRF guard)
    def parse(self, raw) -> list[ParsedJob]: ...
    def normalize(self, parsed) -> NormalizedJob: ...
    def verify(self, job) -> VerificationResult: ...
    def healthcheck(self) -> Health: ...
```

## C3. Status model (deterministic)
`imported_unverified` · `open_verified` · `deadline_passed` · `closed_explicit` · `removed`
· `verification_unavailable` · `stale`

- A network error / 5xx / timeout → `verification_unavailable`. **Never** closed.
- `removed` only after **2 consecutive** confirmed 404/410 responses ≥ 24 h apart.
- `deadline_passed` only from a parsed `closing_date` in a known timezone. "Review begins",
  "priority deadline" and "open until filled" are stored separately and never close a job.
- `open_verified` → `stale` when `now − last_verified_at > source.stale_after`.

## C4. Matching
1. **Hard constraints** (user excludes, required degree level vs CV, explicit work-authorisation
   statements) → `pass | fail | unknown`. Any `fail` → score capped at 20 + "deal-breaker" flag.
2. **Requirements** extracted from the vacancy (degree, years, discipline, rank, teaching,
   publications/supervision, documents) → each `supported | not_supported | unknown`, with CV
   evidence spans and vacancy evidence spans.
3. **Components (0–100, weights configurable):** requirements 40, keyword/BM25 relevance 30,
   preferences 20 (location, arrangement, salary, type), freshness 10.
4. The UI labels the score **"relevance, not a probability of selection."** No protected
   characteristics are stored or used.

## C5. Implementation plan
1. Backend skeleton: settings, DB, models, Alembic migration, health, auth, tenant isolation + tests.
2. Import pipeline (CSV/XLSX, mapping, row errors, provenance, dedupe, safe export) + tests.
3. CV upload + extraction (rules; Claude with consent) + editable profile + tests.
4. Matching + search/filters + tests on a labelled synthetic set (report metrics).
5. Saved jobs, application Kanban, drafting (preview only) + tests.
6. Frontend SPA.
7. Phase 2: SafeHttpClient, connectors, task worker, change detection, SSE, alerts.
