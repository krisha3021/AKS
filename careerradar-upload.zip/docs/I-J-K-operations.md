# I. Setup & deployment · J. Limitations, security, runbook · K. Roadmap

## I. Setup

### Run locally (tested on Windows 11, Python 3.12.15, Node 24)
```bash
cd backend
uv sync                                   # creates .venv (Python 3.12)
cp ../.env.example .env                   # then fill in CR_ENCRYPTION_KEY
.venv/Scripts/alembic upgrade head        # Linux/macOS: .venv/bin/alembic
.venv/Scripts/python -m scripts.seed_demo # optional: SYNTHETIC demo account
cd ../frontend && npm ci && npm run build
cd ../backend && .venv/Scripts/python -m uvicorn app.main:app --port 8000
```
Then open http://localhost:8000. The background worker runs inside the API process by default (`CR_RUN_WORKER_IN_PROCESS=true`). For frontend hot reload, run `npm run dev` (port 5173, which proxies `/api`).

### Tests
```bash
cd backend && .venv/Scripts/python -m pytest          # unit + integration
cd backend && .venv/Scripts/python -m scripts.evaluate # writes docs/H-evaluation.md
cd frontend && npx vitest run                           # component tests
cd frontend && npx playwright install chromium && npx playwright test   # E2E
```

### Docker
`docker-compose.yml` defines db (Postgres 16 + pgvector), api and worker. **It has not been tested**, because Docker isn't installed on the development machine. Postgres runs with the same SQLAlchemy models; keyword search falls back to a LIKE scan there (see K).

Production checklist:
- Serve over HTTPS and set `CR_COOKIE_SECURE=true`.
- Set a unique `CR_ENCRYPTION_KEY`. The app refuses to start outside `CR_ENV=dev` with the dev key.
- Run the worker as its own process, and only one worker.
- Keep `/api/metrics` behind the reverse proxy.
- Back up both the database and the file volume, and keep the encryption key separate from the backups.

### Cost and scaling assumptions
- **One machine:** SQLite and an in-process worker suit one to a few users with up to about 10k jobs each. Duplicate detection does a fuzzy scan over the user's own jobs, which is O(n) per insert.
- **More users:** Postgres plus a separate worker process. The task queue claims work with an optimistic update, so several workers are safe. Server-Sent Events are delivered within one process; multiple API replicas need Redis pub/sub behind `app/events.py`.
- **Claude API:** costs money only for users who opt in, at one call per CV upload. A CV is roughly 3–8k input tokens and up to about 4k output tokens. Matching uses no AI.
- **External calls:** each source is fetched once per interval (6 h by default for ATS boards), with one request at a time per domain.

## J. Connector limitations
| Connector | Status | Limitations |
|---|---|---|
| Greenhouse | Implemented, tested with mocked responses | Needs the employer's board token. The full listing counts as complete, so missing jobs count toward "removed". Not yet run against a live board |
| Lever | Implemented, tested with mocked responses | Same as Greenhouse. EU-hosted sites need `region: eu` |
| RSS/Atom | Implemented, tested | A feed window is partial, so jobs never count as removed because they dropped off a feed. Employer and location are often missing |
| HigherEdJobs | Implemented, **off by default** | Redistribution terms not verified (A-research.md). For personal monitoring only |
| Adzuna | Implemented, **off until keys are set** | Not run against the live API. India (`in`) coverage is confirmed only by third parties. Descriptions are snippets, and predicted salaries are dropped |
| Vacancy-URL verifier | Implemented, tested | Relies on schema.org `JobPosting` JSON-LD or explicit "closed" wording. Pages without structured data keep their current status. Pages that block automated access are reported as blocked |
| Naukri, Naukrigulf, LinkedIn, Bayt, GulfTalent, Nature Careers, EURAXESS, Academic Positions, AcademicJobsOnline | **Not automated** | Terms, robots.txt or partner-only APIs (see A-research.md). Use spreadsheet import or add vacancy URLs, with "Open original listing" links |

## J. Security notes
- **Authentication:** argon2id password hashes. Session tokens are stored only as SHA-256 hashes, in HttpOnly SameSite=Strict cookies. Every state change needs the custom CSRF header. Rate limits cover login, registration and uploads.
- **Tenant isolation:** every query is scoped by `user_id`. Other users' resources return 404. Tests cover jobs, imports, documents, applications and signed links.
- **Files:** the extension must match the file's magic bytes; 10 MB limit; macro-enabled Excel is rejected; zip bombs are refused; XLSX formulas are never evaluated. Files and extracted text are AES-256-GCM encrypted, bound to the owner's user id. Downloads use 5-minute HMAC-signed links and still require the owner's session. Malware scanning is an unimplemented hook in `uploads.py` (ClamAV `INSTREAM`).
- **SSRF:** all outbound fetches go through `app/net.py`: http/https only, ports 80/443, no credentials in URLs. Every hostname and redirect hop must resolve to a public address, and the connected peer address is checked again. Size and time limits apply, plus per-domain concurrency and robots.txt (needed, but never enough on its own to authorise a source).
- **Untrusted content:** job descriptions are rendered as plain text, never HTML. Matching is deterministic; job text never reaches an LLM. CV text sent to Claude (with consent only) is wrapped as data, the output is checked against a schema, and any field whose quote isn't found verbatim in the CV is discarded.
- **Logging:** structured JSON logs record paths, statuses, durations and counts, never CV text. The audit log records actions only.
- **No outbound actions:** there's no email, submission or contact feature. Approving a draft only freezes it.
- **Compliance:** no regulatory compliance (GDPR, DPDP Act and so on) is claimed. Export, deletion, retention and consent are implemented, but a legal review hasn't been done.

## J. Operational runbook
| Symptom | Check | Action |
|---|---|---|
| Source shows **Failing**, error "temporary: …" | `GET /api/sources/queue`, worker logs (`"logger": "careerradar.tasks"`) | Nothing needed: it retries with exponential backoff (up to 5 attempts) and jobs are not closed. If it keeps failing, check whether the source is down or has changed its API |
| Source error "blocked/config: …" | Error text | Fix the config (board token, feed URL). If robots.txt or the terms now block access, disable the source |
| Dead-lettered tasks | `GET /api/sources/queue` → `dead_letters` | Fix the cause, then refresh the source. Dead tasks are pruned after 30 days |
| Jobs stuck "Imported · not verified" | Does the vacancy page have JSON-LD? | Expected for pages without structured data. Check them manually through "Open original listing" |
| Scores look stale after a code change | `explanation.matcher_version` | Bump `MATCHER_VERSION` in `matching.py`; results then recompute when next requested |
| Dashboard not updating | Header says "Reconnecting…" | The browser reconnects automatically with backoff and refetches on reconnect. Check the proxy doesn't buffer `/api/events` |
| Health | `GET /api/health/ready` (checks the database), `GET /api/metrics` (HTTP 2xx/4xx/5xx counts, task done/retry/dead per kind, notifications per kind) | |

## K. Roadmap for expanding sources
1. **Next:** run the Greenhouse, Lever and Adzuna connectors against real endpoints with real keys and boards, and record the results. Add Ashby, SmartRecruiters and Workday where official public endpoints exist.
2. **Indian public sector:** check official recruitment portals (for example the National Career Service, and university and IIT/NIT career pages with RSS) for permitted feeds.
3. **Gulf:** ask Bayt, GulfTalent and Naukrigulf about licensed feeds or partnerships. Until then they stay manual-only.
4. **Academic:** ask Nature Careers, EURAXESS and Academic Positions for feed or API permission. Add per-university RSS presets (many UK universities publish `/RSS`).
5. **Matching:** semantic embeddings behind the existing `keywords` component (pgvector on Postgres), academic-rank equivalence tables only with cited guidance, and a labelled real-world evaluation set to replace the synthetic one in H-evaluation.md.
6. **Ops:** Redis pub/sub for multi-replica SSE, Postgres full-text search (`tsvector`) in place of the LIKE fallback, ClamAV integration, email digests for the daily/weekly alert settings (currently in-app only).
