"""keyword search index (SQLite FTS5; no-op on other databases)

Revision ID: b1c2d3e4f5a6
Revises: af57926117fe
"""
from alembic import op

revision = "b1c2d3e4f5a6"
down_revision = "af57926117fe"
branch_labels = None
depends_on = None


def upgrade() -> None:
    if op.get_bind().dialect.name == "sqlite":
        op.execute("CREATE VIRTUAL TABLE IF NOT EXISTS jobs_fts USING fts5("
                   "job_id UNINDEXED, user_id UNINDEXED, title, employer, location, body, "
                   "tokenize='porter unicode61')")


def downgrade() -> None:
    if op.get_bind().dialect.name == "sqlite":
        op.execute("DROP TABLE IF EXISTS jobs_fts")
