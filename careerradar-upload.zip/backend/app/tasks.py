"""Durable DB-backed task queue: idempotent enqueue, retries with exponential backoff + jitter,
dead-letter after max_attempts. Handlers are registered with @handler("kind")."""
import logging
import random
import traceback
from collections.abc import Callable
from datetime import datetime, timedelta

from sqlalchemy import select, update
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.db import SessionLocal, utcnow
from app.logging_setup import incr
from app.models import Task

log = logging.getLogger("careerradar.tasks")
HANDLERS: dict[str, Callable[[Session, Task], None]] = {}


class RetryableError(Exception):
    """Temporary failure (network, 5xx, rate limit). Task is retried with backoff."""


def handler(kind: str):
    def deco(fn):
        HANDLERS[kind] = fn
        return fn
    return deco


def enqueue(db: Session, kind: str, dedupe_key: str, payload: dict | None = None,
            user_id: str | None = None, run_at: datetime | None = None, max_attempts: int = 5) -> bool:
    """Returns False if an identical task is already pending/running (idempotent)."""
    try:
        with db.begin_nested():
            db.add(Task(kind=kind, dedupe_key=dedupe_key, payload=payload or {}, user_id=user_id,
                        run_at=run_at or utcnow(), max_attempts=max_attempts))
        return True
    except IntegrityError:
        return False


def enqueue_rescore(user_id: str) -> None:
    with SessionLocal() as db:
        enqueue(db, "rescore_user", f"rescore:{user_id}", {"user_id": user_id}, user_id=user_id)
        db.commit()


def backoff(attempt: int, base: float = 30, cap: float = 3600) -> timedelta:
    return timedelta(seconds=random.uniform(0, min(cap, base * 2 ** attempt)))  # full jitter


def claim_next(db: Session, now: datetime | None = None, user_id: str | None = None) -> Task | None:
    now = now or utcnow()
    q = select(Task).where(Task.status == "pending", Task.run_at <= now)
    if user_id:
        q = q.where(Task.user_id == user_id)
    task = db.scalar(q.order_by(Task.run_at).limit(1))
    if not task:
        return None
    # Optimistic claim so two workers never run the same task.
    claimed = db.execute(update(Task).where(Task.id == task.id, Task.status == "pending")
                         .values(status="running", attempts=Task.attempts + 1)).rowcount
    db.commit()
    if not claimed:
        return None
    db.refresh(task)
    return task


def _release_key(task: Task) -> None:
    # Free the dedupe key so the same logical task can be enqueued again later.
    task.dedupe_key = f"{task.dedupe_key}#{task.id}"


def run_one(db: Session, user_id: str | None = None) -> Task | None:
    task = claim_next(db, user_id=user_id)
    if not task:
        return None
    fn = HANDLERS.get(task.kind)
    try:
        if fn is None:
            raise RuntimeError(f"no handler for task kind {task.kind}")
        fn(db, task)
        task.status, task.finished_at, task.last_error = "done", utcnow(), None
        _release_key(task)
        incr(f"task_done_{task.kind}")
    except Exception as e:  # noqa: BLE001 — every failure is recorded on the task
        db.rollback()
        task = db.get(Task, task.id)
        task.last_error = f"{type(e).__name__}: {e}"[:2000]
        if isinstance(e, RetryableError) and task.attempts < task.max_attempts:
            task.status, task.run_at = "pending", utcnow() + backoff(task.attempts)
            incr(f"task_retry_{task.kind}")
        else:
            task.status, task.finished_at = "dead", utcnow()
            _release_key(task)
            incr(f"task_dead_{task.kind}")
            log.error("task dead-lettered", extra={"task": task.kind},
                      exc_info=not isinstance(e, RetryableError))
        log.debug(traceback.format_exc())
    db.commit()
    return task


def drain(max_tasks: int = 100, time_budget_s: float | None = None, user_id: str | None = None) -> int:
    """Run due tasks until none are left, the count limit or the time budget is reached.
    Used by tests, the serverless /api/tick and the daily cron."""
    import time
    deadline = time.monotonic() + time_budget_s if time_budget_s else None
    n = 0
    with SessionLocal() as db:
        while n < max_tasks and (deadline is None or time.monotonic() < deadline) and run_one(db, user_id):
            n += 1
    return n


def recover_stuck(db: Session, older_than: timedelta = timedelta(minutes=15)) -> int:
    """Serverless instances can be killed mid-task; return 'running' tasks to the queue."""
    stuck = list(db.scalars(select(Task).where(Task.status == "running",
                                               Task.run_at < utcnow() - older_than)))
    for t in stuck:
        t.status = "pending" if t.attempts < t.max_attempts else "dead"
    db.commit()
    return len(stuck)
