"""In-process pub/sub feeding the SSE endpoint. Safe to call publish() from any thread.

Single-process only. For multiple API processes, back this with Redis pub/sub (same interface).
"""
import asyncio
import json
import threading
from collections import defaultdict
from itertools import count

_subs: dict[str, set[tuple[asyncio.AbstractEventLoop, asyncio.Queue]]] = defaultdict(set)
_lock = threading.Lock()
_ids = count(1)


def subscribe(user_id: str) -> tuple[asyncio.AbstractEventLoop, asyncio.Queue]:
    sub = (asyncio.get_running_loop(), asyncio.Queue(maxsize=100))
    with _lock:
        _subs[user_id].add(sub)
    return sub


def unsubscribe(user_id: str, sub) -> None:
    with _lock:
        _subs[user_id].discard(sub)


def publish(user_id: str, event: str, data: dict) -> None:
    msg = f"id: {next(_ids)}\nevent: {event}\ndata: {json.dumps(data, default=str)}\n\n"
    with _lock:
        subs = list(_subs.get(user_id, ()))
    for loop, q in subs:
        def _put(q=q):
            if not q.full():
                q.put_nowait(msg)
        try:
            loop.call_soon_threadsafe(_put)
        except RuntimeError:
            pass  # loop closed; subscriber is gone
