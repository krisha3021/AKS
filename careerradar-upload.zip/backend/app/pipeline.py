"""Task handlers: source fetch, vacancy verification, sweeps, rescoring and alerts."""
import logging
from datetime import timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.connectors import REGISTRY
from app.db import utcnow
from app.events import publish
from app.jobstore import upsert_job
from app.logging_setup import incr
from app.matching import ensure_scores
from app.models import Job, JobChange, JobSource, JobStatus, MatchResult, Notification, Profile, Source, Task
from app.net import BlockedError, FetchError, SafeHttpClient
from app.tasks import RetryableError, enqueue, handler
from app.verify import (apply_deadline, apply_missing_from_complete_listing, apply_outcome, apply_stale,
                        check_vacancy_url)

log = logging.getLogger("careerradar.pipeline")
NEW_MATCH_THRESHOLD = 60.0
SCORE_CHANGE_ALERT = 15.0
http_factory = SafeHttpClient  # tests replace this with a mock-transport client


def notify(db: Session, user_id: str, kind: str, message: str, job_id: str | None = None) -> None:
    n = Notification(user_id=user_id, kind=kind, job_id=job_id, message=message[:500])
    db.add(n)
    db.flush()
    incr(f"notify_{kind}")
    publish(user_id, "notification", {"id": n.id, "kind": kind, "message": n.message, "job_id": job_id})


def alerts_for_changes(db: Session, job: Job, changes: list[JobChange]) -> None:
    for c in changes:
        if not c.material:
            continue
        if c.field in ("deadline_at", "deadline_kind"):
            notify(db, job.user_id, "deadline_changed",
                   f"Deadline changed for {job.title} ({job.employer or 'unknown employer'}): "
                   f"{c.old_value or 'none'} → {c.new_value}", job.id)
        elif c.field == "status" and c.new_value in (JobStatus.CLOSED_EXPLICIT, JobStatus.REMOVED,
                                                     JobStatus.DEADLINE_PASSED):
            notify(db, job.user_id, "closed", f"{job.title} ({job.employer or ''}) is now {c.new_value.replace('_', ' ')}",
                   job.id)
        elif c.field == "requirements_text":
            notify(db, job.user_id, "requirements_changed", f"Requirements changed for {job.title}", job.id)


@handler("fetch_source")
def fetch_source(db: Session, task: Task) -> None:
    src = db.get(Source, task.payload["source_id"])
    if not src or not src.enabled:
        return
    conn = REGISTRY.get(src.connector_key)
    now = utcnow()
    src.last_checked_at = now
    try:
        out = conn.discover(src.config, http_factory(), src.etag, src.last_modified)
    except FetchError as e:
        src.consecutive_failures += 1
        src.last_error = f"temporary: {e}"
        db.commit()
        publish(src.user_id, "source_health", {"source_id": src.id, "ok": False, "error": src.last_error})
        raise RetryableError(str(e)) from e
    except (BlockedError, ValueError) as e:
        src.consecutive_failures += 1
        src.last_error = f"blocked/config: {e}"
        db.commit()
        publish(src.user_id, "source_health", {"source_id": src.id, "ok": False, "error": src.last_error})
        return  # configuration/policy problem: do not retry, do not touch job statuses
    src.etag, src.last_modified = out.etag or src.etag, out.last_modified or src.last_modified
    seen, created = set(), []
    for inc in out.jobs:
        inc.raw = {**inc.raw, "_source_id": src.id}
        res = upsert_job(db, src.user_id, inc, now=now)
        res.job.consecutive_missing, res.job.missing_since = 0, None
        seen.add(res.job.id)
        if res.created:
            res.job.first_seen_at = now
            created.append(res.job)
        changes = res.changes + apply_deadline(res.job, now)
        for c in changes:
            if c not in db:
                db.add(c)
        alerts_for_changes(db, res.job, changes)
    if out.complete:
        prior = db.scalars(select(Job).join(JobSource, JobSource.job_id == Job.id)
                           .where(JobSource.user_id == src.user_id, JobSource.source_key == src.connector_key,
                                  JobSource.raw["_source_id"].as_string() == src.id)).unique()
        for job in prior:
            if job.id not in seen and job.status not in (JobStatus.REMOVED, JobStatus.CLOSED_EXPLICIT):
                ch = apply_missing_from_complete_listing(job, now)
                for c in ch:
                    db.add(c)
                alerts_for_changes(db, job, ch)
    src.last_success_at, src.last_error, src.consecutive_failures = now, None, 0
    db.commit()
    _rescore_and_alert(db, src.user_id, {j.id for j in created})
    db.commit()
    publish(src.user_id, "jobs_changed", {"source_id": src.id, "new": len(created), "seen": len(seen)})
    publish(src.user_id, "source_health", {"source_id": src.id, "ok": True})


@handler("verify_job")
def verify_job(db: Session, task: Task) -> None:
    job = db.get(Job, task.payload["job_id"])
    if not job:
        return
    url = job.canonical_url or job.application_url
    if not url:
        return
    outcome = check_vacancy_url(url, http_factory())
    changes = apply_outcome(db, job, outcome)
    job.verification_confidence = {"present": 0.9, "closed": 0.9, "unknown": job.verification_confidence}.get(
        outcome.kind, job.verification_confidence)
    alerts_for_changes(db, job, changes)
    db.add(JobSource(job_id=job.id, user_id=job.user_id, source_key="verify:check", source_url=url,
                     raw={"outcome": outcome.kind, "detail": outcome.detail}))
    db.commit()
    _rescore_and_alert(db, job.user_id, set())
    db.commit()
    publish(job.user_id, "jobs_changed", {"job_id": job.id, "outcome": outcome.kind})
    if outcome.kind == "error":
        raise RetryableError(outcome.detail)  # retried with backoff; job was NOT closed


@handler("rescore_user")
def rescore_user(db: Session, task: Task) -> None:
    _rescore_and_alert(db, task.payload["user_id"], set())
    db.commit()
    publish(task.payload["user_id"], "jobs_changed", {"rescored": True})


def _rescore_and_alert(db: Session, user_id: str, new_job_ids: set[str]) -> None:
    before = {m.job_id: m.score for m in db.scalars(select(MatchResult).where(MatchResult.user_id == user_id))}
    profile = db.get(Profile, user_id)
    freq = (profile.preferences if profile else {}).get("alert_frequency", "daily")
    scores = ensure_scores(db, user_id)
    if freq == "off":
        return
    for jid, m in scores.items():
        job = db.get(Job, jid)
        if jid in new_job_ids and m.score >= NEW_MATCH_THRESHOLD and not m.deal_breaker:
            notify(db, user_id, "new_match", f"New match ({m.score:.0f}): {job.title} — {job.employer or ''}", jid)
        elif jid in before and abs(m.score - before[jid]) >= SCORE_CHANGE_ALERT:
            notify(db, user_id, "score_changed",
                   f"Match score for {job.title} changed {before[jid]:.0f} → {m.score:.0f}", jid)


@handler("sweep")
def sweep(db: Session, task: Task) -> None:
    """Deadline passing and staleness — purely date-based, no network."""
    now = utcnow()
    for job in db.scalars(select(Job).where(Job.status.in_([JobStatus.OPEN_VERIFIED, JobStatus.STALE,
                                                            JobStatus.IMPORTED_UNVERIFIED,
                                                            JobStatus.VERIFICATION_UNAVAILABLE]))):
        changes = apply_deadline(job, now) + apply_stale(job, now)
        for c in changes:
            db.add(c)
        if changes:
            alerts_for_changes(db, job, changes)
            publish(job.user_id, "jobs_changed", {"job_id": job.id})
    db.commit()


@handler("retention")
def retention(db: Session, task: Task) -> None:
    """Per-user retention: uploaded files, closed/removed jobs and old notifications older than the
    user's retention period are deleted. Finished tasks are pruned after 30 days."""
    from app.models import Document, User
    from app.search import unindex_job
    from app.security import delete_file
    now = utcnow()
    keys: list[str] = []
    for user in db.scalars(select(User)):
        cutoff = now - timedelta(days=user.retention_days)
        for d in db.scalars(select(Document).where(Document.user_id == user.id, Document.created_at < cutoff)):
            keys.append(d.storage_key)
            db.delete(d)
        for j in db.scalars(select(Job).where(Job.user_id == user.id, Job.updated_at < cutoff,
                                              Job.status.in_([JobStatus.CLOSED_EXPLICIT, JobStatus.REMOVED,
                                                              JobStatus.DEADLINE_PASSED]))):
            unindex_job(db, j.id)
            db.delete(j)
        for n in db.scalars(select(Notification).where(Notification.user_id == user.id,
                                                       Notification.created_at < min(cutoff, now - timedelta(days=90)))):
            db.delete(n)
    for t in db.scalars(select(Task).where(Task.status.in_(["done", "dead"]),
                                           Task.finished_at < now - timedelta(days=30))):
        db.delete(t)
    db.commit()
    for k in keys:
        delete_file(k)


def schedule_due(db: Session, now=None, user_id: str | None = None) -> int:
    """Enqueue fetches for sources whose interval has elapsed. Idempotent via dedupe keys."""
    now = now or utcnow()
    n = 0
    q = select(Source).where(Source.enabled.is_(True))
    if user_id:
        q = q.where(Source.user_id == user_id)
    for src in db.scalars(q):
        cap = REGISTRY[src.connector_key].capability
        interval = max(src.interval_minutes, cap.min_interval_minutes)
        if src.last_checked_at and now - src.last_checked_at < timedelta(minutes=interval):
            continue
        n += enqueue(db, "fetch_source", f"fetch:{src.id}", {"source_id": src.id}, user_id=src.user_id)
    enqueue(db, "sweep", "sweep", {})
    enqueue(db, "retention", f"retention:{now.date().isoformat()}", {})  # at most once a day
    db.commit()
    return n
