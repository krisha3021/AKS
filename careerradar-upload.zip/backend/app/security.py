"""Passwords, sessions, encryption at rest, private file storage, rate limiting."""
import base64
import hashlib
import os
import secrets
import threading
import time
from datetime import timedelta
from pathlib import Path

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from app.config import get_settings
from app.db import utcnow

_ph = PasswordHasher()


def hash_password(pw: str) -> str:
    return _ph.hash(pw)


def verify_password(pw: str, hashed: str) -> bool:
    try:
        return _ph.verify(hashed, pw)
    except VerifyMismatchError:
        return False


def new_session_token() -> tuple[str, str, object]:
    token = secrets.token_urlsafe(32)
    expires = utcnow() + timedelta(hours=get_settings().session_ttl_hours)
    return token, token_hash(token), expires


def token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


# ---- encryption at rest (AES-256-GCM) ----

def _aes() -> AESGCM:
    key = base64.urlsafe_b64decode(get_settings().encryption_key)
    if len(key) != 32:
        raise RuntimeError("CR_ENCRYPTION_KEY must decode to 32 bytes")
    return AESGCM(key)


def encrypt(data: bytes, aad: bytes = b"") -> bytes:
    nonce = os.urandom(12)
    return nonce + _aes().encrypt(nonce, data, aad)


def decrypt(blob: bytes, aad: bytes = b"") -> bytes:
    return _aes().decrypt(blob[:12], blob[12:], aad)


# ---- private file store: local dir, or private Vercel Blob. Content is always AES-GCM encrypted
#      before it leaves the process, so the store never sees plaintext CVs. ----

def _blob():
    from vercel.blob import BlobClient
    return BlobClient()  # reads BLOB_READ_WRITE_TOKEN


def _blob_path(storage_key: str) -> str:
    if not storage_key.isalnum():
        raise ValueError("bad storage key")
    return f"careerradar/{storage_key}.bin"


def _path(storage_key: str) -> Path:
    if not storage_key.isalnum():
        raise ValueError("bad storage key")
    d = get_settings().storage_dir
    d.mkdir(parents=True, exist_ok=True)
    return d / storage_key


def _db_put(key: str, blob: bytes) -> None:
    from app.db import SessionLocal
    from app.models import FileBlob
    with SessionLocal() as db:
        db.add(FileBlob(storage_key=key, data=blob))
        db.commit()


def _db_get(key: str) -> bytes:
    from app.db import SessionLocal
    from app.models import FileBlob
    with SessionLocal() as db:
        row = db.get(FileBlob, key)
        if row is None:
            raise FileNotFoundError(key)
        return row.data


def _db_delete(key: str) -> None:
    from app.db import SessionLocal
    from app.models import FileBlob
    with SessionLocal() as db:
        row = db.get(FileBlob, key)
        if row is not None:
            db.delete(row)
            db.commit()


def store_file(data: bytes, owner_id: str) -> str:
    key = secrets.token_hex(16)
    blob = encrypt(data, aad=owner_id.encode())
    if get_settings().storage_backend == "db":
        _db_put(key, blob)
    elif get_settings().storage_backend == "vercel_blob":
        _blob().put(_blob_path(key), blob, access="private", content_type="application/octet-stream")
    else:
        _path(key).write_bytes(blob)
    return key


def load_file(storage_key: str, owner_id: str) -> bytes:
    if get_settings().storage_backend == "db":
        raw = _db_get(storage_key)
    elif get_settings().storage_backend == "vercel_blob":
        raw = _blob().get(_blob_path(storage_key), access="private", use_cache=False).content
    else:
        raw = _path(storage_key).read_bytes()
    return decrypt(raw, aad=owner_id.encode())


def delete_file(storage_key: str) -> None:
    if get_settings().storage_backend == "db":
        _db_delete(storage_key)
    elif get_settings().storage_backend == "vercel_blob":
        from vercel.blob import BlobNotFoundError
        try:
            _blob().delete(_blob_path(storage_key))
        except BlobNotFoundError:
            pass
    else:
        _path(storage_key).unlink(missing_ok=True)


# ---- in-memory token-bucket rate limiter (per process; use Redis in multi-process prod) ----

class RateLimiter:
    def __init__(self) -> None:
        self._buckets: dict[str, tuple[float, float]] = {}
        self._lock = threading.Lock()

    def allow(self, key: str, rate_per_min: float, burst: int) -> bool:
        now = time.monotonic()
        with self._lock:
            tokens, last = self._buckets.get(key, (float(burst), now))
            tokens = min(burst, tokens + (now - last) * rate_per_min / 60)
            if tokens < 1:
                self._buckets[key] = (tokens, now)
                return False
            self._buckets[key] = (tokens - 1, now)
            return True

    def reset(self) -> None:
        with self._lock:
            self._buckets.clear()


limiter = RateLimiter()
