"""Create-or-merge jobs with full provenance and change history (deterministic)."""
from dataclasses import dataclass, field
from datetime import datetime

from rapidfuzz import fuzz
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import utcnow
from app.models import Job, JobChange, JobSource, JobStatus
from app.normalize import canonical_url, content_hash, norm_key, parse_location
from app.search import index_job

# Fields whose change is "material" for alerts.
MATERIAL = {"deadline_at", "deadline_kind", "status", "requirements_text", "salary_min", "salary_max"}
TRACKED = MATERIAL | {"title", "employer", "location_raw", "description", "application_url"}

# Status strength: a weaker source (e.g. spreadsheet) never downgrades a verified status.
VERIFIED_STATUSES = {JobStatus.OPEN_VERIFIED, JobStatus.CLOSED_EXPLICIT, JobStatus.DEADLINE_PASSED,
                     JobStatus.REMOVED}


@dataclass
class IncomingJob:
    title: str
    employer: str | None = None
    fields: dict = field(default_factory=dict)  # any other Job column
    source_key: str = "manual"
    source_url: str | None = None
    source_job_id: str | None = None
    raw: dict = field(default_factory=dict)
    import_id: str | None = None
    import_row: int | None = None
    verified: bool = False  # True only when an authorized source confirmed it is live


@dataclass
class UpsertResult:
    job: Job
    created: bool
    changes: list[JobChange]
    matched_by: str | None = None


def same_place(a: str | None, b: str | None) -> bool:
    """Compare locations by parsed country + leading place token, so 'Leeds, UK' == 'Leeds, United Kingdom'."""
    pa, pb = parse_location(a), parse_location(b)
    if pa["country"] and pb["country"] and pa["country"] != pb["country"]:
        return False
    head_a, head_b = norm_key((a or "").split(",")[0]), norm_key((b or "").split(",")[0])
    return fuzz.ratio(head_a, head_b) >= 85 or fuzz.token_set_ratio(norm_key(a), norm_key(b)) >= 90


def find_duplicate(db: Session, user_id: str, inc: IncomingJob, canon: str | None) -> tuple[Job | None, str | None]:
    """Order: same source id → same canonical vacancy URL → same employer+title (+location) fuzzy."""
    if inc.source_job_id:
        src = db.scalar(select(JobSource).where(JobSource.user_id == user_id,
                                                JobSource.source_key == inc.source_key,
                                                JobSource.source_job_id == inc.source_job_id))
        if src:
            return src.job, "source_id"
    if canon:
        job = db.scalar(select(Job).where(Job.user_id == user_id, Job.canonical_url == canon))
        if job:
            return job, "canonical_url"
    emp = norm_key(inc.employer)
    if not emp:
        return None, None
    title = norm_key(inc.title)
    loc = norm_key(inc.fields.get("location_raw"))
    best, best_score = None, 0.0
    for job in db.scalars(select(Job).where(Job.user_id == user_id)):
        if fuzz.token_set_ratio(emp, norm_key(job.employer)) < 90:
            continue
        t = fuzz.token_sort_ratio(title, norm_key(job.title))
        if t < 92:
            continue
        if loc and job.location_raw and not same_place(inc.fields.get("location_raw"), job.location_raw):
            continue  # same title at the same employer but a different campus/city = different job
        # Both have a canonical URL and they differ → treat as distinct vacancies.
        if canon and job.canonical_url and canon != job.canonical_url:
            continue
        if t > best_score:
            best, best_score = job, t
    return (best, "employer_title_location") if best else (None, None)


def _set(job: Job, name: str, value, changes: list[JobChange], record: bool) -> None:
    old = getattr(job, name)
    if value is None or value == old:
        return
    setattr(job, name, value)
    if record and name in TRACKED:
        changes.append(JobChange(job_id=job.id, user_id=job.user_id, field=name,
                                 old_value=None if old is None else str(old),
                                 new_value=str(value), material=name in MATERIAL))


def upsert_job(db: Session, user_id: str, inc: IncomingJob, now: datetime | None = None) -> UpsertResult:
    now = now or utcnow()
    canon = canonical_url(inc.fields.get("canonical_url") or inc.source_url or inc.fields.get("application_url"))
    job, matched_by = find_duplicate(db, user_id, inc, canon)
    created = job is None
    changes: list[JobChange] = []
    if created:
        job = Job(user_id=user_id, title=inc.title, employer=inc.employer, canonical_url=canon,
                  first_seen_at=now, last_seen_at=now)
        db.add(job)
        db.flush()
    else:
        job.last_seen_at = now
    for name, value in inc.fields.items():
        if name in ("status", "canonical_url"):  # canonical_url is always the normalised form above
            continue
        # Spreadsheet leads may fill blanks but never overwrite data from a verified source.
        if not created and not inc.verified and getattr(job, name) not in (None, ""):
            continue
        _set(job, name, value, changes, record=not created)
    if not created and inc.verified:
        _set(job, "title", inc.title, changes, record=True)
        _set(job, "employer", inc.employer, changes, record=True)
    if canon and not job.canonical_url:
        job.canonical_url = canon

    new_status = inc.fields.get("status")
    if inc.verified and new_status:
        _set(job, "status", new_status, changes, record=not created)
        job.last_verified_at = now
        job.last_checked_at = now
    elif created:
        job.status = JobStatus.IMPORTED_UNVERIFIED  # never "open" from an unverified source

    job.content_hash = content_hash(job.title, job.employer, job.location_raw, job.description,
                                    job.requirements_text, job.deadline_at, job.status)
    db.add(JobSource(job_id=job.id, user_id=user_id, source_key=inc.source_key, source_url=inc.source_url,
                     source_job_id=inc.source_job_id, import_id=inc.import_id, import_row=inc.import_row,
                     raw=inc.raw, seen_at=now))
    for c in changes:
        db.add(c)
    db.flush()
    index_job(db, job)
    return UpsertResult(job=job, created=created, changes=changes, matched_by=matched_by)
