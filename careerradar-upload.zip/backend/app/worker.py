"""Background worker: runs due tasks and, once a minute, schedules source refreshes and sweeps.

Run in-process (CR_RUN_WORKER_IN_PROCESS=true, default for local dev) or as its own process:
    python -m app.worker
"""
import logging
import threading
import time

from app import pipeline  # noqa: F401  (registers task handlers)
from app.db import SessionLocal
from app.tasks import run_one

log = logging.getLogger("careerradar.worker")


class BackgroundWorker:
    def __init__(self, poll_s: float = 2.0, schedule_every_s: float = 60.0) -> None:
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, name="careerradar-worker", daemon=True)
        self.poll_s, self.schedule_every_s = poll_s, schedule_every_s

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        self._thread.join(timeout=10)

    def _loop(self) -> None:
        last_schedule = 0.0
        while not self._stop.is_set():
            try:
                with SessionLocal() as db:
                    if time.monotonic() - last_schedule >= self.schedule_every_s:
                        pipeline.schedule_due(db)
                        last_schedule = time.monotonic()
                    ran = run_one(db)
                if not ran:
                    self._stop.wait(self.poll_s)
            except Exception:  # noqa: BLE001 — the loop must survive any single failure
                log.exception("worker loop error")
                self._stop.wait(self.poll_s)


if __name__ == "__main__":
    from app.logging_setup import setup_logging
    setup_logging()
    w = BackgroundWorker()
    w.start()
    try:
        while True:
            time.sleep(3600)
    except KeyboardInterrupt:
        w.stop()
