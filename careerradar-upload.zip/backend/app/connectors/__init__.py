from app.connectors.ats import Greenhouse, Lever
from app.connectors.base import MANUAL_ONLY, Capability
from app.connectors.feeds import Adzuna, HigherEdJobsFeed, RssFeed

REGISTRY = {c.capability.key: c for c in (Greenhouse(), Lever(), RssFeed(), HigherEdJobsFeed(), Adzuna())}


def capability_matrix() -> list[Capability]:
    return [c.capability for c in REGISTRY.values()] + MANUAL_ONLY
