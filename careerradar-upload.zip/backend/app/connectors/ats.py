"""Employer ATS boards with official public read APIs: Greenhouse and Lever."""
import json
import re
from datetime import UTC, datetime

from app.connectors.base import Capability, FetchOutcome, parse_iso, strip_html
from app.jobstore import IncomingJob
from app.models import JobStatus
from app.net import FetchError, SafeHttpClient
from app.normalize import infer_scope, parse_deadline, parse_location

TOKEN_RE = re.compile(r"^[A-Za-z0-9_-]{1,100}$")


def _check_token(value: str | None, name: str) -> str:
    if not value or not TOKEN_RE.match(value):
        raise ValueError(f"{name} must be letters, digits, '-' or '_'")
    return value


def _json(http: SafeHttpClient, url: str):
    r = http.get(url, {"Accept": "application/json"})
    if r.status == 404:
        raise ValueError("Board not found (check the board token)")
    if r.status != 200:
        raise FetchError(f"HTTP {r.status}")
    try:
        return json.loads(r.body)
    except json.JSONDecodeError as e:
        raise FetchError("invalid JSON from source") from e


class Greenhouse:
    capability = Capability(
        "greenhouse", "Greenhouse job board (per employer)", "official_api", True, True, 360,
        requires=["board_token", "employer"],
        notes="Official Job Board API; GET endpoints are public. One source per employer board.",
        evidence_url="https://docs.greenhouse.io/job-board.html")

    def discover(self, cfg, http, etag=None, last_modified=None) -> FetchOutcome:
        token = _check_token(cfg.get("board_token"), "board_token")
        data = _json(http, f"https://boards-api.greenhouse.io/v1/boards/{token}/jobs?content=true")
        jobs = []
        for j in data.get("jobs", []):
            loc = parse_location((j.get("location") or {}).get("name"))
            desc = strip_html(j.get("content"))
            fields = {k: v for k, v in loc.items() if v}
            fields.update(description=desc, application_url=j.get("absolute_url"),
                          canonical_url=j.get("absolute_url"), scope=infer_scope(loc["country"]),
                          posted_date=parse_iso(j.get("first_published")), status=JobStatus.OPEN_VERIFIED,
                          verification_confidence=0.95,
                          department=", ".join(d["name"] for d in j.get("departments", []) if d.get("name")) or None)
            if j.get("application_deadline"):
                fields.update(parse_deadline(j["application_deadline"]))
            jobs.append(IncomingJob(title=j.get("title") or "(untitled)", employer=cfg.get("employer") or token,
                                    fields=fields, source_key="greenhouse", source_url=j.get("absolute_url"),
                                    source_job_id=str(j.get("id")), verified=True,
                                    raw={"id": j.get("id"), "updated_at": j.get("updated_at")}))
        return FetchOutcome(jobs, complete=True)

    def healthcheck(self, cfg, http):
        token = _check_token(cfg.get("board_token"), "board_token")
        data = _json(http, f"https://boards-api.greenhouse.io/v1/boards/{token}/jobs")
        return {"ok": True, "jobs": len(data.get("jobs", []))}


class Lever:
    capability = Capability(
        "lever", "Lever postings (per employer)", "official_api", True, True, 360,
        requires=["site", "employer"],
        notes="Official Postings API; published postings are public. Use region 'eu' for EU-hosted sites.",
        evidence_url="https://github.com/lever/postings-api")

    def _base(self, cfg) -> str:
        return "https://api.eu.lever.co" if cfg.get("region") == "eu" else "https://api.lever.co"

    def discover(self, cfg, http, etag=None, last_modified=None) -> FetchOutcome:
        site = _check_token(cfg.get("site"), "site")
        data = _json(http, f"{self._base(cfg)}/v0/postings/{site}?mode=json")
        jobs = []
        for p in data if isinstance(data, list) else []:
            cats = p.get("categories") or {}
            loc = parse_location(cats.get("location"))
            reqs = "\n".join(f"{lst.get('text')}: {strip_html(lst.get('content'))}" for lst in p.get("lists", []))
            sal = p.get("salaryRange") or {}
            fields = {k: v for k, v in loc.items() if v}
            if p.get("workplaceType") in ("remote", "hybrid", "onsite"):
                fields["work_arrangement"] = p["workplaceType"]
            created = p.get("createdAt")
            fields.update(description=p.get("descriptionPlain") or strip_html(p.get("description")),
                          requirements_text=reqs or None, application_url=p.get("applyUrl") or p.get("hostedUrl"),
                          canonical_url=p.get("hostedUrl"), employment_type=cats.get("commitment"),
                          department=cats.get("department") or cats.get("team"), scope=infer_scope(loc["country"]),
                          posted_date=datetime.fromtimestamp(created / 1000, UTC).replace(tzinfo=None)
                          if isinstance(created, (int, float)) else None,
                          salary_min=sal.get("min"), salary_max=sal.get("max"), salary_currency=sal.get("currency"),
                          salary_period=(sal.get("interval") or "").replace("per-", "") or None,
                          status=JobStatus.OPEN_VERIFIED, verification_confidence=0.95)
            jobs.append(IncomingJob(title=p.get("text") or "(untitled)", employer=cfg.get("employer") or site,
                                    fields=fields, source_key="lever", source_url=p.get("hostedUrl"),
                                    source_job_id=p.get("id"), verified=True, raw={"id": p.get("id")}))
        return FetchOutcome(jobs, complete=True)

    def healthcheck(self, cfg, http):
        site = _check_token(cfg.get("site"), "site")
        data = _json(http, f"{self._base(cfg)}/v0/postings/{site}?mode=json&limit=1")
        return {"ok": True, "sample": len(data) if isinstance(data, list) else 0}
