"""Common connector interface + the source capability matrix (from docs/A-research.md)."""
import html
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Literal, Protocol

from app.jobstore import IncomingJob
from app.net import SafeHttpClient


@dataclass
class Capability:
    key: str
    name: str
    access: Literal["official_api", "rss", "jsonld_verify", "manual_only"]
    automated: bool  # does CareerRadar fetch it automatically?
    default_enabled: bool
    min_interval_minutes: int
    requires: list[str] = field(default_factory=list)  # config keys / env keys
    notes: str = ""
    evidence_url: str = ""


@dataclass
class FetchOutcome:
    """discover() result. complete=True means the listing is the full current set for this source,
    so jobs missing from it may be counted as 'missing' (never closed on the first miss)."""
    jobs: list[IncomingJob]
    complete: bool
    etag: str | None = None
    last_modified: str | None = None
    not_modified: bool = False


class Connector(Protocol):
    capability: Capability

    def discover(self, cfg: dict, http: SafeHttpClient, etag: str | None = None,
                 last_modified: str | None = None) -> FetchOutcome: ...

    def healthcheck(self, cfg: dict, http: SafeHttpClient) -> dict: ...


def strip_html(s: str | None) -> str | None:
    if not s:
        return None
    s = html.unescape(s)
    s = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", s, flags=re.S | re.I)
    s = re.sub(r"<br\s*/?>|</p>|</li>|</h\d>", "\n", s, flags=re.I)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"[ \t]+", " ", s)
    return re.sub(r"\n\s*\n+", "\n", s).strip()[:50_000]


def parse_iso(s) -> datetime | None:
    from app.normalize import parse_date
    try:
        return parse_date(s)
    except ValueError:
        return None


# Sources researched but NOT automated — shown in the UI as manual import / link-out only.
MANUAL_ONLY = [
    Capability("naukri", "Naukri", "manual_only", False, False, 0,
               notes="Terms prohibit automated crawling/scraping. Import a spreadsheet or add vacancy URLs.",
               evidence_url="https://www.naukri.com/termsconditions"),
    Capability("naukrigulf", "Naukrigulf", "manual_only", False, False, 0,
               notes="Terms prohibit bots/crawlers/scraping without written consent.",
               evidence_url="https://naukrigulf.com/terms-and-conditions"),
    Capability("linkedin", "LinkedIn", "manual_only", False, False, 0,
               notes="Job APIs are partner-only (Talent Solutions). No public job-search read API found.",
               evidence_url="https://developer.linkedin.com/docs/v1/job-posting/linkedin-job-credits-partner-program"),
    Capability("bayt", "Bayt", "manual_only", False, False, 0,
               notes="No public job-seeker API/feed found; terms could not be verified.",
               evidence_url="https://www.bayt.com/en/terms-of-use/"),
    Capability("gulftalent", "GulfTalent", "manual_only", False, False, 0,
               notes="No public API/feed found; terms could not be verified.",
               evidence_url="https://www.gulftalent.com/terms-of-use"),
    Capability("nature_careers", "Nature Careers", "manual_only", False, False, 0,
               notes="An RSS feed exists but robots.txt disallows /naturecareers/jobsrss/.",
               evidence_url="https://www.nature.com/robots.txt"),
    Capability("euraxess", "EURAXESS", "manual_only", False, False, 0,
               notes="No official API/feed found; robots.txt disallows /jobs/*.",
               evidence_url="https://euraxess.ec.europa.eu/robots.txt"),
    Capability("academic_positions", "Academic Positions", "manual_only", False, False, 0,
               notes="No API/feed found; site refuses automated requests.",
               evidence_url="https://academicpositions.com/robots.txt"),
    Capability("academicjobsonline", "AcademicJobsOnline", "manual_only", False, False, 0,
               notes="No API/feed found. Individual vacancy URLs can be verified via the vacancy-URL checker.",
               evidence_url="https://academicjobsonline.org/robots.txt"),
]
