"""RSS/Atom feeds (user-supplied URL, or presets) and the Adzuna API."""
import json
import os
import re
from urllib.parse import urlencode

from defusedxml import ElementTree as ET

from app.connectors.base import Capability, FetchOutcome, parse_iso, strip_html
from app.jobstore import IncomingJob
from app.models import JobStatus
from app.net import FetchError, SafeHttpClient
from app.normalize import infer_scope, parse_location, validate_url

ATOM = "{http://www.w3.org/2005/Atom}"


class RssFeed:
    capability = Capability(
        "rss", "RSS/Atom feed (university, employer or job board)", "rss", True, True, 360,
        requires=["url"],
        notes="Only add feeds you are permitted to use. Items are listings seen in the feed; a feed's "
              "window is partial, so jobs that drop out of a feed are NOT marked removed.",
        evidence_url="")

    def discover(self, cfg, http, etag=None, last_modified=None) -> FetchOutcome:
        url = cfg.get("url")
        err = validate_url(url)
        if err or not url:
            raise ValueError(err or "url required")
        headers = {"Accept": "application/rss+xml, application/atom+xml, application/xml;q=0.9"}
        if etag:
            headers["If-None-Match"] = etag
        if last_modified:
            headers["If-Modified-Since"] = last_modified
        r = http.get(url, headers)
        if r.status == 304:
            return FetchOutcome([], complete=False, etag=etag, last_modified=last_modified, not_modified=True)
        if r.status != 200:
            raise FetchError(f"HTTP {r.status}") if r.status >= 500 else ValueError(f"Feed returned HTTP {r.status}")
        try:
            root = ET.fromstring(r.body)  # defusedxml: no entity expansion / external entities
        except ET.ParseError as e:
            raise ValueError("Not a valid RSS/Atom feed") from e
        items = []
        for it in root.iter("item"):
            items.append({"title": it.findtext("title"), "link": it.findtext("link"), "guid": it.findtext("guid"),
                          "date": it.findtext("pubDate"), "desc": it.findtext("description")})
        for e in root.iter(f"{ATOM}entry"):
            link = e.find(f"{ATOM}link")
            items.append({"title": e.findtext(f"{ATOM}title"), "link": link.get("href") if link is not None else None,
                          "guid": e.findtext(f"{ATOM}id"), "date": e.findtext(f"{ATOM}published") or
                          e.findtext(f"{ATOM}updated"), "desc": e.findtext(f"{ATOM}summary")})
        jobs = []
        for it in items[:500]:
            title = (it["title"] or "").strip()
            if not title:
                continue
            employer = cfg.get("employer")
            if not employer and cfg.get("title_format") == "employer: title" and ":" in title:
                employer, title = (s.strip() for s in title.split(":", 1))
            desc = strip_html(it["desc"])
            loc = parse_location(cfg.get("default_location"))
            fields = {k: v for k, v in loc.items() if v}
            fields.update(description=desc, application_url=it["link"], canonical_url=it["link"],
                          posted_date=parse_iso(it["date"]), scope=infer_scope(loc["country"]),
                          status=JobStatus.OPEN_VERIFIED, verification_confidence=0.6)
            jobs.append(IncomingJob(title=title, employer=employer, fields=fields, source_key="rss",
                                    source_url=it["link"], source_job_id=(it["guid"] or it["link"] or title)[:200],
                                    verified=True, raw={"feed": url}))
        return FetchOutcome(jobs, complete=False, etag=r.headers.get("etag"),
                            last_modified=r.headers.get("last-modified"))

    def healthcheck(self, cfg, http):
        out = self.discover(cfg, http)
        return {"ok": True, "items": len(out.jobs)}


class HigherEdJobsFeed(RssFeed):
    capability = Capability(
        "higheredjobs", "HigherEdJobs category feed", "rss", True, False, 720,
        requires=["cat_id"],
        notes="Official RSS feeds exist and robots.txt allows /rss/. Redistribution terms are unverified, "
              "so this is OFF by default and intended for personal monitoring only.",
        evidence_url="https://www.higheredjobs.com/rss/")

    def discover(self, cfg, http, etag=None, last_modified=None):
        cat = str(cfg.get("cat_id", ""))
        if not cat.isdigit():
            raise ValueError("cat_id must be a number (see higheredjobs.com/rss/)")
        return super().discover({**cfg, "url": f"https://www.higheredjobs.com/rss/categoryFeed.cfm?catID={cat}",
                                 "default_location": cfg.get("default_location") or "United States"},
                                http, etag, last_modified)


class Adzuna:
    capability = Capability(
        "adzuna", "Adzuna job search API", "official_api", True, False, 720,
        requires=["country", "what", "env:CR_ADZUNA_APP_ID", "env:CR_ADZUNA_APP_KEY"],
        notes="Official API; needs free registration (app_id/app_key). Country coverage incl. India ('in') is "
              "from third-party sources — verified only once you run it with your key. Descriptions are snippets.",
        evidence_url="https://developer.adzuna.com/overview")

    def discover(self, cfg, http, etag=None, last_modified=None) -> FetchOutcome:
        app_id, app_key = os.environ.get("CR_ADZUNA_APP_ID"), os.environ.get("CR_ADZUNA_APP_KEY")
        if not (app_id and app_key):
            raise ValueError("Set CR_ADZUNA_APP_ID and CR_ADZUNA_APP_KEY to enable Adzuna")
        country = str(cfg.get("country", "")).lower()
        if not re.fullmatch(r"[a-z]{2}", country):
            raise ValueError("country must be a 2-letter code, e.g. 'in' or 'gb'")
        q = {"app_id": app_id, "app_key": app_key, "results_per_page": 50, "what": cfg.get("what", ""),
             "content-type": "application/json"}
        if cfg.get("where"):
            q["where"] = cfg["where"]
        r = http.get(f"https://api.adzuna.com/v1/api/jobs/{country}/search/1?{urlencode(q)}")
        if r.status != 200:
            raise FetchError(f"HTTP {r.status}") if r.status >= 500 else ValueError(f"Adzuna HTTP {r.status}")
        data = json.loads(r.body)
        jobs = []
        for a in data.get("results", []):
            loc = parse_location((a.get("location") or {}).get("display_name"))
            fields = {k: v for k, v in loc.items() if v}
            fields.update(description=a.get("description"), application_url=a.get("redirect_url"),
                          posted_date=parse_iso(a.get("created")), scope=infer_scope(loc["country"]),
                          salary_min=None if a.get("salary_is_predicted") == "1" else a.get("salary_min"),
                          salary_max=None if a.get("salary_is_predicted") == "1" else a.get("salary_max"),
                          employment_type=a.get("contract_time") or a.get("contract_type"),
                          status=JobStatus.OPEN_VERIFIED, verification_confidence=0.6)
            jobs.append(IncomingJob(title=a.get("title") or "(untitled)",
                                    employer=(a.get("company") or {}).get("display_name"), fields=fields,
                                    source_key="adzuna", source_url=a.get("redirect_url"),
                                    source_job_id=str(a.get("id")), verified=True, raw={"id": a.get("id")}))
        return FetchOutcome(jobs, complete=False)

    def healthcheck(self, cfg, http):
        return {"ok": True, "items": len(self.discover(cfg, http).jobs)}
