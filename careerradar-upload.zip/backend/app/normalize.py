"""Deterministic normalisation: URLs, dates, deadlines, locations, hashes. No LLM involved."""
import hashlib
import re
from datetime import datetime, time, timezone
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from dateutil import parser as dateparser

from app.models import DeadlineKind

TRACKING_PARAMS = re.compile(r"^(utm_|fbclid$|gclid$|mc_[ce]id$|trackid$|ref$|source$|src$)", re.I)

INDIA_TERMS = {"india", "bharat"}
INDIAN_PLACES = {
    "delhi", "new delhi", "mumbai", "bengaluru", "bangalore", "chennai", "kolkata", "hyderabad", "pune",
    "ahmedabad", "jaipur", "lucknow", "kanpur", "patiala", "chandigarh", "noida", "gurugram", "gurgaon",
    "kharagpur", "roorkee", "guwahati", "bhubaneswar", "indore", "bhopal", "kochi", "trivandrum",
    "thiruvananthapuram", "coimbatore", "vellore", "mohali", "dehradun", "varanasi", "nagpur", "surat",
    "mangalore", "manipal", "mysore", "mysuru", "goa", "ropar", "rupnagar", "mandi", "jodhpur", "tirupati",
}
GULF = {"uae": "United Arab Emirates", "united arab emirates": "United Arab Emirates", "dubai": "United Arab Emirates",
        "abu dhabi": "United Arab Emirates", "sharjah": "United Arab Emirates", "saudi arabia": "Saudi Arabia",
        "ksa": "Saudi Arabia", "riyadh": "Saudi Arabia", "jeddah": "Saudi Arabia", "qatar": "Qatar",
        "doha": "Qatar", "oman": "Oman", "muscat": "Oman", "kuwait": "Kuwait", "bahrain": "Bahrain"}
GULF_CITIES = {"dubai", "abu dhabi", "sharjah", "riyadh", "jeddah", "doha", "muscat"}
COUNTRY_ALIASES = {"uk": "United Kingdom", "united kingdom": "United Kingdom", "england": "United Kingdom",
                   "scotland": "United Kingdom", "wales": "United Kingdom", "usa": "United States",
                   "us": "United States", "united states": "United States", "canada": "Canada",
                   "germany": "Germany", "france": "France", "netherlands": "Netherlands", "ireland": "Ireland",
                   "singapore": "Singapore", "malaysia": "Malaysia", "australia": "Australia",
                   "new zealand": "New Zealand", "switzerland": "Switzerland", "sweden": "Sweden",
                   "denmark": "Denmark", "norway": "Norway", "finland": "Finland", "japan": "Japan",
                   "china": "China", "hong kong": "Hong Kong", "south korea": "South Korea", "italy": "Italy",
                   "spain": "Spain", "belgium": "Belgium", "austria": "Austria", "portugal": "Portugal",
                   "india": "India", **GULF}


def clean(s) -> str | None:
    if s is None:
        return None
    s = re.sub(r"\s+", " ", str(s)).strip()
    return s or None


def canonical_url(url: str | None) -> str | None:
    """Lower-case scheme/host, drop fragments, tracking params and trailing slash."""
    url = clean(url)
    if not url:
        return None
    parts = urlsplit(url)
    if parts.scheme.lower() not in {"http", "https"} or not parts.netloc:
        return None
    host = parts.netloc.lower().removeprefix("www.")
    query = urlencode(sorted((k, v) for k, v in parse_qsl(parts.query) if not TRACKING_PARAMS.match(k)))
    path = parts.path.rstrip("/") or "/"
    return urlunsplit(("https", host, path, query, ""))


def validate_url(url: str | None) -> str | None:
    """Returns an error message, or None if the URL is syntactically acceptable."""
    url = clean(url)
    if not url:
        return None
    parts = urlsplit(url)
    if parts.scheme.lower() not in {"http", "https"}:
        return f"URL must start with http:// or https:// (got '{url[:60]}')"
    if not parts.netloc or "." not in parts.netloc:
        return f"URL has no valid host: '{url[:60]}'"
    return None


def parse_location(raw: str | None) -> dict:
    """Best-effort split into city/country. Unknown parts stay None — we never guess a country."""
    out = {"location_raw": clean(raw), "city": None, "country": None, "work_arrangement": None}
    if not raw:
        return out
    low = raw.lower()
    if re.search(r"\bremote\b", low):
        out["work_arrangement"] = "remote"
    elif re.search(r"\bhybrid\b", low):
        out["work_arrangement"] = "hybrid"
    tokens = [t.strip() for t in re.split(r"[,/|;()\-–]", low) if t.strip()]
    for t in reversed(tokens):
        if t in COUNTRY_ALIASES:
            out["country"] = COUNTRY_ALIASES[t]
            break
        if t in INDIAN_PLACES:
            out["country"] = "India"
            break
    for t in tokens:
        if t in INDIAN_PLACES or t in GULF_CITIES:
            out["city"] = t.title()
            break
    return out


def infer_scope(country: str | None, home_country: str = "India") -> str | None:
    if not country:
        return None
    return "national" if country == home_country else "international"


_DATE_ONLY = re.compile(r"^\s*\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}\s*$")


def parse_date(value) -> datetime | None:
    """Parse to naive UTC. Ambiguous numeric dates (e.g. 03/04/2026) are rejected, not guessed."""
    if value is None or value == "":
        return None
    if isinstance(value, datetime):
        dt = value
    else:
        s = clean(value)
        if not s:
            return None
        m = re.match(r"^\s*(\d{1,2})[-/.](\d{1,2})[-/.](\d{4})\s*$", s)
        if m and int(m.group(1)) <= 12 and int(m.group(2)) <= 12 and m.group(1) != m.group(2):
            raise ValueError(f"ambiguous date '{s}' (day/month order unclear) — use YYYY-MM-DD")
        try:
            dt = dateparser.parse(s, dayfirst=True)
        except (ValueError, OverflowError) as e:
            raise ValueError(f"unrecognised date '{s}'") from e
    if dt.tzinfo is not None:
        dt = dt.astimezone(timezone.utc).replace(tzinfo=None)
    return dt


def classify_deadline(text: str | None) -> str:
    if not text:
        return DeadlineKind.UNKNOWN
    t = text.lower()
    if "until filled" in t or "until the position is filled" in t or "rolling" in t:
        return DeadlineKind.OPEN_UNTIL_FILLED
    if "review" in t and ("begin" in t or "start" in t or "commence" in t):
        return DeadlineKind.REVIEW_BEGINS
    if "priority" in t:
        return DeadlineKind.PRIORITY
    return DeadlineKind.CLOSING


def parse_deadline(value, tz_name: str | None = None) -> dict:
    """Returns deadline fields. A date with no time means end of that day in the stated timezone;
    without a timezone the instant is stored as end-of-day UTC and deadline_tz stays None (unknown)."""
    text = clean(value) if not isinstance(value, datetime) else value.isoformat()
    out = {"deadline_text": text, "deadline_kind": classify_deadline(text) if text else DeadlineKind.UNKNOWN,
           "deadline_at": None, "deadline_tz": tz_name}
    if not text or out["deadline_kind"] == DeadlineKind.OPEN_UNTIL_FILLED:
        return out
    date_part = re.sub(r"(?i)^(closing date|deadline|closes|review (of applications )?begins( on)?|"
                       r"priority deadline)[:\s]*", "", text)
    if isinstance(value, datetime):
        dt = value
    else:
        try:
            dt = dateparser.parse(date_part, dayfirst=True, fuzzy=True)
        except (ValueError, OverflowError):
            return out
    if dt.tzinfo is None:
        if dt.time() == time(0, 0):
            dt = dt.replace(hour=23, minute=59, second=59)
        if tz_name:
            try:
                dt = dt.replace(tzinfo=ZoneInfo(tz_name))
            except ZoneInfoNotFoundError:
                out["deadline_tz"] = None
    out["deadline_at"] = dt.astimezone(timezone.utc).replace(tzinfo=None) if dt.tzinfo else dt
    return out


def norm_key(s: str | None) -> str:
    s = (s or "").lower()
    s = re.sub(r"\b(the|of|and|at|for|in|university|univ|college|institute|ltd|pvt|inc|llc)\b", " ", s)
    return re.sub(r"[^a-z0-9]+", " ", s).strip()


def content_hash(*parts) -> str:
    h = hashlib.sha256()
    for p in parts:
        h.update(((clean(str(p)) if p is not None else None) or "").encode())
        h.update(b"\x1f")
    return h.hexdigest()
