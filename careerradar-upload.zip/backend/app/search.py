"""Keyword search. SQLite: FTS5 with BM25. Other DBs: case-insensitive LIKE fallback (Postgres
production should swap in tsvector + pgvector; see docs/J-operations.md)."""
import re

from sqlalchemy import text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session

from app.models import Job


def _is_sqlite(bind) -> bool:
    return bind.dialect.name == "sqlite"


def ensure_fts(engine: Engine) -> None:
    if not _is_sqlite(engine):
        return
    with engine.begin() as conn:
        conn.execute(text(
            "CREATE VIRTUAL TABLE IF NOT EXISTS jobs_fts USING fts5("
            "job_id UNINDEXED, user_id UNINDEXED, title, employer, location, body, "
            "tokenize='porter unicode61')"))


def index_job(db: Session, job: Job) -> None:
    if not _is_sqlite(db.get_bind()):
        return
    db.execute(text("DELETE FROM jobs_fts WHERE job_id = :id"), {"id": job.id})
    db.execute(text("INSERT INTO jobs_fts(job_id, user_id, title, employer, location, body) "
                    "VALUES (:id, :uid, :t, :e, :l, :b)"),
               {"id": job.id, "uid": job.user_id, "t": job.title or "", "e": job.employer or "",
                "l": " ".join(filter(None, [job.location_raw, job.city, job.country])),
                "b": " ".join(filter(None, [job.department, job.discipline, job.description,
                                            job.requirements_text]))})


def unindex_job(db: Session, job_id: str) -> None:
    if _is_sqlite(db.get_bind()):
        db.execute(text("DELETE FROM jobs_fts WHERE job_id = :id"), {"id": job_id})


def fts_query(q: str) -> str:
    """Turn free text into a safe FTS5 query: quoted terms, OR'ed, prefix-matched."""
    terms = [t for t in re.findall(r"[\w]+", q.lower()) if len(t) > 1][:20]
    return " OR ".join(f'"{t}"*' for t in terms)


def keyword_scores(db: Session, user_id: str, q: str) -> dict[str, float]:
    """job_id -> relevance in [0,1] (1 = best match for this query). Scoped to the user."""
    query = fts_query(q)
    if not query:
        return {}
    if _is_sqlite(db.get_bind()):
        rows = db.execute(text(
            "SELECT job_id, bm25(jobs_fts, 0, 0, 10.0, 4.0, 2.0, 1.0) AS s FROM jobs_fts "
            "WHERE jobs_fts MATCH :q AND user_id = :uid"), {"q": query, "uid": user_id}).all()
        if not rows:
            return {}
        best = min(r.s for r in rows)  # bm25: more negative = better
        return {r.job_id: (r.s / best if best else 0.0) for r in rows}
    terms = re.findall(r"\w+", q.lower())
    out = {}
    for job in db.query(Job).filter(Job.user_id == user_id):
        hay = " ".join(filter(None, [job.title, job.employer, job.description])).lower()
        hits = sum(t in hay for t in terms)
        if hits:
            out[job.id] = hits / len(terms)
    return out
