"""Grounded application drafts built only from profile fields and the vacancy text.

Anything the draft would need but the profile does not contain is listed in `missing` and shown
as a [bracketed placeholder] — achievements are never invented. Drafts are never sent by the app."""
from app.matching import detect_requirements
from app.models import Job

KINDS = ("application_email", "cover_letter", "research_statement_outline", "teaching_statement_outline",
         "selection_criteria")


def _vals(fields: list[dict], kind: str) -> list[str]:
    out = []
    for f in fields:
        if f["kind"] == kind and not f.get("rejected"):
            v = f["value"]
            out.append(v.get("text") if isinstance(v, dict) else str(v))
    return out


def build_draft(kind: str, job: Job, fields: list[dict]) -> tuple[str, list[str]]:
    missing: list[str] = []
    degrees, jobs = _vals(fields, "degree"), _vals(fields, "employment")
    interests, teaching = _vals(fields, "research_interest"), _vals(fields, "teaching_area")
    pubs, grants, sup = _vals(fields, "publication"), _vals(fields, "grant"), _vals(fields, "supervision")
    role = f"{job.title} at {job.employer or '[employer]'}"

    def need(label: str, items: list[str], n: int = 3) -> str:
        if items:
            return "; ".join(items[:n])
        missing.append(label)
        return f"[{label} — not found in your profile]"

    if kind == "application_email":
        body = (f"Subject: Application for {role}\n\nDear [hiring contact],\n\n"
                f"I am writing to apply for the position of {role}"
                f"{' (ref: ' + job.canonical_url + ')' if job.canonical_url else ''}.\n\n"
                f"My qualifications include {need('degree', degrees, 2)}. "
                f"Most recently: {need('current role', jobs, 1)}.\n\n"
                "Please find my CV and supporting documents attached. [Check the vacancy's required documents.]\n\n"
                "Kind regards,\n[Your name]")
    elif kind == "cover_letter":
        reqs, _ = detect_requirements(job)
        req_lines = "\n".join(f"- {r.label}: [explain your evidence]" for r in reqs) or \
            "- [The vacancy text available lists no specific requirements; address the full person specification]"
        body = (f"Dear Selection Committee,\n\nI wish to apply for the {role}.\n\n"
                f"Qualifications: {need('degree', degrees)}.\n"
                f"Experience: {need('employment history', jobs)}.\n"
                f"Research interests: {need('research interests', interests)}.\n\n"
                f"How I meet the stated requirements:\n{req_lines}\n\n"
                "[Why this institution/department specifically — write in your own words.]\n\n"
                "Yours sincerely,\n[Your name]")
    elif kind == "research_statement_outline":
        body = ("1. Research vision\n   Themes from your profile: " + need("research interests", interests) +
                "\n2. Track record\n   Publications on file: " + str(len(pubs)) + (" (see profile)" if pubs else
                " [no publications in profile]") +
                "\n3. Funding\n   " + need("grants", grants) +
                f"\n4. Fit with {job.employer or '[employer]'} {job.department or '[department]'}\n   [Name colleagues/"
                "facilities you would work with]\n5. 3–5 year plan\n   [Concrete projects and funding targets]")
    elif kind == "teaching_statement_outline":
        body = ("1. Teaching philosophy\n   [Your own words]\n2. Courses taught\n   " +
                need("teaching areas", teaching, 6) +
                "\n3. Supervision and mentoring\n   " + need("supervision record", sup) +
                f"\n4. Courses you could offer at {job.employer or '[employer]'}\n   [Match to their curriculum]"
                "\n5. Evidence of effectiveness\n   [Feedback, outcomes — only real data]")
    elif kind == "selection_criteria":
        reqs, _ = detect_requirements(job)
        if not reqs:
            missing.append("selection criteria (none detected in the vacancy text)")
            body = "[Paste the official selection criteria from the vacancy, then respond to each.]"
        else:
            body = "\n\n".join(f"Criterion: {r.label}\nVacancy text: \"{r.vacancy_quote[:200]}\"\n"
                               "Response (STAR): [Situation] [Task] [Action] [Result — real outcomes only]"
                               for r in reqs)
    else:
        raise ValueError(kind)
    return body, sorted(set(missing))
