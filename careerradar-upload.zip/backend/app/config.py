"""Runtime settings. Every value can be overridden with a CR_-prefixed environment variable."""
from functools import lru_cache
from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BACKEND_DIR = Path(__file__).resolve().parent.parent


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="CR_", env_file=BACKEND_DIR / ".env", extra="ignore")

    env: str = "dev"
    database_url: str = f"sqlite:///{(BACKEND_DIR / 'data' / 'careerradar.db').as_posix()}"
    storage_dir: Path = BACKEND_DIR / "data" / "files"
    # 32-byte urlsafe-base64 key for AES-GCM file/text encryption. Dev default is NOT secret.
    encryption_key: str = "ZGV2LW9ubHktZGV2LW9ubHktZGV2LW9ubHktMzJieXQ="
    session_ttl_hours: int = 24 * 7
    cookie_secure: bool = False
    max_upload_mb: int = 10
    max_import_rows: int = 5000
    default_retention_days: int = 365

    # Claude API (optional). Used only after a user's explicit consent.
    anthropic_api_key: str | None = None
    anthropic_model: str = "claude-opus-5-5"

    # Outbound HTTP (connectors / URL verification)
    http_timeout_s: float = 15.0
    http_max_bytes: int = 3 * 1024 * 1024
    http_user_agent: str = "CareerRadar/0.1 (+personal job monitor)"
    per_domain_concurrency: int = 1
    run_worker_in_process: bool = True

    cors_origins: list[str] = Field(default_factory=lambda: ["http://localhost:5173"])

    # Serverless (Vercel) mode: no in-process worker, no SSE fan-out across instances,
    # files in private Vercel Blob, background work driven by /api/tick and a daily cron.
    storage_backend: str = "local"  # local | vercel_blob
    live_updates: bool = True  # False -> frontend polls /api/tick instead of SSE
    poll_seconds: int = 60
    cron_secret: str | None = None
    serverless: bool = False
    trust_cf_connecting_ip: bool = False  # true only when served through Cloudflare Tunnel on 127.0.0.1
    behind_cloudflare_worker: bool = False  # true only inside the Cloudflare Container (not publicly reachable)


def _normalise_db_url(url: str) -> str:
    # Neon/Vercel Postgres hand out postgres:// URLs; SQLAlchemy needs an explicit driver.
    for prefix in ("postgres://", "postgresql://"):
        if url.startswith(prefix):
            return "postgresql+psycopg://" + url[len(prefix):]
    return url


@lru_cache
def get_settings() -> Settings:
    import os
    s = Settings()
    if not os.environ.get("CR_DATABASE_URL"):
        external = os.environ.get("DATABASE_URL") or os.environ.get("POSTGRES_URL")
        if external:
            s.database_url = external
    s.database_url = _normalise_db_url(s.database_url)
    if not s.cron_secret and os.environ.get("CRON_SECRET"):
        s.cron_secret = os.environ["CRON_SECRET"]  # name Vercel Cron uses
    return s
