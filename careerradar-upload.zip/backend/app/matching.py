"""Evidence-based matching. Deterministic: requirement detection is regex over the vacancy text,
support is checked against confirmed/extracted CV fields. Semantic similarity (if added later)
may only adjust the keyword component and can never lift a confirmed mandatory mismatch.

The score is relevance to the user's stated profile and preferences — NOT a probability of
selection. No protected characteristics are stored or used."""
import re
from dataclasses import dataclass, field

from rapidfuzz import fuzz
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.cv.experience import experience_summary
from app.db import utcnow
from app.models import Job, JobStatus, MatchResult, Profile, Stated
from app.normalize import parse_location
from app.search import keyword_scores

WEIGHTS = {"requirements": 40, "keywords": 30, "preferences": 20, "freshness": 10}
MATCHER_VERSION = 3  # bump whenever scoring logic changes so stored results are recomputed
DEAL_BREAKER_CAP = 20.0
DEGREE_RANK = {"bachelors": 1, "masters": 2, "doctorate": 3}

MANDATORY = r"(required|essential|must|mandatory|minimum|necessary|should possess)"
PREFERRED = r"(desirable|preferred|advantage|ideally|plus)"


@dataclass
class Requirement:
    key: str
    label: str
    mandatory: bool | None  # None = not stated whether mandatory
    vacancy_quote: str
    status: str = "unknown"  # supported | not_supported | unknown
    cv_evidence: list[dict] = field(default_factory=list)
    note: str = ""


def _sentences(text: str) -> list[str]:
    return [s.strip() for s in re.split(r"(?<=[.;\n])\s+|\n", text) if len(s.strip()) > 3]


def _mandatory(sentence: str) -> bool | None:
    if re.search(PREFERRED, sentence, re.I):
        return False
    if re.search(MANDATORY, sentence, re.I):
        return True
    return None


def detect_requirements(job: Job) -> tuple[list[Requirement], dict]:
    """Requirements explicitly stated in the vacancy. Never inferred from the job title alone."""
    text = "\n".join(filter(None, [job.requirements_text, job.description]))
    reqs: list[Requirement] = []
    facts = {"visa": job.visa_sponsorship, "documents": []}
    for s in _sentences(text):
        low = s.lower()
        if re.search(r"\b(ph\.?\s?d|doctorate|doctoral degree)\b", low) and "phd student" not in low:
            reqs.append(Requirement("degree:doctorate", "Doctorate (PhD)", _mandatory(s), s))
        elif re.search(r"\b(master'?s|m\.?tech|m\.?e\.|m\.?sc|postgraduate degree)\b", low):
            reqs.append(Requirement("degree:masters", "Master's degree", _mandatory(s), s))
        elif re.search(r"\b(bachelor'?s|b\.?tech|b\.?e\.|undergraduate degree)\b", low):
            reqs.append(Requirement("degree:bachelors", "Bachelor's degree", _mandatory(s), s))
        m = re.search(r"(\d{1,2})\s*\+?\s*(?:or more\s*)?years?.{0,40}?experience", low)
        if m:
            reqs.append(Requirement(f"experience:{m.group(1)}", f"At least {m.group(1)} years' experience",
                                    _mandatory(s) if _mandatory(s) is not None else True, s))
        if re.search(r"publications?|peer[- ]reviewed|journal papers?|research outputs?", low):
            reqs.append(Requirement("publications", "Research publications", _mandatory(s), s))
        if re.search(r"teaching (experience|ability|record)|experience (of|in) teaching", low):
            reqs.append(Requirement("teaching", "Teaching experience", _mandatory(s), s))
        if re.search(r"supervis(e|ion|ing)", low):
            reqs.append(Requirement("supervision", "Research supervision", _mandatory(s), s))
        if re.search(r"(external|research) funding|grant (income|record|capture)|secure funding", low):
            reqs.append(Requirement("funding", "Research funding record", _mandatory(s), s))
        if re.search(r"no visa sponsorship|unable to (offer|provide) (visa )?sponsorship|"
                     r"must (already )?have (the )?right to work|citizens? only|will not sponsor", low):
            facts["visa"] = Stated.NO
            facts["visa_quote"] = s
        elif re.search(r"visa sponsorship (is )?(available|provided|offered)|will sponsor|sponsorship available", low):
            facts["visa"] = Stated.YES
            facts["visa_quote"] = s
        for doc in ("cover letter", "research statement", "teaching statement", "references", "referees",
                    "writing sample", "transcripts", "diversity statement", "selection criteria"):
            if doc in low and doc not in facts["documents"]:
                facts["documents"].append(doc)
    seen, unique = set(), []
    for r in reqs:
        if r.key not in seen:
            seen.add(r.key)
            unique.append(r)
    return unique, facts


STOP = {"the", "a", "an", "or", "and", "of", "in", "field", "fields", "related", "relevant", "discipline",
        "area", "subject", "closely", "allied", "similar", "equivalent", "is", "are", "essential", "required"}


def degree_subject(sentence: str) -> str | None:
    """'A PhD in Computer Science or a related discipline is essential' -> 'Computer Science'."""
    m = re.search(r"\b(?:ph\.?\s?d|doctorate|degree|master'?s|m\.?tech|b\.?tech|bachelor'?s)\b[^.;]*?\b(?:in|on)\s+"
                  r"([A-Za-z][A-Za-z &,\-/]{2,80})", sentence, re.I)
    if not m:
        return None
    subj = re.split(r"\b(?:or|is|are|with|from|and a|preferred|essential|required|desirable)\b", m.group(1),
                    flags=re.I)[0]
    subj = subj.strip(" ,-/")
    return subj or None


def _subject_overlap(subject: str, degree_text: str) -> bool:
    want = {w for w in re.findall(r"[a-z]+", subject.lower()) if w not in STOP and len(w) > 2}
    have = {w for w in re.findall(r"[a-z]+", degree_text.lower()) if len(w) > 2}
    return bool(want & have)


def title_similarity(target: str, title: str) -> float:
    """1.0 when every word of the target title appears in the job title; otherwise a strict fuzzy ratio,
    so sharing one generic word ('Professor') is not a match."""
    t_words = {w for w in re.findall(r"[a-z]+", target.lower()) if w not in STOP}
    j_words = set(re.findall(r"[a-z]+", title.lower()))
    if t_words and t_words <= j_words:
        return 1.0
    return fuzz.token_sort_ratio(target.lower(), title.lower()) / 100 * 0.8


def _ev(f: dict) -> dict:
    q = f["evidence"][0]["quote"] if f.get("evidence") else f"(entered by you: {f['value']})"
    return {"field_id": f["id"], "kind": f["kind"], "quote": q, "confirmed": f.get("confirmed", False)}


def evaluate(req: Requirement, fields: list[dict], exp: dict) -> None:
    by_kind: dict[str, list[dict]] = {}
    for f in fields:
        by_kind.setdefault(f["kind"], []).append(f)
    if req.key.startswith("degree:"):
        need = DEGREE_RANK[req.key.split(":")[1]]
        degrees = [f for f in by_kind.get("degree", []) if isinstance(f["value"], dict)]
        ok = [f for f in degrees if DEGREE_RANK.get(f["value"].get("level"), 0) >= need]
        subject = degree_subject(req.vacancy_quote)
        if ok and subject:
            on_subject = [f for f in ok if _subject_overlap(subject, f["value"].get("text", ""))]
            if on_subject:
                ok = on_subject
            else:
                # Subject equivalence (e.g. Machine Learning vs Computer Science) cannot be decided by text
                # matching, so this is never a *confirmed* mismatch — the user decides.
                req.cv_evidence = [_ev(f) for f in ok[:2]]
                related = re.search(r"related|equivalent|cognate|similar|any discipline", req.vacancy_quote, re.I)
                req.note = (f"Your degree level matches, but its subject does not obviously match '{subject}'"
                            f"{' (the vacancy allows related fields)' if related else ''}. Confirm whether yours counts.")
                return
        if ok:
            req.status, req.cv_evidence = "supported", [_ev(f) for f in ok[:2]]
        elif degrees:
            req.status, req.cv_evidence = "not_supported", [_ev(f) for f in degrees[:2]]
            req.note = "Your CV lists degrees, but none at the level stated."
        else:
            req.note = "No degree found in your profile; add it to evaluate this requirement."
    elif req.key.startswith("experience:"):
        years = int(req.key.split(":")[1])
        if exp["total_months"] == 0:
            req.note = "No dated employment in your profile."
        elif exp["total_months"] < years * 12:
            # Year-only dates are counted at their widest span, so the total is an upper bound:
            # falling short is a certain mismatch even when some dates are ambiguous.
            req.status = "not_supported"
            req.cv_evidence = [_ev(f) for f in by_kind.get("employment", [])[:3]]
            req.note = f"At most about {exp['total_years']} years found; {years} stated."
        elif exp["ambiguous_field_ids"]:
            req.note = (f"About {exp['total_years']} years found, but some dates are year-only or unclear — "
                        "confirm them to evaluate.")
        else:
            req.status = "supported"
            req.cv_evidence = [_ev(f) for f in by_kind.get("employment", [])[:3]]
            req.note = f"About {exp['total_years']} years of non-overlapping experience found."
    else:
        kinds = {"publications": ["publication"], "teaching": ["teaching_area"], "supervision": ["supervision"],
                 "funding": ["grant"]}[req.key]
        hits = [f for k in kinds for f in by_kind.get(k, [])]
        if req.key == "teaching":
            hits += [f for f in by_kind.get("employment", []) if (f["value"] or {}).get("rank")]
        if hits:
            req.status, req.cv_evidence = "supported", [_ev(f) for f in hits[:3]]
        else:
            req.note = "Nothing in your profile addresses this; it may simply be missing from the CV."
            # Absence of evidence is 'unknown', not 'not supported', unless the CV is otherwise complete.


@dataclass
class MatchOutcome:
    score: float
    components: dict
    explanation: dict
    deal_breaker: bool


def profile_query(fields: list[dict], prefs: dict) -> str:
    terms = list(prefs.get("target_titles", [])) + list(prefs.get("title_synonyms", []))
    terms += list(prefs.get("disciplines", [])) + list(prefs.get("research_areas", []))
    terms += [str(f["value"]) for f in fields if f["kind"] in ("research_interest", "skill", "teaching_area")]
    return " ".join(terms)


def match_job(job: Job, fields: list[dict], prefs: dict, kw: float | None) -> MatchOutcome:
    fields = [f for f in fields if not f.get("rejected")]
    exp = experience_summary(fields)
    reqs, facts = detect_requirements(job)
    for r in reqs:
        evaluate(r, fields, exp)

    deal_breakers, hard = [], []
    hay = " ".join(filter(None, [job.title, job.description])).lower()
    for emp in prefs.get("excluded_employers", []):
        if emp and job.employer and fuzz.partial_ratio(emp.lower(), job.employer.lower()) >= 90:
            deal_breakers.append(f"Employer '{job.employer}' is on your exclusion list")
    for loc in prefs.get("excluded_locations", []):
        if loc and loc.lower() in " ".join(filter(None, [job.location_raw, job.city, job.country])).lower():
            deal_breakers.append(f"Location matches your excluded location '{loc}'")
    for kwd in prefs.get("excluded_keywords", []):
        if kwd and re.search(rf"\b{re.escape(kwd.lower())}\b", hay):
            deal_breakers.append(f"Contains your excluded keyword '{kwd}'")
    visa = facts["visa"]
    if prefs.get("needs_visa_sponsorship"):
        if visa == Stated.NO:
            deal_breakers.append("The vacancy states no visa sponsorship; you indicated you need it")
        hard.append({"label": "Visa sponsorship", "status": {Stated.YES: "supported", Stated.NO: "not_supported"}
                     .get(visa, "unknown"), "quote": facts.get("visa_quote"),
                     "note": "Not stated in the vacancy" if visa == Stated.NOT_STATED else ""})
    for r in reqs:
        if r.mandatory and r.status == "not_supported":
            deal_breakers.append(f"Mandatory requirement not met by your profile: {r.label}")

    # Components (0..1)
    if reqs:
        num = den = 0.0
        for r in reqs:
            w = 2.0 if r.mandatory else 1.0
            num += w * {"supported": 1.0, "unknown": 0.5, "not_supported": 0.0}[r.status]
            den += w
        c_req = num / den
    else:
        c_req = 0.5  # nothing stated → neutral, shown as 'unknown requirements'
    titles = prefs.get("target_titles", []) + prefs.get("title_synonyms", [])
    title_sim = max((title_similarity(t, job.title) for t in titles if t), default=0.0)
    c_kw = max(kw or 0.0, title_sim) if (kw is not None or titles) else 0.5

    pref_scores, pref_notes = [], []
    if prefs.get("countries"):
        if job.country:
            ok = job.country in prefs["countries"]
            pref_scores.append(1.0 if ok else 0.0)
            pref_notes.append(f"Country {job.country} {'is' if ok else 'is not'} in your list")
        else:
            pref_scores.append(0.5)
            pref_notes.append("Country unknown")
    if prefs.get("work_arrangements"):
        if job.work_arrangement:
            pref_scores.append(1.0 if job.work_arrangement in prefs["work_arrangements"] else 0.0)
        else:
            pref_scores.append(0.5)
    if prefs.get("salary_min") and prefs.get("salary_currency"):
        if job.salary_max and job.salary_currency == prefs["salary_currency"]:
            pref_scores.append(1.0 if job.salary_max >= prefs["salary_min"] else 0.0)
        else:
            pref_scores.append(0.5)
            pref_notes.append("Salary not comparable (not stated or different currency)")
    if prefs.get("employment_types"):
        pref_scores.append(0.5 if not job.employment_type else
                           float(job.employment_type.lower() in [e.lower() for e in prefs["employment_types"]]))
    c_pref = sum(pref_scores) / len(pref_scores) if pref_scores else 0.5

    c_fresh = {JobStatus.OPEN_VERIFIED: 1.0, JobStatus.IMPORTED_UNVERIFIED: 0.5,
               JobStatus.VERIFICATION_UNAVAILABLE: 0.4, JobStatus.STALE: 0.3}.get(job.status, 0.0)

    comps = {"requirements": c_req, "keywords": c_kw, "preferences": c_pref, "freshness": c_fresh}
    score = sum(WEIGHTS[k] * v for k, v in comps.items())
    if deal_breakers:
        score = min(score, DEAL_BREAKER_CAP)

    supported = [r for r in reqs if r.status == "supported"]
    gaps = [r for r in reqs if r.status == "not_supported"]
    unknown = [r for r in reqs if r.status == "unknown"]
    why = []
    if title_sim >= 0.8:
        why.append(f"Title closely matches your target roles ({round(title_sim * 100)}% similar)")
    if kw and kw >= 0.5:
        why.append("Vacancy text shares many terms with your research interests and skills")
    why += [f"{r.label}: supported by your CV" for r in supported]
    why += [n for n in pref_notes if " is in " in n]

    def rd(r: Requirement) -> dict:
        return {"key": r.key, "label": r.label, "mandatory": r.mandatory, "status": r.status,
                "vacancy_quote": r.vacancy_quote[:300], "cv_evidence": r.cv_evidence, "note": r.note}

    explanation = {
        "summary": (f"{len(supported)} of {len(reqs)} stated requirements supported by your CV"
                    if reqs else "The vacancy text available states no checkable requirements"),
        "why": why, "requirements": [rd(r) for r in reqs], "gaps": [rd(r) for r in gaps],
        "unknowns": [rd(r) for r in unknown], "deal_breakers": deal_breakers, "hard_constraints": hard,
        "visa_sponsorship": str(visa), "required_documents": facts["documents"],
        "disclaimer": "Relevance to your profile, not a probability of being selected.",
        "matcher_version": MATCHER_VERSION,
    }
    return MatchOutcome(round(score, 1), {k: round(v * 100) for k, v in comps.items()}, explanation,
                        bool(deal_breakers))


def ensure_scores(db: Session, user_id: str, force: bool = False) -> dict[str, MatchResult]:
    """(Re)computes stale match results for the user. Returns job_id -> MatchResult."""
    profile = db.get(Profile, user_id)
    fields = profile.fields if profile else []
    prefs = profile.preferences if profile else {}
    version = profile.version if profile else 0
    existing = {m.job_id: m for m in db.scalars(select(MatchResult).where(MatchResult.user_id == user_id))}
    jobs = list(db.scalars(select(Job).where(Job.user_id == user_id)))
    stale = [j for j in jobs if force or j.id not in existing or existing[j.id].profile_version != version
             or existing[j.id].computed_at < j.updated_at
             or existing[j.id].explanation.get("matcher_version") != MATCHER_VERSION]
    if not stale:
        return existing
    query = profile_query(fields, prefs)
    kws = keyword_scores(db, user_id, query) if query else {}
    for j in stale:
        out = match_job(j, fields, prefs, kws.get(j.id, 0.0) if query else None)
        m = existing.get(j.id) or MatchResult(job_id=j.id, user_id=user_id)
        m.score, m.components, m.explanation = out.score, out.components, out.explanation
        m.deal_breaker, m.profile_version, m.computed_at = out.deal_breaker, version, utcnow()
        db.add(m)
        existing[j.id] = m
    db.flush()
    return existing
