"""SYNTHETIC demo vacancies. None of these are real jobs; every record is stored with
is_synthetic=True and shown with a DEMO badge. Employers use reserved example domains."""

DEMO_JOBS = [
    {"title": "Assistant Professor – Computer Science & Engineering (DEMO)", "employer": "Synthetic Institute of Technology (DEMO)",
     "location_raw": "Patiala, Punjab, India", "country": "India", "city": "Patiala", "scope": "national",
     "discipline": "Computer Science", "rank_or_seniority": "Assistant Professor", "employment_type": "Full-time",
     "description": "A PhD in Computer Science or a related discipline is essential. Teaching experience at "
                    "undergraduate level is required. Publications in peer-reviewed journals are desirable. "
                    "Please submit a cover letter, research statement and references.",
     "deadline": "2026-12-15", "url": "https://careers.example.org/demo/sit-cse-ap"},
    {"title": "Lecturer in Machine Learning (DEMO)", "employer": "Synthetic University of Northshire (DEMO)",
     "location_raw": "Northshire, United Kingdom", "country": "United Kingdom", "scope": "international",
     "discipline": "Machine Learning", "rank_or_seniority": "Lecturer", "employment_type": "Full-time",
     "description": "PhD (or near completion) in machine learning is essential. Evidence of research supervision "
                    "is desirable. Visa sponsorship is available for this role.",
     "deadline": "Review begins 2026-11-20", "url": "https://jobs.example.ac.uk/demo/ml-lecturer",
     "visa_sponsorship": "stated_yes", "salary_min": 41000, "salary_max": 49000, "salary_currency": "GBP",
     "salary_period": "year"},
    {"title": "Postdoctoral Fellow – Brain-Computer Interfaces (DEMO)", "employer": "Demo Neurotech Research Centre (DEMO)",
     "location_raw": "Dubai, UAE", "country": "United Arab Emirates", "city": "Dubai", "scope": "international",
     "discipline": "Neuroengineering", "employment_type": "Fixed-term",
     "description": "PhD in biomedical engineering, computer science or related field required. Experience with EEG "
                    "signal processing and deep learning is essential. Applicants must already have the right to "
                    "work in the UAE.",
     "deadline": "Open until filled", "url": "https://example.com/demo/bci-postdoc"},
    {"title": "Professor of Data Science (DEMO)", "employer": "Example Gulf University (DEMO)",
     "location_raw": "Doha, Qatar", "country": "Qatar", "city": "Doha", "scope": "international",
     "discipline": "Data Science", "rank_or_seniority": "Professor",
     "description": "PhD essential. Minimum 15 years of academic experience is required, including a record of "
                    "external research funding and doctoral supervision.",
     "deadline": "2026-11-30", "url": "https://example.com/demo/gulf-prof-ds"},
    {"title": "Senior Machine Learning Engineer (DEMO)", "employer": "Example Analytics Pvt Ltd (DEMO)",
     "location_raw": "Bengaluru, India (Hybrid)", "country": "India", "city": "Bengaluru", "scope": "national",
     "work_arrangement": "hybrid", "employment_type": "Full-time",
     "description": "5+ years of experience building ML systems is required. Python and PyTorch essential. "
                    "Master's degree preferred.",
     "deadline": None, "url": "https://example.com/demo/blr-mle"},
]
