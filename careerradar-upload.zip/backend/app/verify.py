"""Deterministic verification and status transitions.

Rules (see docs/B-C-requirements-architecture.md §C3):
- network error / timeout / 5xx / 429           -> verification_unavailable; never closed
- explicit closure text or JSON-LD validThrough past -> closed_explicit / deadline_passed
- 404/410                                        -> counted; 'removed' only after 2 misses >= 24h apart
- JobPosting JSON-LD present                     -> open_verified (+ field updates, change history)
- page reachable but no structured data          -> status unchanged; last_checked updated
"""
import json
import re
from dataclasses import dataclass
from datetime import timedelta

from app.db import utcnow
from app.jobstore import IncomingJob, upsert_job
from app.models import DeadlineKind, Job, JobChange, JobStatus
from app.net import BlockedError, FetchError, SafeHttpClient
from app.normalize import parse_deadline, parse_location

CLOSED_PATTERNS = re.compile(
    r"(this (position|vacancy|job|post) (has been filled|is (now )?closed|is no longer (available|accepting))|"
    r"no longer accepting applications|applications? (are|is) (now )?closed|vacancy (has )?closed|"
    r"position (has been )?closed|recruitment (has )?closed|this advert has (now )?closed)", re.I)
REMOVE_AFTER = timedelta(hours=24)
STALE_AFTER = timedelta(days=3)
TZ_GRACE = timedelta(hours=14)  # deadline without a timezone: wait until it has passed everywhere


@dataclass
class CheckOutcome:
    kind: str  # present | closed | not_found | error | blocked | unknown
    detail: str = ""
    data: dict | None = None


def _jsonld_postings(html: str) -> list[dict]:
    out = []
    for m in re.finditer(r'<script[^>]+type=["\']application/ld\+json["\'][^>]*>(.*?)</script>', html, re.S | re.I):
        try:
            data = json.loads(m.group(1).strip())
        except json.JSONDecodeError:
            continue
        stack = data if isinstance(data, list) else [data]
        while stack:
            d = stack.pop()
            if isinstance(d, dict):
                t = d.get("@type")
                if t == "JobPosting" or (isinstance(t, list) and "JobPosting" in t):
                    out.append(d)
                stack.extend(d.get("@graph", []) if isinstance(d.get("@graph"), list) else [])
    return out


def _posting_fields(p: dict) -> dict:
    from app.connectors.base import parse_iso, strip_html
    f: dict = {}
    org = p.get("hiringOrganization")
    f["employer"] = org.get("name") if isinstance(org, dict) else (org if isinstance(org, str) else None)
    f["title"] = p.get("title")
    f["description"] = strip_html(p.get("description"))
    f["posted_date"] = parse_iso(p.get("datePosted"))
    if p.get("validThrough"):
        f.update(parse_deadline(p["validThrough"]))
    loc = p.get("jobLocation")
    loc = loc[0] if isinstance(loc, list) and loc else loc
    if isinstance(loc, dict):
        addr = loc.get("address") or {}
        if isinstance(addr, dict):
            txt = ", ".join(str(addr.get(k)) for k in ("addressLocality", "addressRegion", "addressCountry")
                            if addr.get(k) and isinstance(addr.get(k), str))
            f.update({k: v for k, v in parse_location(txt).items() if v})
    if p.get("jobLocationType") == "TELECOMMUTE":
        f["work_arrangement"] = "remote"
    sal = p.get("baseSalary")
    if isinstance(sal, dict) and isinstance(sal.get("value"), dict):
        v = sal["value"]
        f.update(salary_min=v.get("minValue") or v.get("value"), salary_max=v.get("maxValue") or v.get("value"),
                 salary_currency=sal.get("currency"), salary_period=(v.get("unitText") or "").lower() or None)
    et = p.get("employmentType")
    f["employment_type"] = ", ".join(et) if isinstance(et, list) else et
    return {k: v for k, v in f.items() if v not in (None, "")}


def check_vacancy_url(url: str, http: SafeHttpClient) -> CheckOutcome:
    try:
        r = http.get(url, {"Accept": "text/html,application/xhtml+xml"})
    except FetchError as e:
        return CheckOutcome("error", str(e))
    except BlockedError as e:
        return CheckOutcome("blocked", str(e))
    if r.status in (404, 410):
        return CheckOutcome("not_found", f"HTTP {r.status}")
    if r.status in (401, 403):
        return CheckOutcome("blocked", f"HTTP {r.status} — source refuses automated checks")
    if r.status != 200:
        return CheckOutcome("error", f"HTTP {r.status}")
    text = r.text
    visible = re.sub(r"<[^>]+>", " ", re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", text, flags=re.S | re.I))
    m = CLOSED_PATTERNS.search(visible)
    if m:
        return CheckOutcome("closed", f'Page says: "{m.group(0)}"')
    postings = _jsonld_postings(text)
    if postings:
        return CheckOutcome("present", "schema.org JobPosting found", _posting_fields(postings[0]))
    return CheckOutcome("unknown", "Page reachable but has no structured job data; status not changed")


def _log(job: Job, field: str, old, new, material=True) -> JobChange:
    return JobChange(job_id=job.id, user_id=job.user_id, field=field, old_value=None if old is None else str(old),
                     new_value=None if new is None else str(new), material=material)


def apply_outcome(db, job: Job, outcome: CheckOutcome, now=None) -> list[JobChange]:
    now = now or utcnow()
    job.last_checked_at = now
    changes: list[JobChange] = []
    old_status = job.status

    def set_status(new: str):
        if job.status != new:
            changes.append(_log(job, "status", job.status, new))
            job.status = new

    if outcome.kind == "error":
        if job.status in (JobStatus.OPEN_VERIFIED, JobStatus.STALE, JobStatus.IMPORTED_UNVERIFIED):
            set_status(JobStatus.VERIFICATION_UNAVAILABLE)
    elif outcome.kind == "blocked":
        pass  # policy refusal: keep status, the UI shows "verification unavailable for this source"
    elif outcome.kind == "closed":
        set_status(JobStatus.CLOSED_EXPLICIT)
        job.last_verified_at = now
    elif outcome.kind == "not_found":
        job.consecutive_missing += 1
        job.missing_since = job.missing_since or now
        if job.consecutive_missing >= 2 and now - job.missing_since >= REMOVE_AFTER:
            set_status(JobStatus.REMOVED)
    elif outcome.kind == "present":
        job.consecutive_missing, job.missing_since = 0, None
        data = dict(outcome.data or {})
        title, employer = data.pop("title", None) or job.title, data.pop("employer", None) or job.employer
        res = upsert_job(db, job.user_id, IncomingJob(
            title=title, employer=employer, fields={**data, "canonical_url": job.canonical_url,
                                                    "status": JobStatus.OPEN_VERIFIED,
                                                    "verification_confidence": 0.9},
            source_key="verify:jsonld", source_url=job.canonical_url or job.application_url,
            raw={"check": outcome.detail}, verified=True), now=now)
        changes += res.changes
        if res.job.id != job.id:  # should not happen: canonical URL matches
            return changes
    db.flush()
    changes += apply_deadline(job, now)
    for c in changes:
        if c not in db:
            db.add(c)
    if old_status != job.status:
        db.flush()
    return changes


def apply_deadline(job: Job, now) -> list[JobChange]:
    """Only a real closing date closes a job; review-begins/priority/open-until-filled never do."""
    if job.deadline_kind != DeadlineKind.CLOSING or not job.deadline_at:
        return []
    grace = timedelta(0) if job.deadline_tz else TZ_GRACE
    if now > job.deadline_at + grace and job.status in (JobStatus.OPEN_VERIFIED, JobStatus.STALE,
                                                         JobStatus.IMPORTED_UNVERIFIED,
                                                         JobStatus.VERIFICATION_UNAVAILABLE):
        old = job.status
        job.status = JobStatus.DEADLINE_PASSED
        return [_log(job, "status", old, job.status)]
    return []


def apply_missing_from_complete_listing(job: Job, now) -> list[JobChange]:
    """Job absent from a *complete* official listing (e.g. Greenhouse board)."""
    job.last_checked_at = now
    job.consecutive_missing += 1
    job.missing_since = job.missing_since or now
    if job.consecutive_missing >= 2 and now - job.missing_since >= REMOVE_AFTER and job.status != JobStatus.REMOVED:
        old = job.status
        job.status = JobStatus.REMOVED
        return [_log(job, "status", old, job.status)]
    return []


def apply_stale(job: Job, now) -> list[JobChange]:
    if job.status == JobStatus.OPEN_VERIFIED and job.last_verified_at and now - job.last_verified_at > STALE_AFTER:
        job.status = JobStatus.STALE
        return [_log(job, "status", JobStatus.OPEN_VERIFIED, JobStatus.STALE, material=False)]
    return []
