"""SafeHttpClient: the ONLY way CareerRadar fetches external URLs.

- http/https only, ports 80/443 only
- every hop's hostname is resolved and must be a public unicast address (blocks private, loopback,
  link-local incl. 169.254.169.254 metadata, CGNAT, multicast, reserved, IPv4-mapped IPv6)
- the peer address actually connected to is checked again before the body is read (DNS rebinding)
- redirects followed manually (max 5), each re-validated
- timeouts, response-size cap, per-domain concurrency + minimum spacing, robots.txt respected
  (robots permission is necessary, never sufficient: connectors are also gated by the source matrix)
"""
import ipaddress
import socket
import threading
import time
import urllib.robotparser
from dataclasses import dataclass, field
from urllib.parse import urljoin, urlsplit

import httpx

from app.config import get_settings

MAX_REDIRECTS = 5


class FetchError(Exception):
    """Temporary failure (network, timeout, 429, 5xx). Never evidence that a job closed."""


class BlockedError(Exception):
    """Permanent policy refusal (SSRF guard, robots.txt, protocol). Not retried."""


@dataclass
class FetchResult:
    url: str
    status: int
    body: bytes
    headers: dict = field(default_factory=dict)

    @property
    def text(self) -> str:
        return self.body.decode("utf-8", errors="replace")


def is_public_ip(ip: str) -> bool:
    addr = ipaddress.ip_address(ip)
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        addr = addr.ipv4_mapped
    return addr.is_global and not (addr.is_multicast or addr.is_reserved or addr.is_loopback
                                   or addr.is_link_local or addr.is_private or addr.is_unspecified)


def check_url(url: str, resolver=socket.getaddrinfo) -> None:
    parts = urlsplit(url)
    if parts.scheme not in ("http", "https"):
        raise BlockedError(f"protocol not allowed: {parts.scheme or '(none)'}")
    if parts.username or parts.password:
        raise BlockedError("credentials in URL not allowed")
    host = parts.hostname
    if not host:
        raise BlockedError("URL has no host")
    port = parts.port or (443 if parts.scheme == "https" else 80)
    if port not in (80, 443):
        raise BlockedError(f"port {port} not allowed")
    try:
        infos = resolver(host, port, proto=socket.IPPROTO_TCP)
    except socket.gaierror as e:
        raise FetchError(f"DNS lookup failed for {host}") from e
    ips = {i[4][0] for i in infos}
    if not ips or not all(is_public_ip(ip) for ip in ips):
        raise BlockedError(f"{host} resolves to a non-public address")


class _DomainGate:
    def __init__(self) -> None:
        self._locks: dict[str, threading.Semaphore] = {}
        self._last: dict[str, float] = {}
        self._mu = threading.Lock()

    def acquire(self, host: str, min_interval: float) -> threading.Semaphore:
        with self._mu:
            sem = self._locks.setdefault(host, threading.Semaphore(get_settings().per_domain_concurrency))
        sem.acquire()
        wait = self._last.get(host, 0) + min_interval - time.monotonic()
        if wait > 0:
            time.sleep(min(wait, 30))
        return sem

    def release(self, host: str, sem: threading.Semaphore) -> None:
        self._last[host] = time.monotonic()
        sem.release()


_gate = _DomainGate()
_robots: dict[str, tuple[float, urllib.robotparser.RobotFileParser | None]] = {}


class SafeHttpClient:
    def __init__(self, transport: httpx.BaseTransport | None = None, resolver=socket.getaddrinfo,
                 check_peer: bool = True, respect_robots: bool = True) -> None:
        s = get_settings()
        self.s = s
        self.resolver = resolver
        self.check_peer = check_peer
        self.respect_robots = respect_robots
        self.client = httpx.Client(transport=transport, timeout=s.http_timeout_s, follow_redirects=False,
                                   headers={"User-Agent": s.http_user_agent, "Accept-Encoding": "gzip"})

    def _robots_allowed(self, url: str) -> tuple[bool, float]:
        parts = urlsplit(url)
        base = f"{parts.scheme}://{parts.netloc}"
        cached = _robots.get(base)
        if not cached or time.time() - cached[0] > 86400:
            rp = urllib.robotparser.RobotFileParser()
            try:
                r = self._raw_get(base + "/robots.txt", {}, robots=False)
                if r.status == 200:
                    rp.parse(r.text.splitlines())
                elif r.status in (401, 403):
                    rp.parse(["User-agent: *", "Disallow: /"])
                else:
                    rp.parse([])  # no robots.txt → no robots restriction (other gates still apply)
            except FetchError:
                rp = None
            cached = (time.time(), rp)
            _robots[base] = cached
        rp = cached[1]
        if rp is None:
            raise FetchError("robots.txt unreachable; not fetching")
        delay = rp.crawl_delay(self.s.http_user_agent) or 1.0
        return rp.can_fetch(self.s.http_user_agent, url), float(delay)

    def get(self, url: str, headers: dict | None = None) -> FetchResult:
        delay = 1.0
        if self.respect_robots:
            allowed, delay = self._robots_allowed(url)
            if not allowed:
                raise BlockedError("robots.txt disallows this URL")
        host = urlsplit(url).hostname or ""
        sem = _gate.acquire(host, delay)
        try:
            return self._raw_get(url, headers or {}, robots=self.respect_robots)
        finally:
            _gate.release(host, sem)

    def _raw_get(self, url: str, headers: dict, robots: bool) -> FetchResult:
        for _ in range(MAX_REDIRECTS + 1):
            check_url(url, self.resolver)
            try:
                with self.client.stream("GET", url, headers=headers) as r:
                    if self.check_peer:
                        stream = r.extensions.get("network_stream")
                        peer = stream.get_extra_info("server_addr") if stream else None
                        if peer and not is_public_ip(peer[0]):
                            raise BlockedError("connected to a non-public address")
                    if r.status_code in (301, 302, 303, 307, 308):
                        loc = r.headers.get("location")
                        if not loc:
                            raise FetchError("redirect without location")
                        url = urljoin(url, loc)
                        if robots and self.respect_robots and not self._robots_allowed(url)[0]:
                            raise BlockedError("redirect target disallowed by robots.txt")
                        continue
                    body = bytearray()
                    for chunk in r.iter_bytes():
                        body += chunk
                        if len(body) > self.s.http_max_bytes:
                            raise BlockedError("response too large")
                    if r.status_code == 429 or r.status_code >= 500:
                        raise FetchError(f"HTTP {r.status_code}")
                    return FetchResult(str(r.url), r.status_code, bytes(body), dict(r.headers))
            except httpx.TimeoutException as e:
                raise FetchError("timeout") from e
            except httpx.TransportError as e:
                raise FetchError(f"network error: {type(e).__name__}") from e
        raise FetchError("too many redirects")
