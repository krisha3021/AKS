"""Validated, encrypted storage of user uploads."""
import hashlib

from fastapi import HTTPException, UploadFile
from sqlalchemy.orm import Session

from app.config import get_settings
from app.models import Document
from app.security import store_file

ALLOWED = {
    "cv": {".pdf": b"%PDF-", ".docx": b"PK\x03\x04"},
    "job_list": {".csv": None, ".xlsx": b"PK\x03\x04"},
    "supporting": {".pdf": b"%PDF-", ".docx": b"PK\x03\x04"},
}
MIME = {".pdf": "application/pdf", ".csv": "text/csv",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"}


async def read_upload(file: UploadFile, kind: str) -> tuple[bytes, str]:
    name = (file.filename or "upload").replace("\\", "/").rsplit("/", 1)[-1][:200]
    ext = "." + name.rsplit(".", 1)[-1].lower() if "." in name else ""
    if ext not in ALLOWED[kind]:
        raise HTTPException(415, f"File type {ext or '(none)'} not allowed here. Allowed: {', '.join(ALLOWED[kind])}")
    limit = get_settings().max_upload_mb * 1024 * 1024
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, f"File too large (max {get_settings().max_upload_mb} MB)")
    if not data:
        raise HTTPException(422, "File is empty")
    magic = ALLOWED[kind][ext]
    if magic and not data.startswith(magic):
        raise HTTPException(415, f"File content does not match its {ext} extension")
    # Malware scanning hook: plug ClamAV (clamd INSTREAM) here in deployments that have it.
    return data, name


def save_document(db: Session, user_id: str, kind: str, name: str, data: bytes) -> Document:
    ext = "." + name.rsplit(".", 1)[-1].lower()
    doc = Document(user_id=user_id, kind=kind, filename=name, mime=MIME.get(ext, "application/octet-stream"),
                   size_bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                   storage_key=store_file(data, user_id))
    db.add(doc)
    db.flush()
    return doc
