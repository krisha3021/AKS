import logging
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from sqlalchemy import text

from app import routers
from app.config import get_settings
from app.db import SessionLocal
from app.deps import CSRF_HEADER
from app.logging_setup import incr, setup_logging, snapshot

log = logging.getLogger("careerradar")
UNSAFE = {"POST", "PUT", "PATCH", "DELETE"}
FRONTEND_DIST = Path(__file__).resolve().parents[2] / "frontend" / "dist"


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    worker = None
    if get_settings().run_worker_in_process:
        from app.worker import BackgroundWorker
        worker = BackgroundWorker()
        worker.start()
    yield
    if worker:
        worker.stop()


DEV_KEY = "ZGV2LW9ubHktZGV2LW9ubHktZGV2LW9ubHktMzJieXQ="


def create_app() -> FastAPI:
    s = get_settings()
    if s.env != "dev" and (s.encryption_key == DEV_KEY or not s.cookie_secure):
        raise RuntimeError("Refusing to start: set CR_ENCRYPTION_KEY and CR_COOKIE_SECURE=true outside dev")
    app = FastAPI(title="CareerRadar API", version="0.1.0", lifespan=lifespan)
    app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_credentials=True,
                       allow_methods=["*"], allow_headers=["*"])

    @app.middleware("http")
    async def csrf_and_logging(request: Request, call_next):
        # Custom header cannot be set cross-site without a CORS preflight, which we restrict.
        if request.method in UNSAFE and request.url.path.startswith("/api/") \
                and request.headers.get(CSRF_HEADER) != "1":
            return JSONResponse({"detail": "Missing CSRF header"}, status_code=403)
        t0 = time.perf_counter()
        response = await call_next(request)
        incr(f"http_{response.status_code // 100}xx")
        log.info("request", extra={"path": request.url.path, "status": response.status_code,
                                   "duration_ms": round((time.perf_counter() - t0) * 1000, 1)})
        return response

    @app.get("/api/health/live")
    def live():
        return {"status": "ok"}

    @app.get("/api/health/ready")
    def ready():
        with SessionLocal() as db:
            db.execute(text("SELECT 1"))
        return {"status": "ok", "database": "ok"}

    @app.get("/api/metrics")
    def metrics(request: Request):
        # Public in dev; elsewhere only with the operator secret (Authorization: Bearer <CRON_SECRET>).
        if s.env != "dev":
            import hmac
            auth = request.headers.get("authorization") or ""
            if not s.cron_secret or not hmac.compare_digest(auth, f"Bearer {s.cron_secret}"):
                return JSONResponse({"detail": "Not found"}, status_code=404)
        return snapshot()

    for r in routers.ALL:
        app.include_router(r)

    if FRONTEND_DIST.exists():
        @app.get("/{path:path}", include_in_schema=False)
        def spa(path: str):
            f = (FRONTEND_DIST / path).resolve()
            if path and f.is_file() and FRONTEND_DIST in f.parents:
                return FileResponse(f)
            return FileResponse(FRONTEND_DIST / "index.html")

    return app


app = create_app()
