"""Safe text extraction from PDF/DOCX. Output is plain text with page boundaries, so every
extracted field can point back to (page, char offset) evidence."""
import io
from dataclasses import dataclass

from docx import Document as DocxDocument
from pypdf import PdfReader

MAX_PAGES = 40
MAX_CHARS = 200_000


@dataclass
class CvText:
    text: str
    page_starts: list[int]  # char offset where each page begins

    def page_of(self, offset: int) -> int:
        page = 1
        for i, start in enumerate(self.page_starts):
            if offset >= start:
                page = i + 1
        return page


class CvParseError(ValueError):
    pass


def extract_text(data: bytes, filename: str) -> CvText:
    name = filename.lower()
    if name.endswith(".pdf"):
        return _pdf(data)
    if name.endswith(".docx"):
        return _docx(data)
    raise CvParseError("Only PDF and DOCX CVs are supported")


def _pdf(data: bytes) -> CvText:
    try:
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise CvParseError("PDF is password-protected; upload an unlocked copy")
        pages = reader.pages[:MAX_PAGES]  # never execute JavaScript/actions; text only
        parts, starts, pos = [], [], 0
        for p in pages:
            t = (p.extract_text() or "").replace("\x00", "")
            starts.append(pos)
            parts.append(t)
            pos += len(t) + 2
    except CvParseError:
        raise
    except Exception as e:  # malformed PDFs raise many exception types
        raise CvParseError(f"Could not read PDF: {type(e).__name__}") from None
    text = "\n\n".join(parts)[:MAX_CHARS]
    if len(text.strip()) < 50:
        raise CvParseError("No selectable text found (scanned PDF?). OCR is not supported yet.")
    return CvText(text, starts)


def _docx(data: bytes) -> CvText:
    try:
        doc = DocxDocument(io.BytesIO(data))
    except Exception as e:
        raise CvParseError(f"Could not read DOCX: {type(e).__name__}") from None
    lines = [p.text for p in doc.paragraphs]
    for table in doc.tables:
        for row in table.rows:
            lines.append(" | ".join(c.text.strip() for c in row.cells))
    text = "\n".join(lines)[:MAX_CHARS]
    if len(text.strip()) < 50:
        raise CvParseError("Document contains almost no text")
    return CvText(text, [0])
