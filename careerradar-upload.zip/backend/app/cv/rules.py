"""Deterministic CV extractor. Only records what is explicitly present, each with an evidence span.

Confidence is a heuristic: 0.9 for an exact pattern match in the right section, 0.6 for a match
outside its expected section, 0.4 for loose list items. Users confirm or correct every field.
"""
import re
import uuid
from datetime import date

from app.cv.text import CvText

SECTIONS = {
    "education": r"education|academic qualifications?|qualifications?|degrees?",
    "experience": r"(professional |work |employment |academic |teaching |research )?(experience|employment|appointments?|positions? held|career history)",
    "skills": r"(technical |key )?skills|competenc(e|ies)|tools( and technologies)?|technical expertise",
    "research": r"research interests?|areas? of (research|interest)|research areas?",
    "teaching": r"teaching( interests| areas| experience)?|courses taught|subjects taught",
    "publications": r"(selected |journal |conference )?publications?|papers|journal articles",
    "patents": r"patents?",
    "grants": r"grants?|funding|funded projects|research projects|sponsored projects",
    "projects": r"projects?",
    "supervision": r"(student |phd |research )?supervision|students supervised|mentoring",
    "awards": r"awards?|honou?rs|achievements",
}
HEADING_RE = {k: re.compile(rf"^\s*(?:\d+[.)]\s*)?(?:{v})\s*:?\s*$", re.I) for k, v in SECTIONS.items()}

DEGREES = [
    ("doctorate", r"\bPh\.?\s?D\.?\b|\bDoctor of Philosophy\b|\bD\.?Phil\b|\bDSc\b"),
    ("masters", r"\bM\.?\s?Tech\b|\bM\.E\.|\bM\.?Sc\b|\bM\.S\.|\bMaster(?:'s)? of\b|\bMBA\b|\bMCA\b|\bM\.?Phil\b"),
    ("bachelors", r"\bB\.?\s?Tech\b|\bB\.E\.|\bB\.?Sc\b|\bBachelor(?:'s)? of\b|\bBCA\b|\bB\.?S\.\b"),
]
RANKS = [
    ("professor", r"(?<!assistant )(?<!associate )\bprofessor\b"),
    ("associate_professor", r"\bassociate professor\b"),
    ("assistant_professor", r"\bassistant professor\b"),
    ("lecturer", r"\b(senior )?lecturer\b"),
    ("postdoc", r"\bpost-?doc(toral)?\b"),
    ("research_scientist", r"\bresearch (scientist|fellow|associate)\b"),
]
MONTHS = {m: i + 1 for i, m in enumerate(
    ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"])}
DATE_TOK = r"(?:(?:jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*\.?\s+\d{4}|\d{1,2}/\d{4}|\d{4})"
END_TOK = rf"(?:{DATE_TOK}|present|current|now|till date|to date|ongoing)"
RANGE_RE = re.compile(rf"(?P<start>{DATE_TOK})\s*(?:-|–|—|to|until)\s*(?P<end>{END_TOK})", re.I)
YEAR_RE = re.compile(r"\b(19[5-9]\d|20[0-4]\d)\b")


def _fid() -> str:
    return uuid.uuid4().hex[:12]


def _ev(cv: CvText, doc_id: str, start: int, end: int) -> dict:
    return {"document_id": doc_id, "page": cv.page_of(start), "start": start, "end": end,
            "quote": cv.text[start:end].strip()[:300]}


def _field(kind: str, value, cv: CvText, doc_id: str, start: int, end: int, conf: float, flags=None) -> dict:
    return {"id": _fid(), "kind": kind, "value": value, "confidence": conf, "origin": "rules",
            "evidence": [_ev(cv, doc_id, start, end)], "flags": flags or [], "confirmed": False}


def split_sections(cv: CvText) -> list[tuple[str, int, int]]:
    """Returns (section, start, end) char ranges. Text before the first heading is 'header'."""
    marks = [("header", 0)]
    pos = 0
    for line in cv.text.splitlines(keepends=True):
        stripped = line.strip()
        if 2 < len(stripped) < 60:
            for name, rx in HEADING_RE.items():
                if rx.match(stripped):
                    marks.append((name, pos))
                    break
        pos += len(line)
    out = []
    for i, (name, start) in enumerate(marks):
        end = marks[i + 1][1] if i + 1 < len(marks) else len(cv.text)
        out.append((name, start, end))
    return out


def _lines(cv: CvText, start: int, end: int):
    pos = start
    for line in cv.text[start:end].splitlines(keepends=True):
        s = line.strip()
        if s:
            off = pos + line.index(s[0])
            yield s, off, off + len(s)
        pos += len(line)


def _parse_point(tok: str, is_end: bool, today: date) -> tuple[date | None, str]:
    """Returns (date, granularity). Year-only dates are flagged by the caller, never silently exact."""
    t = tok.strip().lower().rstrip(".")
    if t in {"present", "current", "now", "till date", "to date", "ongoing"}:
        return today, "present"
    m = re.match(r"([a-z]+)\.?\s+(\d{4})", t)
    if m and m.group(1)[:3] in MONTHS:
        return date(int(m.group(2)), MONTHS[m.group(1)[:3]], 1), "month"
    m = re.match(r"(\d{1,2})/(\d{4})", t)
    if m and 1 <= int(m.group(1)) <= 12:
        return date(int(m.group(2)), int(m.group(1)), 1), "month"
    if re.fullmatch(r"\d{4}", t):
        return date(int(t), 12 if is_end else 1, 1), "year"
    return None, "unknown"


def classify_rank(text: str) -> str | None:
    low = text.lower()
    for rank, rx in RANKS[1:3]:  # check associate/assistant before plain professor
        if re.search(rx, low):
            return rank
    for rank, rx in [RANKS[0], *RANKS[3:]]:
        if re.search(rx, low):
            return rank
    return None


def extract(cv: CvText, doc_id: str, today: date | None = None) -> list[dict]:
    today = today or date.today()
    fields: list[dict] = []
    sections = split_sections(cv)
    by_name: dict[str, list[tuple[int, int]]] = {}
    for name, s, e in sections:
        by_name.setdefault(name, []).append((s, e))

    def in_section(off: int, name: str) -> bool:
        return any(s <= off < e for s, e in by_name.get(name, []))

    # Degrees — anywhere, higher confidence inside Education.
    seen_deg = set()
    for level, rx in DEGREES:
        for m in re.finditer(rx, cv.text, re.I):
            line_start = cv.text.rfind("\n", 0, m.start()) + 1
            line_end = cv.text.find("\n", m.end())
            line_end = len(cv.text) if line_end == -1 else line_end
            line = cv.text[line_start:line_end].strip()
            if (level, line) in seen_deg or len(line) > 250:
                continue
            seen_deg.add((level, line))
            years = YEAR_RE.findall(line)
            inst = re.search(r"([A-Z][\w.&'\- ]*(University|Institute|College|School|IIT|NIT|IISc)[\w.&'\-, ]*)", line)
            in_edu = in_section(m.start(), "education")
            fields.append(_field("degree", {"level": level, "text": line, "year": years[-1] if years else None,
                                            "institution": inst.group(1).strip(" ,") if inst else None},
                                 cv, doc_id, line_start, line_end, 0.9 if in_edu else 0.6,
                                 [] if in_edu else ["found outside an Education section — please confirm"]))

    # Employment — date ranges inside experience-like sections.
    for name in ("experience", "header", "teaching", "research"):
        for s, e in by_name.get(name, []):
            for line, ls, le in _lines(cv, s, e):
                m = RANGE_RE.search(line)
                if not m:
                    continue
                start_d, g1 = _parse_point(m.group("start"), False, today)
                end_d, g2 = _parse_point(m.group("end"), True, today)
                flags = []
                if not start_d or not end_d:
                    flags.append("could not parse dates — please enter them")
                if "year" in (g1, g2):
                    flags.append("year-only date; months unknown, experience may be over-counted")
                if start_d and end_d and end_d < start_d:
                    flags.append("end date before start date")
                role = RANGE_RE.sub("", line).strip(" ,|–-:()")
                fields.append(_field("employment", {
                    "text": role, "rank": classify_rank(role), "start": start_d.isoformat() if start_d else None,
                    "end": end_d.isoformat() if end_d else None, "current": g2 == "present"},
                    cv, doc_id, ls, le, 0.85 if name == "experience" and not flags else 0.6, flags))

    # Lists: skills, research interests, teaching areas.
    for section, kind in (("skills", "skill"), ("research", "research_interest"), ("teaching", "teaching_area")):
        for s, e in by_name.get(section, [])[:1]:
            body_start = cv.text.find("\n", s) + 1
            for line, ls, _ in _lines(cv, body_start, e):
                if RANGE_RE.search(line):
                    continue
                line_body = re.sub(r"^[•\-\*–·▪]\s*", "", line)
                label = re.match(r"^[A-Za-z /&]{2,30}:\s*", line_body)
                items = line_body[label.end():] if label else line_body
                for item in re.split(r"[,;|•·]", items):
                    item = item.strip(" .")
                    if 1 < len(item) <= 60:
                        off = cv.text.find(item, ls)
                        fields.append(_field(kind, item, cv, doc_id, off, off + len(item), 0.75))

    # Countable research outputs — only from their own explicit sections.
    for section, kind in (("publications", "publication"), ("patents", "patent"), ("grants", "grant"),
                          ("supervision", "supervision"), ("projects", "project")):
        for s, e in by_name.get(section, []):
            body_start = cv.text.find("\n", s) + 1
            for line, ls, le in _lines(cv, body_start, e):
                if len(line) < 25 and kind == "publication":
                    continue
                fields.append(_field(kind, re.sub(r"^\[?\d+[.)\]]\s*", "", line)[:400], cv, doc_id, ls, le,
                                     0.7 if (kind != "publication" or YEAR_RE.search(line)) else 0.5))
    return fields
