"""Experience totals from employment fields: overlapping periods are merged, never double-counted."""
from datetime import date


def _months(d: date) -> int:
    return d.year * 12 + d.month - 1


def experience_summary(fields: list[dict]) -> dict:
    spans, ambiguous, academic_spans = [], [], []
    for f in fields:
        if f["kind"] != "employment" or f.get("rejected"):
            continue
        v = f["value"]
        if not v.get("start") or not v.get("end"):
            ambiguous.append(f["id"])
            continue
        s, e = _months(date.fromisoformat(v["start"])), _months(date.fromisoformat(v["end"])) + 1
        if e <= s:
            ambiguous.append(f["id"])
            continue
        if f.get("flags"):
            ambiguous.append(f["id"])
        spans.append((s, e))
        if v.get("rank"):
            academic_spans.append((s, e))

    def merged_total(items):
        total, cur_s, cur_e = 0, None, None
        for s, e in sorted(items):
            if cur_e is None or s > cur_e:
                if cur_e is not None:
                    total += cur_e - cur_s
                cur_s, cur_e = s, e
            else:
                cur_e = max(cur_e, e)
        if cur_e is not None:
            total += cur_e - cur_s
        return total

    raw_sum = sum(e - s for s, e in spans)
    total = merged_total(spans)
    return {"total_months": total, "total_years": round(total / 12, 1),
            "academic_months": merged_total(academic_spans),
            "overlap_months_removed": raw_sum - total,
            "ambiguous_field_ids": ambiguous}
