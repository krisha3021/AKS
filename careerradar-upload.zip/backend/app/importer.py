"""CSV/XLSX job-list import. Spreadsheet rows are *leads*: never marked verified or open.

Safety: files are parsed as data only. XLSX formulas are never evaluated (openpyxl reads the
formula text, which we reject), macros are never loaded, and zip bombs are refused.
"""
import csv
import io
import zipfile
from dataclasses import dataclass

from openpyxl import load_workbook

from app.normalize import clean, infer_scope, parse_date, parse_deadline, parse_location, validate_url

FIELDS = ["scope", "title", "organisation", "department", "location", "url", "application_url", "source",
          "posted_date", "deadline", "status", "notes", "discipline", "employment_type", "salary"]

ALIASES = {
    "scope": "scope", "region_scope": "scope",
    "title": "title", "job_title": "title", "position": "title", "role": "title", "job": "title",
    "organisation": "organisation", "organization": "organisation", "employer": "organisation",
    "company": "organisation", "institution": "organisation", "university": "organisation",
    "department": "department", "dept": "department", "school": "department",
    "location": "location", "city": "location", "place": "location",
    "url": "url", "link": "url", "job_url": "url", "vacancy_url": "url", "listing_url": "url",
    "application_url": "application_url", "apply_url": "application_url", "apply_link": "application_url",
    "source": "source", "board": "source", "site": "source",
    "posted_date": "posted_date", "posted": "posted_date", "date_posted": "posted_date",
    "deadline": "deadline", "closing_date": "deadline", "close_date": "deadline", "last_date": "deadline",
    "apply_by": "deadline",
    "status": "status", "notes": "notes", "comment": "notes", "comments": "notes",
    "discipline": "discipline", "subject": "discipline", "field": "discipline",
    "employment_type": "employment_type", "type": "employment_type", "salary": "salary",
}

MAX_UNCOMPRESSED = 50 * 1024 * 1024
FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")


class ImportFileError(ValueError):
    pass


@dataclass
class Table:
    headers: list[str]
    rows: list[dict[str, str | None]]  # header -> raw string
    formula_cells: set[tuple[int, str]]  # (row_number, header) for XLSX formulas


def _key(h: str) -> str:
    return "_".join(str(h or "").strip().lower().replace("-", " ").split())


def suggest_mapping(headers: list[str]) -> dict[str, str | None]:
    out, used = {}, set()
    for h in headers:
        f = ALIASES.get(_key(h))
        out[h] = f if f and f not in used else None
        if f:
            used.add(f)
    return out


def read_table(data: bytes, filename: str, max_rows: int) -> Table:
    name = filename.lower()
    if name.endswith((".xlsm", ".xls", ".xlsb")):
        raise ImportFileError("Macro-enabled or legacy Excel files are not accepted. Save as .xlsx or .csv.")
    if name.endswith(".xlsx"):
        return _read_xlsx(data, max_rows)
    if name.endswith(".csv"):
        return _read_csv(data, max_rows)
    raise ImportFileError("Unsupported file type. Upload .csv or .xlsx.")


def _read_csv(data: bytes, max_rows: int) -> Table:
    if b"\x00" in data[:4096]:
        raise ImportFileError("File looks binary, not CSV.")
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ImportFileError("Could not decode CSV (expected UTF-8).")
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    reader = csv.reader(io.StringIO(text), dialect)
    try:
        headers = [h.strip() for h in next(reader)]
    except StopIteration:
        raise ImportFileError("File is empty.") from None
    if not any(headers):
        raise ImportFileError("First row must contain column headers.")
    rows = []
    for i, r in enumerate(reader):
        if i >= max_rows:
            raise ImportFileError(f"Too many rows (limit {max_rows}).")
        if not any(c.strip() for c in r):
            continue
        rows.append({h: (r[j] if j < len(r) else None) for j, h in enumerate(headers)})
    return Table(headers, rows, set())


def _read_xlsx(data: bytes, max_rows: int) -> Table:
    if not data.startswith(b"PK\x03\x04"):
        raise ImportFileError("Not a valid .xlsx file.")
    try:
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if sum(i.file_size for i in z.infolist()) > MAX_UNCOMPRESSED:
                raise ImportFileError("Spreadsheet expands too large; refusing to open.")
            if any(n.lower().endswith("vbaproject.bin") for n in z.namelist()):
                raise ImportFileError("Workbook contains macros; save as a plain .xlsx.")
    except zipfile.BadZipFile:
        raise ImportFileError("Not a valid .xlsx file.") from None
    # data_only=False: we get formula *text* and can refuse it; nothing is ever calculated.
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=False, keep_vba=False, keep_links=False)
    ws = wb.worksheets[0]
    it = ws.iter_rows(values_only=False)
    try:
        header_cells = next(it)
    except StopIteration:
        raise ImportFileError("Sheet is empty.") from None
    headers = [str(c.value).strip() if c.value is not None else f"column_{i+1}" for i, c in enumerate(header_cells)]
    rows, formulas = [], set()
    for i, cells in enumerate(it):
        if i >= max_rows:
            raise ImportFileError(f"Too many rows (limit {max_rows}).")
        row = {}
        for j, h in enumerate(headers):
            c = cells[j] if j < len(cells) else None
            v = None if c is None else c.value
            if c is not None and c.data_type == "f":
                formulas.add((i + 2, h))
            row[h] = None if v is None else (v.isoformat() if hasattr(v, "isoformat") else str(v))
        if any(v not in (None, "") for v in row.values()):
            rows.append(row)
    wb.close()
    return Table(headers, rows, formulas)


def map_row(raw: dict, mapping: dict[str, str | None], row_number: int,
            formula_cells: set[tuple[int, str]]) -> tuple[dict | None, list[str]]:
    """Returns (normalised fields, errors). Errors make the row fail; other rows still import."""
    errors: list[str] = []
    m: dict[str, str | None] = {}
    for header, target in mapping.items():
        if not target:
            continue
        if (row_number, header) in formula_cells:
            errors.append(f"'{header}' contains a formula; formulas are not evaluated — paste values instead")
            continue
        m[target] = clean(raw.get(header))

    title = m.get("title")
    if not title:
        errors.append("missing required 'title'")
    if not m.get("organisation") and not m.get("url"):
        errors.append("need at least 'organisation' or 'url' to identify the vacancy")
    for f in ("url", "application_url"):
        err = validate_url(m.get(f))
        if err:
            errors.append(f"{f}: {err}")
    fields: dict = {}
    if m.get("posted_date"):
        try:
            fields["posted_date"] = parse_date(m["posted_date"])
        except ValueError as e:
            errors.append(f"posted_date: {e}")
    if m.get("deadline"):
        fields.update(parse_deadline(m["deadline"]))
    scope = (m.get("scope") or "").lower() or None
    if scope and scope not in {"national", "international"}:
        errors.append(f"scope must be 'national' or 'international' (got '{m['scope']}')")
    if errors:
        return None, errors

    loc = parse_location(m.get("location"))
    fields.update({k: v for k, v in loc.items() if v})
    fields["scope"] = scope or infer_scope(loc["country"])
    for src, dst in (("department", "department"), ("discipline", "discipline"),
                     ("employment_type", "employment_type")):
        if m.get(src):
            fields[dst] = m[src]
    if m.get("url"):
        fields["canonical_url"] = m["url"]
    if m.get("application_url") or m.get("url"):
        fields["application_url"] = m.get("application_url") or m.get("url")
    if m.get("notes") or m.get("salary"):
        fields["description"] = "\n".join(filter(None, [m.get("salary") and f"Salary (as imported): {m['salary']}",
                                                        m.get("notes") and f"Imported notes: {m['notes']}"]))
    return {"title": title, "employer": m.get("organisation"), "fields": fields,
            "source_name": m.get("source"), "status_claimed": m.get("status"), "url": m.get("url")}, []


def csv_safe(value) -> str:
    """Neutralise spreadsheet formula injection in exported cells (OWASP guidance)."""
    s = "" if value is None else str(value)
    return "'" + s if s.startswith(FORMULA_PREFIXES) else s
