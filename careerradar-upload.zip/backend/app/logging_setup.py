"""JSON structured logs + simple in-process counters exposed at /api/metrics."""
import json
import logging
import sys
import threading
from collections import Counter

_metrics: Counter[str] = Counter()
_lock = threading.Lock()


def incr(name: str, n: int = 1) -> None:
    with _lock:
        _metrics[name] += n


def snapshot() -> dict[str, int]:
    with _lock:
        return dict(_metrics)


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {"ts": self.formatTime(record), "level": record.levelname, "logger": record.name,
                   "msg": record.getMessage()}
        for k in ("user_id", "task", "source", "status", "duration_ms", "path"):
            if hasattr(record, k):
                payload[k] = getattr(record, k)
        if record.exc_info:
            payload["exc"] = self.formatException(record.exc_info)
        return json.dumps(payload, default=str)


def setup_logging() -> None:
    h = logging.StreamHandler(sys.stdout)
    h.setFormatter(JsonFormatter())
    root = logging.getLogger()
    root.handlers[:] = [h]
    root.setLevel(logging.INFO)
