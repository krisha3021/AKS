"""Background-work triggers for serverless hosting (Vercel), plus the public runtime config.

- POST /api/tick         signed-in user's dashboard calls this while open: schedules the user's due
                          sources and runs their tasks for up to ~20 s.
- GET  /api/cron/daily   Vercel Cron (Bearer CRON_SECRET): schedules everything, sweeps, retention.
- POST /api/admin/migrate (Bearer CRON_SECRET): applies Alembic migrations to the configured DB.
"""
import hmac
import logging
from pathlib import Path

from fastapi import APIRouter, Depends, Header, HTTPException
from sqlalchemy.orm import Session

from app import pipeline  # noqa: F401  (registers task handlers)
from app.config import get_settings
from app.db import SessionLocal, get_db
from app.deps import current_user, rate_limit
from app.models import User
from app.tasks import drain, recover_stuck

router = APIRouter(prefix="/api", tags=["ops"])
log = logging.getLogger("careerradar.ops")


@router.get("/config")
def runtime_config():
    s = get_settings()
    return {"live_updates": s.live_updates, "poll_seconds": s.poll_seconds,
            "background": "in-process worker" if s.run_worker_in_process else
            "runs while the app is open, and at least once a day"}


@router.post("/tick", dependencies=[Depends(rate_limit("tick", 4, 2))])
def tick(user: User = Depends(current_user), db: Session = Depends(get_db)):
    pipeline.schedule_due(db, user_id=user.id)
    ran = drain(max_tasks=25, time_budget_s=20, user_id=user.id)
    return {"ran": ran}


def _check_secret(authorization: str | None) -> None:
    secret = get_settings().cron_secret
    if not secret or not authorization or not hmac.compare_digest(authorization, f"Bearer {secret}"):
        raise HTTPException(401, "Unauthorized")


@router.get("/cron/daily")
def cron_daily(authorization: str | None = Header(None)):
    _check_secret(authorization)
    with SessionLocal() as db:
        recovered = recover_stuck(db)
        pipeline.schedule_due(db)
    ran = drain(max_tasks=500, time_budget_s=240)
    log.info("daily cron", extra={"status": f"ran={ran} recovered={recovered}"})
    return {"ran": ran, "recovered": recovered}


@router.post("/admin/migrate")
def migrate(authorization: str | None = Header(None)):
    _check_secret(authorization)
    from alembic import command
    from alembic.config import Config
    backend = Path(__file__).resolve().parents[2]
    cfg = Config(str(backend / "alembic.ini"))
    cfg.set_main_option("script_location", str(backend / "migrations"))
    cfg.set_main_option("sqlalchemy.url", get_settings().database_url.replace("%", "%%"))
    command.upgrade(cfg, "head")
    return {"migrated": True}
