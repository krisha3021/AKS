import hashlib
import hmac
import time
import uuid
from typing import Any, Literal

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.cv import llm
from app.cv.experience import experience_summary
from app.cv.rules import extract as rules_extract
from app.cv.text import CvParseError, CvText, extract_text
from app.db import get_db
from app.deps import audit, current_user, rate_limit
from app.models import Document, Profile, User
from app.security import decrypt, delete_file, encrypt, load_file
from app.uploads import read_upload, save_document

router = APIRouter(prefix="/api", tags=["profile"])


class Preferences(BaseModel):
    home_country: str = "India"
    academic_mode: bool = False
    target_titles: list[str] = []
    title_synonyms: list[str] = []
    countries: list[str] = []
    cities: list[str] = []
    work_arrangements: list[Literal["remote", "hybrid", "onsite"]] = []
    salary_min: float | None = None
    salary_currency: str | None = Field(None, min_length=3, max_length=3)
    employment_types: list[str] = []
    appointment_types: list[str] = []
    disciplines: list[str] = []
    research_areas: list[str] = []
    needs_visa_sponsorship: bool | None = None
    open_to_relocation: bool | None = None
    excluded_employers: list[str] = []
    excluded_locations: list[str] = []
    excluded_keywords: list[str] = []
    alert_frequency: Literal["instant", "daily", "weekly", "off"] = "daily"
    languages: list[str] = ["English"]


class ProfileOut(BaseModel):
    fields: list[dict]
    preferences: Preferences
    experience: dict
    version: int
    documents: list[dict]
    extraction_notes: list[str] = []


class FieldPatch(BaseModel):
    value: Any | None = None
    confirmed: bool | None = None
    rejected: bool | None = None


class NewField(BaseModel):
    kind: Literal["degree", "employment", "skill", "research_interest", "teaching_area", "publication",
                  "patent", "grant", "project", "supervision", "academic_rank"]
    value: Any


def get_profile(db: Session, user_id: str) -> Profile:
    p = db.get(Profile, user_id)
    if not p:
        p = Profile(user_id=user_id, fields=[], preferences=Preferences().model_dump(), version=1)
        db.add(p)
        db.flush()
    return p


def _out(db: Session, p: Profile, notes: list[str] | None = None) -> ProfileOut:
    docs = db.scalars(select(Document).where(Document.user_id == p.user_id, Document.kind != "job_list")
                      .order_by(Document.created_at.desc()))
    return ProfileOut(fields=p.fields, preferences=Preferences(**p.preferences),
                      experience=experience_summary(p.fields), version=p.version,
                      documents=[{"id": d.id, "kind": d.kind, "filename": d.filename, "size_bytes": d.size_bytes,
                                  "created_at": d.created_at.isoformat()} for d in docs],
                      extraction_notes=notes or [])


def _bump(p: Profile, fields: list[dict]) -> None:
    p.fields = fields  # reassign so SQLAlchemy sees the JSON change
    p.version += 1


@router.get("/profile", response_model=ProfileOut)
def read_profile(user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_profile(db, user.id)
    db.commit()
    return _out(db, p)


@router.post("/profile/cv", response_model=ProfileOut, dependencies=[Depends(rate_limit("upload", 20, 10))])
async def upload_cv(file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    data, name = await read_upload(file, "cv")
    try:
        cv = extract_text(data, name)
    except CvParseError as e:
        raise HTTPException(422, str(e)) from None
    doc = save_document(db, user.id, "cv", name, data)
    doc.text_encrypted = encrypt(cv.text.encode(), aad=user.id.encode())
    notes = ["Rule-based extraction: every field links to the exact CV text it came from. Please review."]
    extracted = rules_extract(cv, doc.id)
    if llm.available(user.ai_consent_at is not None):
        try:
            ai_fields, stats = llm.extract_with_claude(cv, doc.id)
            known = {(f["kind"], str(f["value"]).lower()) for f in extracted}
            extracted += [f for f in ai_fields if (f["kind"], str(f["value"]).lower()) not in known]
            notes.append(f"AI-assisted extraction added fields; {stats['dropped_unverifiable']} AI suggestions were "
                         "discarded because their quoted evidence was not found in your CV.")
        except Exception as e:  # noqa: BLE001 — AI is optional; never block the upload
            notes.append(f"AI-assisted extraction unavailable ({type(e).__name__}); rule-based results shown.")
    elif get_settings().anthropic_api_key and user.ai_consent_at is None:
        notes.append("AI-assisted extraction is off because you have not consented to sending your CV to "
                     "the AI provider. You can enable it in Settings.")
    p = get_profile(db, user.id)
    keep = [f for f in p.fields if f["origin"] == "user" or f.get("confirmed")]
    _bump(p, keep + extracted)
    audit(db, user.id, "cv_uploaded", doc.id, fields=len(extracted))  # counts only, never CV text
    db.commit()
    from app.tasks import enqueue_rescore
    enqueue_rescore(user.id)
    return _out(db, p, notes)


@router.patch("/profile/fields/{field_id}", response_model=ProfileOut)
def patch_field(field_id: str, body: FieldPatch, user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_profile(db, user.id)
    fields = [dict(f) for f in p.fields]
    for f in fields:
        if f["id"] == field_id:
            if body.value is not None:
                f["value"], f["edited_by_user"], f["flags"] = body.value, True, []
            if body.confirmed is not None:
                f["confirmed"] = body.confirmed
            if body.rejected is not None:
                f["rejected"] = body.rejected
            break
    else:
        raise HTTPException(404, "Field not found")
    _bump(p, fields)
    db.commit()
    return _out(db, p)


@router.post("/profile/fields", response_model=ProfileOut)
def add_field(body: NewField, user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_profile(db, user.id)
    f = {"id": uuid.uuid4().hex[:12], "kind": body.kind, "value": body.value, "confidence": 1.0,
         "origin": "user", "evidence": [], "flags": [], "confirmed": True}
    _bump(p, [*p.fields, f])
    db.commit()
    return _out(db, p)


@router.put("/profile/preferences", response_model=ProfileOut)
def put_preferences(body: Preferences, user: User = Depends(current_user), db: Session = Depends(get_db)):
    p = get_profile(db, user.id)
    p.preferences = body.model_dump()
    p.version += 1
    db.commit()
    from app.tasks import enqueue_rescore
    enqueue_rescore(user.id)
    return _out(db, p)


# ---- documents: private, short-lived signed download links ----

def _sign(doc_id: str, user_id: str, exp: int) -> str:
    key = get_settings().encryption_key.encode()
    return hmac.new(key, f"{doc_id}:{user_id}:{exp}".encode(), hashlib.sha256).hexdigest()


def _own_doc(db: Session, user: User, doc_id: str) -> Document:
    d = db.get(Document, doc_id)
    if not d or d.user_id != user.id:
        raise HTTPException(404, "Document not found")
    return d


@router.post("/documents/{doc_id}/link")
def document_link(doc_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    _own_doc(db, user, doc_id)
    exp = int(time.time()) + 300
    return {"url": f"/api/documents/{doc_id}/download?exp={exp}&sig={_sign(doc_id, user.id, exp)}",
            "expires_in": 300}


@router.get("/documents/{doc_id}/download")
def document_download(doc_id: str, exp: int, sig: str, user: User = Depends(current_user),
                      db: Session = Depends(get_db)):
    d = _own_doc(db, user, doc_id)
    if exp < time.time() or not hmac.compare_digest(sig, _sign(doc_id, user.id, exp)):
        raise HTTPException(403, "Link expired or invalid")
    return Response(load_file(d.storage_key, user.id), media_type=d.mime,
                    headers={"Content-Disposition": f'attachment; filename="{d.filename}"',
                             "X-Content-Type-Options": "nosniff"})


@router.get("/documents/{doc_id}/text")
def document_text(doc_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Extracted CV text, for showing evidence spans in context."""
    d = _own_doc(db, user, doc_id)
    if not d.text_encrypted:
        raise HTTPException(404, "No extracted text")
    return {"text": decrypt(d.text_encrypted, aad=user.id.encode()).decode()}


@router.delete("/documents/{doc_id}")
def delete_document(doc_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d = _own_doc(db, user, doc_id)
    p = get_profile(db, user.id)
    remaining = [f for f in p.fields if not any(e.get("document_id") == doc_id for e in f.get("evidence", []))
                 or f["origin"] == "user"]
    _bump(p, remaining)
    key = d.storage_key
    db.delete(d)
    audit(db, user.id, "document_deleted", doc_id)
    db.commit()
    delete_file(key)
    return {"deleted": True}
