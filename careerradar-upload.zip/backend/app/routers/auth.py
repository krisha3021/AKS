import re

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
from sqlalchemy import delete, select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db, utcnow
from app.deps import SESSION_COOKIE, audit, current_user, rate_limit
from app.models import (Application, AuthSession, Document, Draft, Import, Job, Notification, Profile,
                        Source, User)
from app.security import delete_file, hash_password, new_session_token, token_hash, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class Credentials(BaseModel):
    email: str = Field(max_length=320)
    password: str = Field(min_length=10, max_length=200)


class Me(BaseModel):
    id: str
    email: str
    ai_consent: bool
    retention_days: int


def _me(u: User) -> Me:
    return Me(id=u.id, email=u.email, ai_consent=u.ai_consent_at is not None, retention_days=u.retention_days)


def _start_session(db: Session, response: Response, user: User) -> None:
    token, th, expires = new_session_token()
    db.add(AuthSession(token_hash=th, user_id=user.id, expires_at=expires))
    s = get_settings()
    response.set_cookie(SESSION_COOKIE, token, httponly=True, samesite="strict", secure=s.cookie_secure,
                        max_age=s.session_ttl_hours * 3600, path="/")


@router.post("/register", response_model=Me, dependencies=[Depends(rate_limit("register", 5, 5))])
def register(body: Credentials, response: Response, db: Session = Depends(get_db)):
    email = body.email.strip().lower()
    if not EMAIL_RE.match(email):
        raise HTTPException(422, "Invalid email")
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, "Email already registered")
    user = User(email=email, password_hash=hash_password(body.password),
                retention_days=get_settings().default_retention_days)
    db.add(user)
    db.flush()
    _start_session(db, response, user)
    audit(db, user.id, "register")
    db.commit()
    return _me(user)


@router.post("/login", response_model=Me, dependencies=[Depends(rate_limit("login", 10, 10))])
def login(body: Credentials, response: Response, db: Session = Depends(get_db)):
    user = db.scalar(select(User).where(User.email == body.email.strip().lower()))
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    _start_session(db, response, user)
    audit(db, user.id, "login")
    db.commit()
    return _me(user)


@router.post("/logout")
def logout(request: Request, response: Response, db: Session = Depends(get_db)):
    token = request.cookies.get(SESSION_COOKIE)
    if token:
        db.execute(delete(AuthSession).where(AuthSession.token_hash == token_hash(token)))
        db.commit()
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"ok": True}


@router.get("/me", response_model=Me)
def me(user: User = Depends(current_user)):
    return _me(user)


class ConsentBody(BaseModel):
    ai_consent: bool


@router.post("/consent", response_model=Me)
def set_consent(body: ConsentBody, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Explicit opt-in before any CV text is sent to the external AI provider."""
    user.ai_consent_at = utcnow() if body.ai_consent else None
    audit(db, user.id, "ai_consent", meta_value=body.ai_consent)
    db.commit()
    return _me(user)


@router.get("/export")
def export_my_data(user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Machine-readable export of everything stored about the user (file bytes excluded)."""
    def rows(model):
        out = []
        for r in db.scalars(select(model).where(model.user_id == user.id)):
            d = {c.name: getattr(r, c.name) for c in r.__table__.columns if c.name != "text_encrypted"}
            out.append({k: (v.isoformat() if hasattr(v, "isoformat") else v) for k, v in d.items()})
        return out
    profile = db.get(Profile, user.id)
    return {
        "user": _me(user).model_dump(),
        "profile": {"fields": profile.fields, "preferences": profile.preferences} if profile else None,
        "documents": rows(Document), "jobs": rows(Job), "imports": rows(Import),
        "applications": rows(Application), "drafts": rows(Draft), "sources": rows(Source),
        "notifications": rows(Notification),
    }


@router.delete("/account")
def delete_account(response: Response, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Hard-deletes the user, all rows (FK cascade) and all stored files."""
    keys = list(db.scalars(select(Document.storage_key).where(Document.user_id == user.id)))
    uid = user.id
    db.delete(user)
    audit(db, uid, "account_deleted", files=len(keys))
    db.commit()
    for k in keys:
        delete_file(k)
    response.delete_cookie(SESSION_COOKIE, path="/")
    return {"deleted": True, "files_removed": len(keys)}
