import asyncio

from fastapi import APIRouter, Depends, Request
from fastapi.responses import StreamingResponse
from sqlalchemy import select, update
from sqlalchemy.orm import Session

from app.db import get_db, utcnow
from app.deps import current_user
from app.events import subscribe, unsubscribe
from app.models import Notification, User

router = APIRouter(prefix="/api", tags=["events"])


@router.get("/events")
async def events(request: Request, user: User = Depends(current_user)):
    """Server-Sent Events. The browser's EventSource reconnects automatically (retry: 3s);
    on reconnect the client refetches state, so missed events are never lost data."""
    loop_q = subscribe(user.id)

    async def stream():
        try:
            yield "retry: 3000\nevent: hello\ndata: {}\n\n"
            while not await request.is_disconnected():
                try:
                    msg = await asyncio.wait_for(loop_q[1].get(), timeout=15)
                    yield msg
                except TimeoutError:
                    yield ": keepalive\n\n"
        finally:
            unsubscribe(user.id, loop_q)

    return StreamingResponse(stream(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@router.get("/notifications")
def list_notifications(unread: bool = False, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Notification).where(Notification.user_id == user.id)
    if unread:
        q = q.where(Notification.read_at.is_(None))
    return [{"id": n.id, "kind": n.kind, "job_id": n.job_id, "message": n.message, "created_at": n.created_at,
             "read": n.read_at is not None} for n in db.scalars(q.order_by(Notification.created_at.desc()).limit(200))]


@router.post("/notifications/read")
def mark_read(user: User = Depends(current_user), db: Session = Depends(get_db)):
    db.execute(update(Notification).where(Notification.user_id == user.id, Notification.read_at.is_(None))
               .values(read_at=utcnow()))
    db.commit()
    return {"ok": True}
