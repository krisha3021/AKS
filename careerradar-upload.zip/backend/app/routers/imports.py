from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import get_settings
from app.db import get_db
from app.deps import audit, current_user, rate_limit
from app.events import publish
from app.importer import FIELDS, ImportFileError, map_row, read_table, suggest_mapping
from app.jobstore import IncomingJob, upsert_job
from app.models import Document, Import, User
from app.security import load_file
from app.uploads import read_upload, save_document

router = APIRouter(prefix="/api/imports", tags=["imports"])


class Preview(BaseModel):
    document_id: str
    filename: str
    headers: list[str]
    suggested_mapping: dict[str, str | None]
    target_fields: list[str]
    sample_rows: list[dict]
    row_count: int


class CommitBody(BaseModel):
    mapping: dict[str, str | None]


class RowError(BaseModel):
    row: int
    raw: dict
    errors: list[str]


class ImportSummary(BaseModel):
    id: str
    filename: str
    total_rows: int
    created_count: int
    merged_count: int
    failed_count: int
    errors: list[RowError]


def _summary(imp: Import) -> ImportSummary:
    return ImportSummary(id=imp.id, filename=imp.filename, total_rows=imp.total_rows,
                         created_count=imp.created_count, merged_count=imp.merged_count,
                         failed_count=imp.failed_count, errors=imp.errors)


def _table(data: bytes, name: str):
    try:
        return read_table(data, name, get_settings().max_import_rows)
    except ImportFileError as e:
        raise HTTPException(422, str(e)) from None


@router.post("/preview", response_model=Preview, dependencies=[Depends(rate_limit("upload", 20, 10))])
async def preview(file: UploadFile = File(...), user: User = Depends(current_user), db: Session = Depends(get_db)):
    data, name = await read_upload(file, "job_list")
    table = _table(data, name)
    doc = save_document(db, user.id, "job_list", name, data)
    audit(db, user.id, "import_preview", doc.id, rows=len(table.rows))
    db.commit()
    return Preview(document_id=doc.id, filename=name, headers=table.headers,
                   suggested_mapping=suggest_mapping(table.headers), target_fields=FIELDS,
                   sample_rows=table.rows[:5], row_count=len(table.rows))


@router.post("/{document_id}/commit", response_model=ImportSummary)
def commit(document_id: str, body: CommitBody, user: User = Depends(current_user), db: Session = Depends(get_db)):
    doc = db.get(Document, document_id)
    if not doc or doc.user_id != user.id or doc.kind != "job_list":
        raise HTTPException(404, "Upload not found")
    bad = {v for v in body.mapping.values() if v and v not in FIELDS}
    if bad:
        raise HTTPException(422, f"Unknown target field(s): {', '.join(sorted(bad))}")
    if "title" not in body.mapping.values():
        raise HTTPException(422, "Map a column to 'title' before importing")
    table = _table(load_file(doc.storage_key, user.id), doc.filename)
    imp = Import(user_id=user.id, document_id=doc.id, filename=doc.filename, mapping=body.mapping,
                 total_rows=len(table.rows))
    db.add(imp)
    db.flush()
    errors, created, merged, new_ids = [], 0, 0, []
    for i, raw in enumerate(table.rows):
        row_number = i + 2  # 1-based, after header row
        mapped, errs = map_row(raw, body.mapping, row_number, table.formula_cells)
        if errs:
            errors.append({"row": row_number, "raw": raw, "errors": errs})
            continue
        with db.begin_nested():
            res = upsert_job(db, user.id, IncomingJob(
                title=mapped["title"], employer=mapped["employer"], fields=mapped["fields"],
                source_key="import:" + ("xlsx" if doc.filename.lower().endswith(".xlsx") else "csv"),
                source_url=mapped["url"], raw={**raw, "_claimed_status": mapped["status_claimed"],
                                               "_source_name": mapped["source_name"]},
                import_id=imp.id, import_row=row_number, verified=False))
        if res.created:
            created += 1
            new_ids.append(res.job.id)
        else:
            merged += 1
    imp.created_count, imp.merged_count, imp.failed_count, imp.errors = created, merged, len(errors), errors
    audit(db, user.id, "import_commit", imp.id, created=created, merged=merged, failed=len(errors))
    db.commit()
    from app.tasks import enqueue_rescore
    enqueue_rescore(user.id)
    publish(user.id, "jobs_changed", {"import_id": imp.id, "created": created, "merged": merged})
    return _summary(imp)


@router.get("", response_model=list[ImportSummary])
def list_imports(user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Import).where(Import.user_id == user.id).order_by(Import.created_at.desc())
    return [_summary(i) for i in db.scalars(q)]


@router.get("/{import_id}", response_model=ImportSummary)
def get_import(import_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    imp = db.get(Import, import_id)
    if not imp or imp.user_id != user.id:
        raise HTTPException(404, "Import not found")
    return _summary(imp)
