import csv
import io
from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db, utcnow
from app.deps import audit, current_user
from app.importer import csv_safe
from app.jobstore import IncomingJob, upsert_job
from app.matching import ensure_scores
from app.models import Job, JobChange, JobStatus, User
from app.normalize import parse_location, validate_url
from app.search import keyword_scores, unindex_job

router = APIRouter(prefix="/api/jobs", tags=["jobs"])


class JobCard(BaseModel):
    id: str
    title: str
    employer: str | None
    location: str | None
    country: str | None
    city: str | None
    scope: str | None
    work_arrangement: str | None
    status: str
    is_synthetic: bool
    deadline_at: datetime | None
    deadline_kind: str
    deadline_text: str | None
    posted_date: datetime | None
    first_seen_at: datetime
    last_verified_at: datetime | None
    last_checked_at: datetime | None
    application_url: str | None
    canonical_url: str | None
    sources: list[str]
    score: float | None
    deal_breaker: bool
    summary: str | None
    visa_sponsorship: str
    salary: str | None
    stale_warning: str | None


class JobPage(BaseModel):
    total: int
    items: list[JobCard]


def _salary(j: Job) -> str | None:
    if not (j.salary_min or j.salary_max):
        return None
    rng = "–".join(f"{v:,.0f}" for v in (j.salary_min, j.salary_max) if v)
    return f"{rng} {j.salary_currency or '(currency not stated)'} {('per ' + j.salary_period) if j.salary_period else ''}".strip()


def _stale_warning(j: Job) -> str | None:
    now = utcnow()
    if j.status == JobStatus.IMPORTED_UNVERIFIED:
        return "Imported lead — not verified as open"
    if j.status == JobStatus.VERIFICATION_UNAVAILABLE:
        return "Last check failed (source unreachable); status unchanged"
    if j.status == JobStatus.STALE or (j.last_verified_at and (now - j.last_verified_at).days >= 7):
        return "Not verified in the last 7 days"
    return None


def _card(j: Job, m) -> JobCard:
    return JobCard(
        id=j.id, title=j.title, employer=j.employer, location=j.location_raw, country=j.country, city=j.city,
        scope=j.scope, work_arrangement=j.work_arrangement, status=j.status, is_synthetic=j.is_synthetic,
        deadline_at=j.deadline_at, deadline_kind=j.deadline_kind, deadline_text=j.deadline_text,
        posted_date=j.posted_date, first_seen_at=j.first_seen_at, last_verified_at=j.last_verified_at,
        last_checked_at=j.last_checked_at, application_url=j.application_url, canonical_url=j.canonical_url,
        sources=sorted({s.source_key for s in j.sources}), score=m.score if m else None,
        deal_breaker=bool(m and m.deal_breaker), summary=m.explanation.get("summary") if m else None,
        visa_sponsorship=j.visa_sponsorship, salary=_salary(j), stale_warning=_stale_warning(j))


def _filtered(db: Session, user: User, q: str | None, scope, country, city, arrangement, employer, status,
              deadline_before, deadline_after, seen_after, posted_after, min_score, visa_stated, salary_min,
              employment_type, rank, discipline, academic, include_closed, sort):
    scores = ensure_scores(db, user.id)
    db.commit()
    jobs = list(db.scalars(select(Job).where(Job.user_id == user.id)))
    kw = keyword_scores(db, user.id, q) if q else None
    out = []
    for j in jobs:
        m = scores.get(j.id)
        if kw is not None and j.id not in kw:
            continue
        if scope and j.scope != scope:
            continue
        if country and (j.country or "").lower() != country.lower():
            continue
        if city and city.lower() not in (j.city or j.location_raw or "").lower():
            continue
        if arrangement and j.work_arrangement != arrangement:
            continue
        if employer and employer.lower() not in (j.employer or "").lower():
            continue
        if status and j.status not in status:
            continue
        if not include_closed and not status and j.status in (JobStatus.CLOSED_EXPLICIT, JobStatus.REMOVED,
                                                              JobStatus.DEADLINE_PASSED):
            continue
        if deadline_before and not (j.deadline_at and j.deadline_at <= deadline_before):
            continue
        if deadline_after and not (j.deadline_at and j.deadline_at >= deadline_after):
            continue
        if seen_after and j.first_seen_at < seen_after:
            continue
        if posted_after and not (j.posted_date and j.posted_date >= posted_after):
            continue
        if min_score is not None and (not m or m.score < min_score):
            continue
        if visa_stated and j.visa_sponsorship != "stated_yes":
            continue
        if salary_min is not None and not (j.salary_max and j.salary_max >= salary_min):
            continue
        if employment_type and (j.employment_type or "").lower() != employment_type.lower():
            continue
        if rank and rank.lower() not in f"{j.rank_or_seniority or ''} {j.title}".lower():
            continue
        if discipline and discipline.lower() not in f"{j.discipline or ''} {j.title} {j.department or ''}".lower():
            continue
        if academic and not any(t in j.title.lower() for t in
                                ("professor", "lecturer", "postdoc", "post-doc", "research fellow",
                                 "research scientist", "reader", "faculty")):
            continue
        out.append((j, m, kw.get(j.id, 0) if kw else 0))
    keyfn = {
        "score": lambda t: (-(t[1].score if t[1] else -1), -t[2]),
        "relevance": lambda t: (-t[2], -(t[1].score if t[1] else -1)),
        "deadline": lambda t: (t[0].deadline_at is None, t[0].deadline_at or datetime.max),
        "newest": lambda t: (-t[0].first_seen_at.timestamp(),),
    }[sort]
    out.sort(key=keyfn)
    return out


@router.get("", response_model=JobPage)
def list_jobs(q: str | None = None, scope: Literal["national", "international"] | None = None,
              country: str | None = None, city: str | None = None,
              arrangement: Literal["remote", "hybrid", "onsite"] | None = None, employer: str | None = None,
              status: list[str] | None = Query(None), deadline_before: datetime | None = None,
              deadline_after: datetime | None = None, seen_after: datetime | None = None,
              posted_after: datetime | None = None, min_score: float | None = None, visa_stated: bool = False,
              salary_min: float | None = None, employment_type: str | None = None, rank: str | None = None,
              discipline: str | None = None, academic: bool = False, include_closed: bool = False,
              sort: Literal["score", "relevance", "deadline", "newest"] = "score",
              offset: int = Query(0, ge=0), limit: int = Query(50, ge=1, le=200),
              user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = _filtered(db, user, q, scope, country, city, arrangement, employer, status, deadline_before,
                     deadline_after, seen_after, posted_after, min_score, visa_stated, salary_min,
                     employment_type, rank, discipline, academic, include_closed, sort)
    return JobPage(total=len(rows), items=[_card(j, m) for j, m, _ in rows[offset:offset + limit]])


def _own(db: Session, user: User, job_id: str) -> Job:
    j = db.get(Job, job_id)
    if not j or j.user_id != user.id:
        raise HTTPException(404, "Job not found")
    return j


@router.get("/{job_id}")
def job_detail(job_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    j = _own(db, user, job_id)
    m = ensure_scores(db, user.id).get(j.id)
    db.commit()
    changes = db.scalars(select(JobChange).where(JobChange.job_id == j.id).order_by(JobChange.at.desc()))
    return {
        "job": _card(j, m).model_dump(),
        "fields": {c.name: getattr(j, c.name) for c in Job.__table__.columns if c.name != "user_id"},
        "match": {"score": m.score, "components": m.components, "explanation": m.explanation,
                  "computed_at": m.computed_at} if m else None,
        "provenance": [{"source_key": s.source_key, "source_url": s.source_url, "source_job_id": s.source_job_id,
                        "import_id": s.import_id, "import_row": s.import_row, "seen_at": s.seen_at,
                        "original_values": s.raw} for s in j.sources],
        "changes": [{"field": c.field, "old": c.old_value, "new": c.new_value, "material": c.material,
                     "at": c.at} for c in changes],
    }


class ManualJob(BaseModel):
    url: str
    title: str
    employer: str | None = None
    location: str | None = None
    deadline: str | None = None
    notes: str | None = None


@router.post("", status_code=201)
def add_job_lead(body: ManualJob, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Add a single vacancy URL as a lead. It stays 'imported_unverified' until a verifier confirms it."""
    err = validate_url(body.url)
    if err:
        raise HTTPException(422, err)
    from app.normalize import parse_deadline, infer_scope
    loc = parse_location(body.location)
    fields = {k: v for k, v in loc.items() if v}
    fields.update(application_url=body.url, scope=infer_scope(loc["country"]))
    if body.deadline:
        fields.update(parse_deadline(body.deadline))
    if body.notes:
        fields["description"] = f"Your notes: {body.notes}"
    res = upsert_job(db, user.id, IncomingJob(title=body.title, employer=body.employer, fields=fields,
                                              source_key="manual:url", source_url=body.url,
                                              raw=body.model_dump()))
    from app.tasks import enqueue
    enqueue(db, "verify_job", f"verify:{res.job.id}", {"job_id": res.job.id}, user_id=user.id)
    db.commit()
    return {"id": res.job.id, "created": res.created}


@router.delete("/{job_id}")
def delete_job(job_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    j = _own(db, user, job_id)
    unindex_job(db, j.id)
    db.delete(j)
    audit(db, user.id, "job_deleted", job_id)
    db.commit()
    return {"deleted": True}


@router.post("/{job_id}/refresh")
def refresh_job(job_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Manual re-verification, throttled to once per 10 minutes per job."""
    j = _own(db, user, job_id)
    if j.last_checked_at and (utcnow() - j.last_checked_at).total_seconds() < 600:
        raise HTTPException(429, "This job was checked less than 10 minutes ago")
    from app.tasks import enqueue
    queued = enqueue(db, "verify_job", f"verify:{j.id}", {"job_id": j.id}, user_id=user.id)
    db.commit()
    return {"queued": queued}


@router.get("/export/csv")
def export_csv(user: User = Depends(current_user), db: Session = Depends(get_db)):
    scores = ensure_scores(db, user.id)
    db.commit()
    buf = io.StringIO()
    w = csv.writer(buf)
    cols = ["title", "employer", "location", "country", "status", "deadline", "deadline_kind", "score",
            "application_url", "first_seen", "last_verified", "synthetic"]
    w.writerow(cols)
    for j in db.scalars(select(Job).where(Job.user_id == user.id)):
        m = scores.get(j.id)
        w.writerow([csv_safe(v) for v in (j.title, j.employer, j.location_raw, j.country, j.status,
                                          j.deadline_at, j.deadline_kind, m.score if m else "", j.application_url,
                                          j.first_seen_at, j.last_verified_at, j.is_synthetic)])
    return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                             headers={"Content-Disposition": 'attachment; filename="careerradar-jobs.csv"'})
