from app.routers import applications, auth, events, imports, jobs, ops, profile, sources

ALL = [auth.router, imports.router, profile.router, jobs.router, applications.router, sources.router,
       events.router, ops.router]
