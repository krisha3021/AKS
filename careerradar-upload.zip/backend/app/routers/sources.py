from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.connectors import REGISTRY, capability_matrix
from app.db import get_db, utcnow
from app.deps import audit, current_user
from app.models import Source, Task, User
from app.tasks import enqueue

router = APIRouter(prefix="/api/sources", tags=["sources"])


class SourceIn(BaseModel):
    connector_key: str
    name: str = Field(max_length=200)
    config: dict = {}
    interval_minutes: int = Field(360, ge=15, le=10080)
    enabled: bool = True


def _out(s: Source) -> dict:
    cap = REGISTRY[s.connector_key].capability
    interval = max(s.interval_minutes, cap.min_interval_minutes)
    health = "ok" if s.last_success_at and not s.last_error else ("failing" if s.last_error else "never_run")
    return {"id": s.id, "connector_key": s.connector_key, "connector_name": cap.name, "name": s.name,
            "config": s.config, "enabled": s.enabled, "interval_minutes": interval,
            "last_checked_at": s.last_checked_at, "last_success_at": s.last_success_at, "last_error": s.last_error,
            "consecutive_failures": s.consecutive_failures, "health": health,
            "stale": bool(s.last_success_at and (utcnow() - s.last_success_at).total_seconds() > interval * 120)}


@router.get("/capabilities")
def capabilities():
    """The source-access matrix: what is automated, what is manual-only and why."""
    return [c.__dict__ for c in capability_matrix()]


@router.get("")
def list_sources(user: User = Depends(current_user), db: Session = Depends(get_db)):
    return [_out(s) for s in db.scalars(select(Source).where(Source.user_id == user.id))]


@router.post("", status_code=201)
def add_source(body: SourceIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    conn = REGISTRY.get(body.connector_key)
    if not conn:
        raise HTTPException(422, "This source has no supported automated connector. Use spreadsheet import or "
                                 "add vacancy URLs instead.")
    for req in conn.capability.requires:
        if not req.startswith("env:") and req != "employer" and not body.config.get(req):
            raise HTTPException(422, f"config.{req} is required for {conn.capability.name}")
    s = Source(user_id=user.id, connector_key=body.connector_key, name=body.name, config=body.config,
               interval_minutes=max(body.interval_minutes, conn.capability.min_interval_minutes), enabled=body.enabled)
    db.add(s)
    db.flush()
    if s.enabled:
        enqueue(db, "fetch_source", f"fetch:{s.id}", {"source_id": s.id}, user_id=user.id)
    audit(db, user.id, "source_added", s.id, connector=s.connector_key)
    db.commit()
    return _out(s)


def _own(db: Session, user: User, sid: str) -> Source:
    s = db.get(Source, sid)
    if not s or s.user_id != user.id:
        raise HTTPException(404, "Source not found")
    return s


@router.patch("/{sid}")
def update_source(sid: str, body: dict, user: User = Depends(current_user), db: Session = Depends(get_db)):
    s = _own(db, user, sid)
    if "enabled" in body:
        s.enabled = bool(body["enabled"])
    if "interval_minutes" in body:
        s.interval_minutes = max(int(body["interval_minutes"]), REGISTRY[s.connector_key].capability.min_interval_minutes)
    if "name" in body:
        s.name = str(body["name"])[:200]
    db.commit()
    return _out(s)


@router.delete("/{sid}")
def delete_source(sid: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    db.delete(_own(db, user, sid))
    db.commit()
    return {"deleted": True}


@router.post("/{sid}/refresh")
def refresh_source(sid: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Manual refresh, throttled to the connector's minimum interval / 4 (min 5 minutes)."""
    s = _own(db, user, sid)
    floor = max(5, REGISTRY[s.connector_key].capability.min_interval_minutes // 4)
    if s.last_checked_at and (utcnow() - s.last_checked_at).total_seconds() < floor * 60:
        raise HTTPException(429, f"Checked recently; try again in a few minutes (minimum {floor} min).")
    queued = enqueue(db, "fetch_source", f"fetch:{s.id}", {"source_id": s.id}, user_id=user.id)
    db.commit()
    return {"queued": queued}


@router.get("/queue")
def queue_status(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.execute(select(Task.status, func.count()).where(Task.user_id == user.id).group_by(Task.status)).all()
    dead = db.scalars(select(Task).where(Task.user_id == user.id, Task.status == "dead")
                      .order_by(Task.finished_at.desc()).limit(10))
    return {"counts": dict(rows), "dead_letters": [{"id": t.id, "kind": t.kind, "error": t.last_error,
                                                    "at": t.finished_at} for t in dead]}
