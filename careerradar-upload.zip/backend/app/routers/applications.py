"""Application tracking and drafts. There is deliberately NO endpoint that submits applications,
sends email or contacts anyone: the user copies an approved draft and sends it themselves."""
import hashlib
from datetime import datetime
from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db, utcnow
from app.deps import current_user
from app.drafting import KINDS, build_draft
from app.models import Application, Draft, Job, Profile, Stage, User

router = APIRouter(prefix="/api", tags=["applications"])
StageLit = Literal["interested", "shortlisted", "preparing", "applied", "interview", "offer", "rejected", "withdrawn"]


class AppIn(BaseModel):
    job_id: str
    stage: StageLit = "interested"


class AppPatch(BaseModel):
    stage: StageLit | None = None
    notes: str | None = None
    applied_at: datetime | None = None
    reminder_at: datetime | None = None
    required_documents: list[dict] | None = None  # [{name, done}]
    contacts: list[dict] | None = None  # [{name, role, email}] — entered by the user only


def _app_out(a: Application, j: Job) -> dict:
    return {"id": a.id, "job_id": a.job_id, "stage": a.stage, "notes": a.notes, "applied_at": a.applied_at,
            "reminder_at": a.reminder_at, "required_documents": a.required_documents, "contacts": a.contacts,
            "history": a.history, "updated_at": a.updated_at,
            "job": {"title": j.title, "employer": j.employer, "deadline_at": j.deadline_at, "status": j.status,
                    "application_url": j.application_url, "is_synthetic": j.is_synthetic}}


def _job(db: Session, user: User, job_id: str) -> Job:
    j = db.get(Job, job_id)
    if not j or j.user_id != user.id:
        raise HTTPException(404, "Job not found")
    return j


def _app(db: Session, user: User, app_id: str) -> Application:
    a = db.get(Application, app_id)
    if not a or a.user_id != user.id:
        raise HTTPException(404, "Application not found")
    return a


@router.get("/applications")
def list_applications(user: User = Depends(current_user), db: Session = Depends(get_db)):
    rows = db.execute(select(Application, Job).join(Job, Job.id == Application.job_id)
                      .where(Application.user_id == user.id).order_by(Application.updated_at.desc())).all()
    return [_app_out(a, j) for a, j in rows]


@router.post("/applications", status_code=201)
def create_application(body: AppIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    j = _job(db, user, body.job_id)
    a = db.scalar(select(Application).where(Application.user_id == user.id, Application.job_id == j.id))
    if a:
        return _app_out(a, j)
    from app.matching import detect_requirements
    _, facts = detect_requirements(j)
    a = Application(user_id=user.id, job_id=j.id, stage=body.stage,
                    required_documents=[{"name": d, "done": False} for d in facts["documents"]],
                    history=[{"stage": body.stage, "at": utcnow().isoformat()}])
    db.add(a)
    db.commit()
    return _app_out(a, j)


@router.patch("/applications/{app_id}")
def update_application(app_id: str, body: AppPatch, user: User = Depends(current_user), db: Session = Depends(get_db)):
    a = _app(db, user, app_id)
    data = body.model_dump(exclude_unset=True)
    if "stage" in data and data["stage"] != a.stage:
        a.history = [*a.history, {"stage": data["stage"], "at": utcnow().isoformat()}]
        if data["stage"] == Stage.APPLIED and not a.applied_at and "applied_at" not in data:
            a.applied_at = utcnow()
    for k, v in data.items():
        setattr(a, k, v)
    db.commit()
    return _app_out(a, db.get(Job, a.job_id))


@router.delete("/applications/{app_id}")
def delete_application(app_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    db.delete(_app(db, user, app_id))
    db.commit()
    return {"deleted": True}


# ---- drafts ----

class DraftIn(BaseModel):
    job_id: str
    kind: Literal["application_email", "cover_letter", "research_statement_outline",
                  "teaching_statement_outline", "selection_criteria"]


class DraftEdit(BaseModel):
    content: str


def _draft_out(d: Draft) -> dict:
    return {"id": d.id, "job_id": d.job_id, "kind": d.kind, "content": d.content, "missing_info": d.missing_info,
            "approved": d.approved_at is not None, "approved_at": d.approved_at, "approved_sha256": d.approved_sha256,
            "notice": "CareerRadar never sends this. Copy it and submit it yourself after checking every line."}


def _draft(db: Session, user: User, draft_id: str) -> Draft:
    d = db.get(Draft, draft_id)
    if not d or d.user_id != user.id:
        raise HTTPException(404, "Draft not found")
    return d


@router.get("/drafts")
def list_drafts(job_id: str | None = None, user: User = Depends(current_user), db: Session = Depends(get_db)):
    q = select(Draft).where(Draft.user_id == user.id)
    if job_id:
        q = q.where(Draft.job_id == job_id)
    return [_draft_out(d) for d in db.scalars(q.order_by(Draft.created_at.desc()))]


@router.post("/drafts", status_code=201)
def create_draft(body: DraftIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    assert body.kind in KINDS
    j = _job(db, user, body.job_id)
    p = db.get(Profile, user.id)
    content, missing = build_draft(body.kind, j, p.fields if p else [])
    d = Draft(user_id=user.id, job_id=j.id, kind=body.kind, content=content, missing_info=missing)
    db.add(d)
    db.commit()
    return _draft_out(d)


@router.put("/drafts/{draft_id}")
def edit_draft(draft_id: str, body: DraftEdit, user: User = Depends(current_user), db: Session = Depends(get_db)):
    d = _draft(db, user, draft_id)
    if d.approved_at:
        raise HTTPException(409, "Approved drafts are frozen. Create a new draft to make changes.")
    d.content = body.content
    db.commit()
    return _draft_out(d)


@router.post("/drafts/{draft_id}/approve")
def approve_draft(draft_id: str, user: User = Depends(current_user), db: Session = Depends(get_db)):
    """Freezes the content (hash recorded). Approval does not send anything anywhere."""
    d = _draft(db, user, draft_id)
    if not d.approved_at:
        d.approved_at = utcnow()
        d.approved_sha256 = hashlib.sha256(d.content.encode()).hexdigest()
        db.commit()
    return _draft_out(d)
