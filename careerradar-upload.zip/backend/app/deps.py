from fastapi import Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.db import get_db, utcnow
from app.models import AuditLog, AuthSession, User
from app.security import limiter, token_hash

SESSION_COOKIE = "cr_session"
CSRF_HEADER = "x-cr-csrf"


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = request.cookies.get(SESSION_COOKIE)
    if not token:
        raise HTTPException(401, "Not signed in")
    sess = db.get(AuthSession, token_hash(token))
    if not sess or sess.expires_at < utcnow():
        raise HTTPException(401, "Session expired")
    user = db.get(User, sess.user_id)
    if not user:
        raise HTTPException(401, "Not signed in")
    return user


def client_ip(request: Request) -> str:
    """Behind Cloudflare Tunnel every request arrives from 127.0.0.1, so the visitor's address
    comes from CF-Connecting-IP. Only trusted when enabled AND the peer is local (i.e. cloudflared);
    a direct caller cannot spoof it."""
    from app.config import get_settings
    s = get_settings()
    peer = request.client.host if request.client else "unknown"
    # 'behind_cloudflare_worker': the container has no public address; every request comes through
    # our own Worker, which receives CF-Connecting-IP from Cloudflare's edge.
    if (s.trust_cf_connecting_ip and peer in ("127.0.0.1", "::1")) or s.behind_cloudflare_worker:
        # x-cr-client-ip: set (and overwritten) by our workers.dev proxy Worker (src/index.ts);
        # cf-connecting-ip: set by Cloudflare on direct tunnel traffic.
        return request.headers.get("x-cr-client-ip") or request.headers.get("cf-connecting-ip") or peer
    return peer


def rate_limit(bucket: str, per_min: float, burst: int):
    def _dep(request: Request) -> None:
        ip = client_ip(request)
        if not limiter.allow(f"{bucket}:{ip}", per_min, burst):
            raise HTTPException(429, "Too many requests, slow down")
    return _dep


def audit(db: Session, user_id: str | None, action: str, target: str | None = None, **meta) -> None:
    db.add(AuditLog(user_id=user_id, action=action, target=target, meta=meta))
