"""Measured quality report on a LABELLED SYNTHETIC test set. Writes docs/H-evaluation.md.

    python -m scripts.evaluate

Numbers describe this small synthetic set only. They are a regression baseline, not a claim
about performance on real CVs or real job boards — collect a labelled real-world set for that.
"""
import math
import os
import tempfile
import time
from datetime import date
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="cr-eval-"))
os.environ.setdefault("CR_DATABASE_URL", f"sqlite:///{(_TMP / 'eval.db').as_posix()}")
os.environ.setdefault("CR_STORAGE_DIR", str(_TMP / "files"))

from app.cv.rules import extract  # noqa: E402
from app.cv.text import CvText  # noqa: E402
from app.db import Base, SessionLocal, engine  # noqa: E402
from app.jobstore import IncomingJob, upsert_job  # noqa: E402
from app.matching import match_job  # noqa: E402
from app.models import Job, User  # noqa: E402
from app.search import ensure_fts  # noqa: E402

DOCS = Path(__file__).resolve().parents[2] / "docs"

# ---------- 1. CV parsing: gold labels per synthetic CV ----------
CVS = [
    ("Education\nPhD in Physics, Demo University, 2015\nMSc Physics, Example College, 2010\nExperience\n"
     "Lecturer, Demo University, Sep 2016 - Present\nPostdoctoral Researcher, Example Lab, 2015 - 2016\n"
     "Skills\nPython, LaTeX, Monte Carlo methods\n",
     {"degree": {"doctorate", "masters"}, "employment": 2, "skill": {"Python", "LaTeX", "Monte Carlo methods"}}),
    ("ACADEMIC QUALIFICATIONS\nB.Tech in Electronics, Demo Institute of Technology, 2008\n"
     "M.Tech in VLSI Design, Example University, 2011\nPh.D. in Electrical Engineering, Example University, 2017\n"
     "Work Experience\nAssistant Professor, Demo College, 07/2017 - 06/2021\nAssociate Professor, Demo College, "
     "07/2021 - present\nTechnical Skills\nVerilog; MATLAB; Cadence\n",
     {"degree": {"bachelors", "masters", "doctorate"}, "employment": 2, "skill": {"Verilog", "MATLAB", "Cadence"}}),
    ("Summary of a synthetic engineer.\nEducation\nBachelor of Science in Computer Science, Example State "
     "University, 2014\nEmployment\nSoftware Engineer, Example Corp, Jan 2015 – Dec 2018\nSenior Software "
     "Engineer, Demo Systems, Jan 2019 - now\nSkills\nGo, Kubernetes, PostgreSQL\n",
     {"degree": {"bachelors"}, "employment": 2, "skill": {"Go", "Kubernetes", "PostgreSQL"}}),
    ("Education\nMBA, Demo Business School, 2012\nMaster of Arts in Economics, Example University, 2009\n"
     "Professional Experience\nResearch Scientist, Example Policy Institute, March 2013 to 2020\n"
     "Skills\nStata, R, survey design\n",
     {"degree": {"masters"}, "employment": 1, "skill": {"Stata", "R", "survey design"}}),
]


def eval_parsing() -> dict:
    tp = fp = fn = 0
    rows = []
    for i, (text, gold) in enumerate(CVS):
        fields = extract(CvText(text, [0]), f"cv{i}", date(2026, 10, 1))
        got_deg = {f["value"]["level"] for f in fields if f["kind"] == "degree"}
        got_skill = {f["value"] for f in fields if f["kind"] == "skill"}
        got_emp = sum(f["kind"] == "employment" for f in fields)
        for got, want in ((got_deg, gold["degree"]), (got_skill, gold["skill"])):
            tp += len(got & want)
            fp += len(got - want)
            fn += len(want - got)
        tp += min(got_emp, gold["employment"])
        fp += max(0, got_emp - gold["employment"])
        fn += max(0, gold["employment"] - got_emp)
        rows.append((i + 1, sorted(got_deg), got_emp, sorted(got_skill)))
    p, r = tp / (tp + fp or 1), tp / (tp + fn or 1)
    return {"precision": p, "recall": r, "f1": 2 * p * r / (p + r or 1), "tp": tp, "fp": fp, "fn": fn}


# ---------- 2. Duplicate detection: labelled pairs ----------
DUP_PAIRS = [  # (a, b, is_duplicate)
    (("Assistant Professor CSE", "Demo Institute", "Patiala, India", "https://ex.org/j/1"),
     ("Assistant Professor CSE", "Demo Institute", "Patiala, India", "https://ex.org/j/1/?utm_source=x"), True),
    (("Lecturer in AI", "Example University", "Leeds, UK", None),
     ("Lecturer in AI", "The Example University", "Leeds, United Kingdom", None), True),
    (("Lecturer in AI", "Example University", "Leeds, UK", "https://ex.ac.uk/1"),
     ("Lecturer in AI", "Example University", "London, UK", "https://ex.ac.uk/2"), False),
    (("Postdoc in BCI", "Demo Lab", "Dubai", "https://ex.com/a"),
     ("Postdoctoral Fellow in Brain Computer Interfaces", "Demo Lab", "Dubai", "https://ex.com/b"), False),
    (("Data Scientist", "Example Corp", "Bengaluru", None), ("Data Scientist", "Other Corp", "Bengaluru", None), False),
    (("Professor of Physics", "Demo University", "Doha, Qatar", None),
     ("Professor of Physics", "Demo University", "Doha", None), True),
    (("Research Scientist", "Example Lab", "Berlin", "https://ex.de/7"),
     ("Research Scientist", "Example Lab", "Berlin", "https://EX.de/7#apply"), True),
    (("Lecturer (Teaching)", "Demo College", "Pune, India", None),
     ("Senior Lecturer", "Demo College", "Pune, India", None), False),
]


def eval_dedupe() -> dict:
    tp = fp = fn = tn = 0
    for a, b, is_dup in DUP_PAIRS:
        Base.metadata.drop_all(engine)
        Base.metadata.create_all(engine)
        ensure_fts(engine)
        with SessionLocal() as db:
            u = User(email="e@x.test", password_hash="x")
            db.add(u)
            db.flush()
            for t, e, loc, url in (a, b):
                upsert_job(db, u.id, IncomingJob(title=t, employer=e, fields={"location_raw": loc},
                                                 source_key="eval", source_url=url))
            merged = db.query(Job).count() == 1
            db.rollback()
        tp += merged and is_dup
        fp += merged and not is_dup
        fn += (not merged) and is_dup
        tn += (not merged) and not is_dup
    return {"precision": tp / (tp + fp or 1), "recall": tp / (tp + fn or 1), "tp": tp, "fp": fp, "fn": fn, "tn": tn}


# ---------- 3. Ranking: graded relevance (2 = strong, 1 = partial, 0 = poor) ----------
def eval_ranking() -> dict:
    from app.fixtures.synthetic_cv import synthetic_cv_docx
    from app.cv.text import extract_text
    cv = extract_text(synthetic_cv_docx(), "cv.docx")
    fields = extract(cv, "d", date(2026, 10, 1))
    prefs = {"target_titles": ["Assistant Professor", "Postdoctoral Fellow"],
             "research_areas": ["brain-computer interfaces"], "needs_visa_sponsorship": False}
    jobs = [  # (title, description, gold relevance)
        ("Assistant Professor in Brain-Computer Interfaces", "PhD essential. Teaching experience required. "
         "EEG signal processing and machine learning research.", 2),
        ("Postdoctoral Fellow in EEG Decoding", "PhD in computer science or related field required.", 2),
        ("Assistant Professor in Computer Science", "PhD essential. Teaching experience is required.", 1),
        ("Lecturer in Digital Signal Processing", "PhD desirable. Teaching required.", 1),
        ("Professor of Neuroscience", "Minimum 15 years of experience required. External funding record essential.", 0),
        ("Accounts Manager", "5 years of accounting experience required. CA qualification essential.", 0),
        ("Professor of History", "PhD in History essential. Publications required.", 0),
    ]
    scored = []
    for t, d, rel in jobs:
        j = Job(title=t, employer="Eval U", description=d, status="imported_unverified", visa_sponsorship="not_stated",
                deadline_kind="unknown")
        out = match_job(j, fields, prefs, None)
        scored.append((out.score, rel, t))
    scored.sort(key=lambda x: -x[0])
    rels = [r for _, r, _ in scored]
    dcg = sum((2 ** r - 1) / math.log2(i + 2) for i, r in enumerate(rels[:5]))
    ideal = sorted(rels, reverse=True)
    idcg = sum((2 ** r - 1) / math.log2(i + 2) for i, r in enumerate(ideal[:5]))
    p3 = sum(r > 0 for r in rels[:3]) / 3
    return {"ndcg@5": dcg / idcg, "precision@3": p3, "ranking": [(round(s), r, t) for s, r, t in scored]}


# ---------- 4. Freshness latency (processing only; upstream refresh interval excluded) ----------
def eval_latency() -> dict:
    import json
    import httpx
    from app import pipeline
    from app.models import Source
    from app.net import SafeHttpClient
    from app.tasks import drain, enqueue
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    ensure_fts(engine)
    body = {"jobs": [{"id": i, "title": f"Job {i}", "location": {"name": "Pune, India"}, "content": "x",
                      "absolute_url": f"https://boards.greenhouse.io/demo/jobs/{i}"} for i in range(50)]}

    def handler(req):
        if req.url.path == "/robots.txt":
            return httpx.Response(200, text="")
        return httpx.Response(200, text=json.dumps(body))
    pipeline.http_factory = lambda: SafeHttpClient(
        transport=httpx.MockTransport(handler), check_peer=False,
        resolver=lambda *a, **k: [(2, 1, 6, "", ("93.184.216.34", 443))])
    seen = []
    pipeline.publish = lambda uid, ev, data: seen.append((time.perf_counter(), ev))
    with SessionLocal() as db:
        u = User(email="l@x.test", password_hash="x")
        db.add(u)
        db.flush()
        s = Source(user_id=u.id, connector_key="greenhouse", name="eval", config={"board_token": "demo"})
        db.add(s)
        db.flush()
        enqueue(db, "fetch_source", "f", {"source_id": s.id}, user_id=u.id)
        db.commit()
    t0 = time.perf_counter()
    drain()
    t_event = next(t for t, ev in seen if ev == "jobs_changed")
    return {"jobs": 50, "fetch_to_dashboard_event_ms": round((t_event - t0) * 1000)}


def main() -> None:
    parsing, dedupe = eval_parsing(), eval_dedupe()
    ranking, latency = eval_ranking(), eval_latency()
    rank_rows = "\n".join(f"| {s} | {r} | {t} |" for s, r, t in ranking["ranking"])
    report = f"""# H. Evaluation report (synthetic labelled set)

Generated by `python -m scripts.evaluate` on {date.today().isoformat()}.
**Scope warning:** tiny synthetic set written by the developers. These numbers are a regression
baseline only — they say nothing about accuracy on real CVs or real job boards.

**Tuning disclosure:** the first run (2026-10-14) scored dedupe recall 0.75 and ranked "Professor of
History" 4th for a computer-science CV. Location comparison and degree-subject checks were fixed in
response, so this set is no longer independent of the code — a fresh held-out set is needed.

## CV parsing (rule-based extractor; degree levels, employment entries, skills)
{len(CVS)} synthetic CVs. Precision **{parsing['precision']:.2f}**, recall **{parsing['recall']:.2f}**,
F1 **{parsing['f1']:.2f}** (TP {parsing['tp']}, FP {parsing['fp']}, FN {parsing['fn']}).

## Duplicate detection
{len(DUP_PAIRS)} labelled pairs. Precision **{dedupe['precision']:.2f}**, recall **{dedupe['recall']:.2f}**
(TP {dedupe['tp']}, FP {dedupe['fp']}, FN {dedupe['fn']}, TN {dedupe['tn']}).

## Ranking
7 vacancies with graded relevance (2 strong / 1 partial / 0 poor) for the synthetic CV.
nDCG@5 **{ranking['ndcg@5']:.2f}**, precision@3 **{ranking['precision@3']:.2f}**.

| Score | Gold relevance | Vacancy |
|---|---|---|
{rank_rows}

## Freshness latency
Processing latency from the start of a source fetch (50 jobs, mocked HTTP) to the dashboard
`jobs_changed` event: **{latency['fetch_to_dashboard_event_ms']} ms** on the dev machine.
End-to-end freshness = this + the source's refresh interval (default 6 h for ATS boards, shown per source).
"""
    DOCS.mkdir(exist_ok=True)
    (DOCS / "H-evaluation.md").write_text(report, encoding="utf-8")
    print(report)


if __name__ == "__main__":
    main()
