"""Create a demo account with SYNTHETIC jobs and a SYNTHETIC CV.

    python -m scripts.seed_demo            (from backend/, after `alembic upgrade head`)

Prints the demo login. The password is generated randomly and written to backend/data/demo-login.txt;
it is not stored anywhere else.
"""
import secrets
from pathlib import Path

from sqlalchemy import select

from app.config import BACKEND_DIR
from app.cv.rules import extract
from app.cv.text import extract_text
from app.db import SessionLocal
from app.fixtures.demo_jobs import DEMO_JOBS
from app.jobstore import IncomingJob, upsert_job
from app.models import Profile, User
from app.normalize import parse_deadline
from app.security import encrypt, hash_password
from app.uploads import save_document

EMAIL = "demo@careerradar.test"


def main() -> None:
    from app.fixtures.synthetic_cv import synthetic_cv_docx  # synthetic person, no real data
    with SessionLocal() as db:
        if db.scalar(select(User).where(User.email == EMAIL)):
            print(f"Demo user already exists: {EMAIL} (see data/demo-login.txt)")
            return
        password = secrets.token_urlsafe(12)
        user = User(email=EMAIL, password_hash=hash_password(password))
        db.add(user)
        db.flush()
        data = synthetic_cv_docx()
        doc = save_document(db, user.id, "cv", "synthetic-demo-cv.docx", data)
        cv = extract_text(data, "cv.docx")
        doc.text_encrypted = encrypt(cv.text.encode(), aad=user.id.encode())
        db.add(Profile(user_id=user.id, fields=extract(cv, doc.id), version=1, preferences={
            "home_country": "India", "academic_mode": True,
            "target_titles": ["Assistant Professor", "Lecturer", "Postdoctoral Fellow"],
            "research_areas": ["brain-computer interfaces", "machine learning"], "countries": [],
            "work_arrangements": [], "employment_types": [], "appointment_types": [], "disciplines": [],
            "title_synonyms": [], "cities": [], "excluded_employers": [], "excluded_locations": [],
            "excluded_keywords": [], "needs_visa_sponsorship": True, "alert_frequency": "instant",
            "languages": ["English"]}))
        for j in DEMO_JOBS:
            fields = {k: v for k, v in j.items() if k not in ("title", "employer", "url", "deadline")}
            fields.update(is_synthetic=True, application_url=j["url"])
            if j.get("deadline"):
                fields.update(parse_deadline(j["deadline"]))
            upsert_job(db, user.id, IncomingJob(title=j["title"], employer=j["employer"], fields=fields,
                                                source_key="demo:synthetic", source_url=j["url"],
                                                raw={"synthetic": True}))
        db.commit()
    out = Path(BACKEND_DIR) / "data" / "demo-login.txt"
    out.write_text(f"{EMAIL}\n{password}\n")
    print(f"Demo account created: {EMAIL}  (password saved to {out})")


if __name__ == "__main__":
    main()
