from tests.conftest import Api, make_user


def test_health():
    api = Api()
    assert api.get("/api/health/live").json() == {"status": "ok"}
    assert api.get("/api/health/ready").json()["database"] == "ok"


def test_register_login_me_logout():
    api = make_user("x@example.com")
    assert api.get("/api/auth/me").json()["email"] == "x@example.com"
    api.post("/api/auth/logout")
    assert api.get("/api/auth/me").status_code == 401
    r = api.post("/api/auth/login", json={"email": "X@example.com", "password": "correct-horse-1"})
    assert r.status_code == 200


def test_wrong_password_rejected():
    make_user("y@example.com")
    r = Api().post("/api/auth/login", json={"email": "y@example.com", "password": "wrong-password"})
    assert r.status_code == 401


def test_csrf_header_required():
    api = Api()
    r = api.c.post("/api/auth/register", json={"email": "z@example.com", "password": "correct-horse-1"})
    assert r.status_code == 403


def test_login_rate_limited():
    api = Api()
    codes = [api.post("/api/auth/login", json={"email": "n@example.com", "password": "nope-nope-nope"}).status_code
             for _ in range(12)]
    assert 429 in codes


def test_ai_consent_toggle(api):
    assert api.get("/api/auth/me").json()["ai_consent"] is False
    assert api.post("/api/auth/consent", json={"ai_consent": True}).json()["ai_consent"] is True


def test_rate_limit_uses_cf_ip_only_when_trusted(monkeypatch):
    from starlette.requests import Request
    from app.config import get_settings
    from app.deps import client_ip

    def req(peer, cf=None):
        headers = [(b"cf-connecting-ip", cf.encode())] if cf else []
        return Request({"type": "http", "client": (peer, 1234), "headers": headers})
    assert client_ip(req("127.0.0.1", "203.0.113.9")) == "127.0.0.1"  # not trusted by default
    monkeypatch.setattr(get_settings(), "trust_cf_connecting_ip", True)
    assert client_ip(req("127.0.0.1", "203.0.113.9")) == "203.0.113.9"
    assert client_ip(req("198.51.100.7", "203.0.113.9")) == "198.51.100.7"  # spoof from non-local peer ignored


def test_metrics_hidden_outside_dev(monkeypatch):
    from app.config import get_settings
    from app.main import create_app
    from fastapi.testclient import TestClient
    s = get_settings()
    monkeypatch.setattr(s, "env", "prod")
    monkeypatch.setattr(s, "cookie_secure", True)
    monkeypatch.setattr(s, "encryption_key", "aW5zZWN1cmUtdGVzdC1rZXktb25seS0zMmJ5dGVzISE=")
    monkeypatch.setattr(s, "cron_secret", "op-secret")
    c = TestClient(create_app())
    assert c.get("/api/metrics").status_code == 404
    assert c.get("/api/metrics", headers={"Authorization": "Bearer op-secret"}).status_code == 200


def test_worker_client_ip_header_trusted_only_from_local_peer(monkeypatch):
    from starlette.requests import Request
    from app.config import get_settings
    from app.deps import client_ip
    monkeypatch.setattr(get_settings(), "trust_cf_connecting_ip", True)

    def req(peer, headers):
        return Request({"type": "http", "client": (peer, 1), "headers": [(k.encode(), v.encode()) for k, v in headers]})
    assert client_ip(req("127.0.0.1", [("x-cr-client-ip", "203.0.113.7")])) == "203.0.113.7"
    assert client_ip(req("198.51.100.1", [("x-cr-client-ip", "203.0.113.7")])) == "198.51.100.1"
