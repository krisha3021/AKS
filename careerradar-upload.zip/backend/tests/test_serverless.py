"""Serverless (Vercel) mode: tick/cron endpoints, Blob storage backend, runtime config."""
from types import SimpleNamespace

from app.config import get_settings
from app.db import SessionLocal
from app.models import Source, Task
from app.tasks import enqueue


def test_runtime_config(api):
    assert set(api.get("/api/config").json()) == {"live_updates", "poll_seconds", "background"}


def test_cron_requires_secret(api, monkeypatch):
    monkeypatch.setattr(get_settings(), "cron_secret", "s3cret-value-for-tests")
    assert api.get("/api/cron/daily").status_code == 401
    assert api.get("/api/cron/daily", headers={"Authorization": "Bearer wrong"}).status_code == 401
    r = api.get("/api/cron/daily", headers={"Authorization": "Bearer s3cret-value-for-tests"})
    assert r.status_code == 200 and "ran" in r.json()
    assert api.post("/api/admin/migrate").status_code == 401


def test_cron_disabled_when_no_secret_configured(api, monkeypatch):
    monkeypatch.setattr(get_settings(), "cron_secret", None)
    assert api.get("/api/cron/daily", headers={"Authorization": "Bearer "}).status_code == 401


def test_tick_runs_only_the_callers_tasks(api):
    from tests.conftest import make_user
    me = api.get("/api/auth/me").json()["id"]
    other = make_user("other-tick@example.com")
    them = other.get("/api/auth/me").json()["id"]
    with SessionLocal() as db:
        for uid in (me, them):
            enqueue(db, "rescore_user", f"rs:{uid}", {"user_id": uid}, user_id=uid)
        db.commit()
    assert api.post("/api/tick").json()["ran"] >= 1
    with SessionLocal() as db:
        statuses = {t.user_id: t.status for t in db.query(Task).filter(Task.kind == "rescore_user")}
    assert statuses[me] == "done" and statuses[them] == "pending"


def test_blob_backend_stores_only_ciphertext(monkeypatch):
    from app import security
    store = {}

    class FakeBlob:
        def put(self, path, body, **kw):
            assert kw["access"] == "private"
            store[path] = body
        def get(self, path, **kw):
            return SimpleNamespace(content=store[path])
        def delete(self, path):
            store.pop(path)
    monkeypatch.setattr(security, "_blob", lambda: FakeBlob())
    monkeypatch.setattr(get_settings(), "storage_backend", "vercel_blob")
    key = security.store_file(b"SECRET CV TEXT", "user1")
    (path, body), = store.items()
    assert path == f"careerradar/{key}.bin" and b"SECRET CV TEXT" not in body
    assert security.load_file(key, "user1") == b"SECRET CV TEXT"
    security.delete_file(key)
    assert not store


def test_postgres_url_normalised():
    from app.config import _normalise_db_url
    assert _normalise_db_url("postgres://u:p@h/db?sslmode=require") == "postgresql+psycopg://u:p@h/db?sslmode=require"
    assert _normalise_db_url("sqlite:///x.db") == "sqlite:///x.db"


def test_db_storage_backend_end_to_end(api, monkeypatch):
    """CR_STORAGE_BACKEND=db (Cloudflare Container): upload, signed download, and deletion with no disk."""
    from app.fixtures.synthetic_cv import synthetic_cv_docx
    from app.models import FileBlob
    monkeypatch.setattr(get_settings(), "storage_backend", "db")
    data = synthetic_cv_docx()
    prof = api.post("/api/profile/cv", files={"file": ("cv.docx", data, "x")}).json()
    doc_id = prof["documents"][0]["id"]
    with SessionLocal() as db:
        (blob,) = db.query(FileBlob).all()
        assert data not in blob.data  # ciphertext only
    link = api.post(f"/api/documents/{doc_id}/link").json()["url"]
    assert api.get(link).content == data
    assert not get_settings().storage_dir.exists() or not any(get_settings().storage_dir.iterdir())
    api.delete("/api/auth/account")
    with SessionLocal() as db:
        assert db.query(FileBlob).count() == 0
