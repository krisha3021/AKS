import json

import httpx

from app.net import SafeHttpClient

PUBLIC = [(2, 1, 6, "", ("93.184.216.34", 443))]


def public_resolver(host, port, proto=None):
    return PUBLIC


def mock_client(routes: dict, robots: str = "User-agent: *\nAllow: /\n") -> SafeHttpClient:
    """routes: url -> (status, body, headers) or a callable(request) -> httpx.Response."""
    from app import net
    net._robots.clear()  # robots.txt answers are cached per process; tests need their own
    def handler(request: httpx.Request) -> httpx.Response:
        url = str(request.url)
        if url.endswith("/robots.txt"):
            return httpx.Response(200, text=robots)
        r = routes.get(url)
        if r is None:
            return httpx.Response(404, text="not found")
        if callable(r):
            return r(request)
        status, body, *headers = r
        if isinstance(body, (dict, list)):
            body = json.dumps(body)
        return httpx.Response(status, text=body, headers=headers[0] if headers else {})
    return SafeHttpClient(transport=httpx.MockTransport(handler), resolver=public_resolver, check_peer=False)
