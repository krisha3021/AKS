from app.db import SessionLocal
from app.jobstore import IncomingJob, upsert_job
from app.models import Job
from app.fixtures.synthetic_cv import synthetic_cv_docx


def _setup(api, description: str, title="Associate Professor in Computer Science", prefs=None):
    api.post("/api/profile/cv", files={"file": ("cv.docx", synthetic_cv_docx(), "x")})
    if prefs:
        base = api.get("/api/profile").json()["preferences"]
        api.put("/api/profile/preferences", json={**base, **prefs})
    uid = api.get("/api/auth/me").json()["id"]
    with SessionLocal() as db:
        res = upsert_job(db, uid, IncomingJob(title=title, employer="Demo University (SYNTHETIC)",
                                              fields={"description": description, "location_raw": "Doha, Qatar",
                                                      "country": "Qatar"},
                                              source_key="test", source_url="https://example.com/demo/m"))
        db.commit()
        return res.job.id


def _detail(api, job_id):
    return api.get(f"/api/jobs/{job_id}").json()


def test_explanations_cite_cv_and_vacancy_evidence(api):
    jid = _setup(api, "A PhD in Computer Science is essential. Experience of teaching undergraduate courses "
                      "is required. Peer-reviewed publications are desirable.")
    m = _detail(api, jid)["match"]
    reqs = {r["key"]: r for r in m["explanation"]["requirements"]}
    assert reqs["degree:doctorate"]["status"] == "supported" and reqs["degree:doctorate"]["mandatory"] is True
    assert "Ph.D. in Computer Science" in reqs["degree:doctorate"]["cv_evidence"][0]["quote"]
    assert "essential" in reqs["degree:doctorate"]["vacancy_quote"]
    assert reqs["teaching"]["status"] == "supported"
    assert reqs["publications"]["mandatory"] is False
    assert "not a probability" in m["explanation"]["disclaimer"]
    assert set(m["components"]) == {"requirements", "keywords", "preferences", "freshness"}


def test_confirmed_mandatory_mismatch_is_visible_and_caps_score(api):
    jid = _setup(api, "Minimum 15 years of post-PhD experience is required. PhD essential.")
    m = _detail(api, jid)["match"]
    assert m["score"] <= 20
    assert any("15 years" in d for d in m["explanation"]["deal_breakers"])
    card = api.get("/api/jobs").json()["items"][0]
    assert card["deal_breaker"] is True


def test_missing_visa_information_stays_unknown(api):
    jid = _setup(api, "PhD essential.", prefs={"needs_visa_sponsorship": True})
    m = _detail(api, jid)["match"]
    assert m["explanation"]["visa_sponsorship"] == "not_stated"
    hc = m["explanation"]["hard_constraints"][0]
    assert hc["status"] == "unknown" and not m["explanation"]["deal_breakers"]
    with SessionLocal() as db:
        assert db.get(Job, jid).visa_sponsorship == "not_stated"


def test_stated_no_sponsorship_is_a_deal_breaker_only_if_user_needs_it(api):
    jid = _setup(api, "Applicants must already have the right to work in the country. PhD essential.",
                 prefs={"needs_visa_sponsorship": True})
    m = _detail(api, jid)["match"]
    assert any("visa" in d.lower() for d in m["explanation"]["deal_breakers"])


def test_title_alone_never_implies_requirements(api):
    jid = _setup(api, "", title="Professor of Neuroscience")
    m = _detail(api, jid)["match"]
    assert m["explanation"]["requirements"] == []
    assert "no checkable requirements" in m["explanation"]["summary"]


def test_excluded_employer_is_deal_breaker(api):
    jid = _setup(api, "PhD essential.", prefs={"excluded_employers": ["Demo University"]})
    assert _detail(api, jid)["match"]["explanation"]["deal_breakers"]


def test_search_filters_and_tenant_isolation(api):
    from tests.conftest import make_user
    jid = _setup(api, "EEG signal processing and brain-computer interfaces. PhD essential.")
    assert api.get("/api/jobs", params={"q": "EEG"}).json()["total"] == 1
    assert api.get("/api/jobs", params={"q": "astrophysics"}).json()["total"] == 0
    assert api.get("/api/jobs", params={"scope": "national"}).json()["total"] == 0
    assert api.get("/api/jobs", params={"country": "Qatar", "academic": True}).json()["total"] == 1
    assert api.get("/api/jobs", params={"visa_stated": True}).json()["total"] == 0
    other = make_user("intruder@example.com")
    assert other.get("/api/jobs").json()["total"] == 0
    assert other.get(f"/api/jobs/{jid}").status_code == 404
    assert other.delete(f"/api/jobs/{jid}").status_code == 404
    assert other.post("/api/applications", json={"job_id": jid}).status_code == 404


def test_degree_subject_mismatch_is_unknown_not_a_confirmed_mismatch(api):
    jid = _setup(api, "A PhD in History is essential.", title="Professor of History")
    m = _detail(api, jid)["match"]
    req = m["explanation"]["requirements"][0]
    assert req["status"] == "unknown" and "History" in req["note"]
    assert not m["explanation"]["deal_breakers"]


def test_related_field_wording_gives_unknown_not_mismatch(api):
    jid = _setup(api, "A PhD in Electrical Engineering or a related discipline is essential.")
    req = _detail(api, jid)["match"]["explanation"]["requirements"][0]
    assert req["status"] == "unknown" and "related" in req["note"]


def test_title_similarity_needs_whole_target():
    from app.matching import title_similarity
    assert title_similarity("Assistant Professor", "Assistant Professor in AI") == 1.0
    assert title_similarity("Assistant Professor", "Professor of History") < 0.6
