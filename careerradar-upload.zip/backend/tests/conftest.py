import os
import shutil
import tempfile
from pathlib import Path

_TMP = Path(tempfile.mkdtemp(prefix="careerradar-test-"))
os.environ["CR_DATABASE_URL"] = f"sqlite:///{(_TMP / 'test.db').as_posix()}"
os.environ["CR_STORAGE_DIR"] = str(_TMP / "files")
os.environ["CR_RUN_WORKER_IN_PROCESS"] = "false"
os.environ["CR_ANTHROPIC_API_KEY"] = ""

import pytest  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from app.db import Base, engine  # noqa: E402
from app.main import create_app  # noqa: E402
from app.security import limiter  # noqa: E402

FIXTURES = Path(__file__).parent / "fixtures"


@pytest.fixture(autouse=True)
def _fresh_db():
    Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    from app.search import ensure_fts
    ensure_fts(engine)
    limiter.reset()
    shutil.rmtree(_TMP / "files", ignore_errors=True)
    yield


def pytest_sessionfinish(session, exitstatus):
    engine.dispose()
    shutil.rmtree(_TMP, ignore_errors=True)


class Api:
    """TestClient wrapper that always sends the CSRF header."""

    def __init__(self) -> None:
        self.c = TestClient(create_app())

    def __getattr__(self, name):
        method = getattr(self.c, name)
        if name in {"post", "put", "patch", "delete"}:
            def wrapped(url, **kw):
                kw.setdefault("headers", {})["x-cr-csrf"] = "1"
                return method(url, **kw)
            return wrapped
        return method


def make_user(email: str = "a@example.com") -> Api:
    api = Api()
    r = api.post("/api/auth/register", json={"email": email, "password": "correct-horse-1"})
    assert r.status_code == 200, r.text
    return api


@pytest.fixture
def api() -> Api:
    return make_user()
