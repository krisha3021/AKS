import subprocess
import sys
from pathlib import Path

from sqlalchemy import create_engine, inspect

from app.db import Base


def test_migrations_match_models(tmp_path: Path):
    url = f"sqlite:///{(tmp_path / 'm.db').as_posix()}"
    backend = Path(__file__).resolve().parents[1]
    r = subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=backend,
                       env={**__import__("os").environ, "CR_DATABASE_URL": url}, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr
    eng = create_engine(url)
    insp = inspect(eng)
    for name, table in Base.metadata.tables.items():
        cols = {c["name"] for c in insp.get_columns(name)}
        assert cols == {c.name for c in table.columns}, f"{name} drifted from its migration"
    assert "jobs_fts" in insp.get_table_names()
    eng.dispose()
