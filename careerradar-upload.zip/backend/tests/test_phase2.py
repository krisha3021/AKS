from datetime import timedelta

import pytest
from sqlalchemy import select

from app import pipeline
from app.db import SessionLocal, utcnow
from app.models import Job, JobChange, JobStatus, Notification, Source, Task
from app.net import BlockedError, check_url, is_public_ip
from app.tasks import drain, enqueue
from tests.helpers import mock_client, public_resolver

GH = "https://boards-api.greenhouse.io/v1/boards/demo/jobs?content=true"


def _gh_job(i, deadline=None, title="Assistant Professor of Computer Science"):
    j = {"id": i, "title": title, "updated_at": "2026-10-01T00:00:00Z", "first_published": "2026-09-30T10:00:00Z",
         "location": {"name": "Bengaluru, India"}, "absolute_url": f"https://boards.greenhouse.io/demo/jobs/{i}",
         "content": "&lt;p&gt;A PhD is essential.&lt;/p&gt;", "departments": [{"name": "CSE"}]}
    if deadline:
        j["application_deadline"] = deadline
    return j


@pytest.fixture
def routes(monkeypatch):
    table = {}
    monkeypatch.setattr(pipeline, "http_factory", lambda: mock_client(table))
    return table


def _source(api, routes, jobs):
    routes[GH] = (200, {"jobs": jobs})
    r = api.post("/api/sources", json={"connector_key": "greenhouse", "name": "Demo board",
                                       "config": {"board_token": "demo", "employer": "Demo Corp (SYNTHETIC)"}})
    assert r.status_code == 201, r.text
    return r.json()["id"]


def _run(src_id=None):
    if src_id:
        with SessionLocal() as db:
            enqueue(db, "fetch_source", f"fetch:{src_id}", {"source_id": src_id})
            db.commit()
    drain()


# ---- SSRF guard ----

@pytest.mark.parametrize("ip", ["127.0.0.1", "10.0.0.5", "192.168.1.1", "169.254.169.254", "::1",
                                "::ffff:127.0.0.1", "100.64.0.1", "0.0.0.0", "fd00::1"])
def test_private_addresses_rejected(ip):
    assert not is_public_ip(ip)
    with pytest.raises(BlockedError):
        check_url("https://evil.example/x", resolver=lambda *a, **k: [(2, 1, 6, "", (ip, 443))])


@pytest.mark.parametrize("url", ["ftp://example.com/a", "file:///etc/passwd", "http://user:pw@example.com/",
                                 "https://example.com:8080/"])
def test_bad_protocols_ports_rejected(url):
    with pytest.raises(BlockedError):
        check_url(url, resolver=public_resolver)


def test_redirect_to_private_address_blocked():
    import httpx

    from app.net import SafeHttpClient

    def resolver(host, port, proto=None):
        return [(2, 1, 6, "", ("10.0.0.1" if host == "internal.example" else "93.184.216.34", port))]

    def handler(req):
        if req.url.path == "/robots.txt":
            return httpx.Response(200, text="")
        return httpx.Response(302, headers={"location": "http://internal.example/admin"})
    client = SafeHttpClient(transport=httpx.MockTransport(handler), resolver=resolver, check_peer=False)
    with pytest.raises(BlockedError):
        client.get("https://example.com/job")


def test_robots_disallow_respected():
    from app.connectors.feeds import RssFeed
    client = mock_client({"https://example.com/feed": (200, "<rss/>")}, robots="User-agent: *\nDisallow: /\n")
    with pytest.raises(BlockedError):
        RssFeed().discover({"url": "https://example.com/feed"}, client)


# ---- connectors & lifecycle ----

def test_greenhouse_connector_creates_verified_jobs(api, routes):
    _run(_source(api, routes, [_gh_job(1), _gh_job(2, title="Data Scientist")]))
    with SessionLocal() as db:
        jobs = list(db.scalars(select(Job)))
        assert len(jobs) == 2 and all(j.status == JobStatus.OPEN_VERIFIED for j in jobs)
        j = next(j for j in jobs if j.title.startswith("Assistant"))
        assert j.country == "India" and j.scope == "national" and j.posted_date.day == 30
        assert j.first_seen_at != j.posted_date  # first-seen is never used as the publication date
        assert "PhD is essential" in j.description
    srcs = api.get("/api/sources").json()
    assert srcs[0]["health"] == "ok"


def test_changed_deadline_detected_and_alerted(api, routes):
    sid = _source(api, routes, [_gh_job(1, deadline="2026-12-01")])
    _run(sid)
    routes[GH] = (200, {"jobs": [_gh_job(1, deadline="2026-12-15")]})
    _run(sid)
    with SessionLocal() as db:
        ch = db.scalar(select(JobChange).where(JobChange.field == "deadline_at"))
        assert ch and "2026-12-15" in ch.new_value and ch.material
        assert db.scalar(select(Notification).where(Notification.kind == "deadline_changed"))


def test_temporary_failure_does_not_close_jobs(api, routes):
    sid = _source(api, routes, [_gh_job(1)])
    _run(sid)
    routes[GH] = (503, "down")
    _run(sid)
    with SessionLocal() as db:
        job = db.scalar(select(Job))
        assert job.status == JobStatus.OPEN_VERIFIED
        task = db.scalar(select(Task).where(Task.kind == "fetch_source", Task.status == "pending"))
        assert task and task.attempts == 1 and task.run_at >= utcnow() - timedelta(seconds=1)  # backoff retry
        src = db.get(Source, sid)
        assert src.last_error.startswith("temporary") and src.consecutive_failures == 1
    assert api.get("/api/sources").json()[0]["health"] == "failing"


def test_job_missing_from_listing_removed_only_after_two_misses_24h_apart(api, routes):
    sid = _source(api, routes, [_gh_job(1), _gh_job(2)])
    _run(sid)
    routes[GH] = (200, {"jobs": [_gh_job(1)]})
    _run(sid)
    with SessionLocal() as db:
        j2 = db.scalar(select(Job).where(Job.canonical_url.like("%/2")))
        assert j2.status == JobStatus.OPEN_VERIFIED and j2.consecutive_missing == 1
        j2.missing_since = utcnow() - timedelta(hours=25)
        db.get(Source, sid).last_checked_at = None
        db.commit()
    _run(sid)
    with SessionLocal() as db:
        j2 = db.scalar(select(Job).where(Job.canonical_url.like("%/2")))
        assert j2.status == JobStatus.REMOVED
        assert db.scalar(select(Notification).where(Notification.kind == "closed"))


def test_vacancy_url_explicit_closure_and_jsonld(api, routes):
    url = "https://jobs.example.edu/vacancy/42"
    routes[url] = (200, '<html><script type="application/ld+json">{"@context":"https://schema.org",'
                        '"@type":"JobPosting","title":"Lecturer in AI","hiringOrganization":{"name":"Example Uni"},'
                        '"datePosted":"2026-10-01","validThrough":"2026-11-30T23:59:00+00:00",'
                        '"jobLocation":{"@type":"Place","address":{"addressLocality":"Leeds",'
                        '"addressCountry":"United Kingdom"}}}</script><p>Apply now</p></html>')
    r = api.post("/api/jobs", json={"url": url, "title": "Lecturer in AI", "employer": "Example Uni"})
    jid = r.json()["id"]
    with SessionLocal() as db:
        assert db.get(Job, jid).status == JobStatus.IMPORTED_UNVERIFIED
    drain()
    with SessionLocal() as db:
        j = db.get(Job, jid)
        assert j.status == JobStatus.OPEN_VERIFIED and j.deadline_at.month == 11 and j.country == "United Kingdom"
        j.last_checked_at = None
        db.commit()
    routes[url] = (200, "<html><h1>Lecturer in AI</h1><p>This vacancy has closed.</p></html>")
    api.post(f"/api/jobs/{jid}/refresh")
    drain()
    with SessionLocal() as db:
        assert db.get(Job, jid).status == JobStatus.CLOSED_EXPLICIT


def test_vacancy_url_network_error_marks_unavailable_not_closed(api, routes):
    import httpx
    url = "https://jobs.example.edu/vacancy/7"

    def boom(req):
        raise httpx.ConnectError("refused")
    routes[url] = boom
    jid = api.post("/api/jobs", json={"url": url, "title": "Reader"}).json()["id"]
    drain()
    with SessionLocal() as db:
        assert db.get(Job, jid).status == JobStatus.VERIFICATION_UNAVAILABLE


def test_deadline_sweep_respects_deadline_kinds(api):
    csv = (b"title,organisation,deadline\nA,Demo,2020-01-01\nB,Demo,Review begins 2020-01-01\n"
           b"C,Demo,Open until filled\n")
    p = api.post("/api/imports/preview", files={"file": ("d.csv", csv, "x")}).json()
    api.post(f"/api/imports/{p['document_id']}/commit", json={"mapping": p["suggested_mapping"]})
    with SessionLocal() as db:
        enqueue(db, "sweep", "sweep", {})
        db.commit()
    drain()
    with SessionLocal() as db:
        st = {j.title: j.status for j in db.scalars(select(Job))}
    assert st == {"A": JobStatus.DEADLINE_PASSED, "B": JobStatus.IMPORTED_UNVERIFIED,
                  "C": JobStatus.IMPORTED_UNVERIFIED}


def test_task_dead_letter_after_max_attempts():
    from app.tasks import RetryableError, handler

    @handler("always_fails")
    def _f(db, task):
        raise RetryableError("nope")
    with SessionLocal() as db:
        enqueue(db, "always_fails", "af", {}, max_attempts=2)
        db.commit()
    for _ in range(3):
        with SessionLocal() as db:
            for t in db.scalars(select(Task)):
                t.run_at = utcnow() - timedelta(seconds=1)
            db.commit()
        drain()
    with SessionLocal() as db:
        t = db.scalar(select(Task).where(Task.kind == "always_fails"))
        assert t.status == "dead" and t.attempts == 2


def test_enqueue_is_idempotent():
    with SessionLocal() as db:
        assert enqueue(db, "sweep", "k1", {}) is True
        assert enqueue(db, "sweep", "k1", {}) is False
        db.commit()


def test_unsupported_sources_are_explicit(api):
    caps = {c["key"]: c for c in api.get("/api/sources/capabilities").json()}
    for k in ("naukri", "linkedin", "naukrigulf", "nature_careers", "euraxess"):
        assert caps[k]["automated"] is False and caps[k]["access"] == "manual_only"
    r = api.post("/api/sources", json={"connector_key": "naukri", "name": "x", "config": {}})
    assert r.status_code == 422 and "spreadsheet" in r.json()["detail"]


def test_events_published_on_processing(api, routes):
    from app import events
    got = []
    original = events.publish
    pipeline.publish = lambda uid, ev, data: got.append(ev) or original(uid, ev, data)
    try:
        _run(_source(api, routes, [_gh_job(1)]))
    finally:
        pipeline.publish = original
    assert "jobs_changed" in got and "source_health" in got


def test_retention_deletes_expired_private_data(api):
    from app.config import get_settings
    from app.fixtures.synthetic_cv import synthetic_cv_docx
    from app.models import Document, User
    api.post("/api/profile/cv", files={"file": ("cv.docx", synthetic_cv_docx(), "x")})
    csv = b"title,organisation,deadline\nOld closed job,Demo,2020-01-01\nLive lead,Demo,\n"
    p = api.post("/api/imports/preview", files={"file": ("d.csv", csv, "x")}).json()
    api.post(f"/api/imports/{p['document_id']}/commit", json={"mapping": p["suggested_mapping"]})
    with SessionLocal() as db:
        enqueue(db, "sweep", "sweep-r", {})
        db.commit()
    drain()
    with SessionLocal() as db:
        db.query(User).update({"retention_days": 30})
        old = utcnow() - timedelta(days=31)
        db.query(Document).update({"created_at": old})
        db.query(Job).filter(Job.title == "Old closed job").update({"updated_at": old})
        db.commit()
        enqueue(db, "retention", "ret-test", {})
        db.commit()
    drain()
    with SessionLocal() as db:
        assert db.query(Document).count() == 0
        assert [j.title for j in db.query(Job)] == ["Live lead"]  # open leads are kept
    assert not any(get_settings().storage_dir.iterdir())


def test_production_refuses_dev_key(monkeypatch):
    from app.config import get_settings
    from app.main import create_app
    monkeypatch.setattr(get_settings(), "env", "prod")
    with pytest.raises(RuntimeError):
        create_app()
