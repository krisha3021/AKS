import io

from openpyxl import Workbook
from sqlalchemy import select

from app.db import SessionLocal
from app.importer import csv_safe
from app.models import Job, JobSource, JobStatus
from tests.conftest import FIXTURES, make_user


def _upload(api, name: str, data: bytes):
    r = api.post("/api/imports/preview", files={"file": (name, data, "application/octet-stream")})
    assert r.status_code == 200, r.text
    return r.json()


def _commit(api, preview, mapping=None):
    r = api.post(f"/api/imports/{preview['document_id']}/commit",
                 json={"mapping": mapping or preview["suggested_mapping"]})
    assert r.status_code == 200, r.text
    return r.json()


def test_existing_schema_imports_without_restructuring(api):
    p = _upload(api, "jobs.csv", (FIXTURES / "sample_jobs.csv").read_bytes())
    assert p["suggested_mapping"] == {"scope": "scope", "title": "title", "organisation": "organisation",
                                      "location": "location", "url": "url"}
    s = _commit(api, p)
    assert s["total_rows"] == 7
    assert s["created_count"] == 3          # rows 2,3,4
    assert s["merged_count"] == 1           # row 5 duplicates row 2 (trailing slash URL)
    assert s["failed_count"] == 3           # rows 6,7,8


def test_invalid_rows_give_actionable_errors(api):
    s = _commit(api, _upload(api, "jobs.csv", (FIXTURES / "sample_jobs.csv").read_bytes()))
    by_row = {e["row"]: e for e in s["errors"]}
    assert "missing required 'title'" in by_row[6]["errors"]
    assert any("http://" in e for e in by_row[7]["errors"])
    assert any("scope must be" in e for e in by_row[8]["errors"])
    assert by_row[6]["raw"]["organisation"] == "Missing Title College (DEMO)"  # original values kept


def test_imported_jobs_are_never_marked_open(api):
    _commit(api, _upload(api, "jobs.csv", (FIXTURES / "sample_jobs.csv").read_bytes()))
    with SessionLocal() as db:
        statuses = set(db.scalars(select(Job.status)))
    assert statuses == {JobStatus.IMPORTED_UNVERIFIED}


def test_claimed_open_status_in_file_is_ignored(api):
    csv = b"title,organisation,url,status\nProfessor,Demo U,https://example.com/demo/p,Open\n"
    _commit(api, _upload(api, "s.csv", csv))
    with SessionLocal() as db:
        job = db.scalar(select(Job))
        assert job.status == JobStatus.IMPORTED_UNVERIFIED
        assert db.scalar(select(JobSource)).raw["_claimed_status"] == "Open"


def test_duplicate_merge_keeps_all_provenance(api):
    _commit(api, _upload(api, "jobs.csv", (FIXTURES / "sample_jobs.csv").read_bytes()))
    _commit(api, _upload(api, "again.csv", (FIXTURES / "sample_jobs.csv").read_bytes()))
    with SessionLocal() as db:
        job = db.scalar(select(Job).where(Job.title.like("Assistant Professor%")))
        rows = sorted((s.import_row for s in job.sources))
        assert len(job.sources) == 4  # 2 rows x 2 imports, all retained
        assert rows == [2, 2, 5, 5]
        assert db.query(Job).count() == 3


def test_aliases_and_location_parsing(api):
    csv = (b"Job Title,Employer,City,Application_URL,Closing_Date\n"
           b"Associate Professor,Demo Univ,\"Doha, Qatar\",https://example.com/demo/a,2026-12-31\n")
    p = _upload(api, "alias.csv", csv)
    assert p["suggested_mapping"] == {"Job Title": "title", "Employer": "organisation", "City": "location",
                                      "Application_URL": "application_url", "Closing_Date": "deadline"}
    _commit(api, p)
    with SessionLocal() as db:
        job = db.scalar(select(Job))
        assert (job.country, job.city, job.scope) == ("Qatar", "Doha", "international")
        assert job.deadline_kind == "closing" and job.deadline_at.year == 2026
        assert job.visa_sponsorship == "not_stated"


def test_ambiguous_date_is_flagged_not_guessed(api):
    csv = b"title,organisation,posted_date\nLecturer,Demo U,03/04/2026\n"
    s = _commit(api, _upload(api, "d.csv", csv))
    assert s["failed_count"] == 1 and "ambiguous" in s["errors"][0]["errors"][0]


def test_open_until_filled_is_not_a_deadline(api):
    csv = b"title,organisation,deadline\nLecturer,Demo U,Open until filled\n"
    _commit(api, _upload(api, "d.csv", csv))
    with SessionLocal() as db:
        job = db.scalar(select(Job))
        assert job.deadline_kind == "open_until_filled" and job.deadline_at is None


def _xlsx(rows, formula_cell=None) -> bytes:
    wb = Workbook()
    ws = wb.active
    for r in rows:
        ws.append(r)
    if formula_cell:
        ws[formula_cell] = "=HYPERLINK(\"https://evil.example\",\"x\")"
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def test_xlsx_import_and_formulas_are_never_evaluated(api):
    data = _xlsx([["title", "organisation", "url"],
                  ["Professor of AI", "Demo U", "https://example.com/demo/1"],
                  ["Reader", "Demo U", "placeholder"]], formula_cell="C3")
    s = _commit(api, _upload(api, "jobs.xlsx", data))
    assert s["created_count"] == 1 and s["failed_count"] == 1
    assert "formula" in s["errors"][0]["errors"][0]


def test_macro_and_wrong_types_rejected(api):
    r = api.post("/api/imports/preview", files={"file": ("m.xlsm", b"PK\x03\x04", "x")})
    assert r.status_code == 415
    r = api.post("/api/imports/preview", files={"file": ("fake.xlsx", b"not a zip", "x")})
    assert r.status_code == 415


def test_tenant_isolation_on_imports(api):
    p = _upload(api, "jobs.csv", (FIXTURES / "sample_jobs.csv").read_bytes())
    other = make_user("b@example.com")
    r = other.post(f"/api/imports/{p['document_id']}/commit", json={"mapping": p["suggested_mapping"]})
    assert r.status_code == 404


def test_csv_export_formula_injection_neutralised():
    assert csv_safe("=1+1") == "'=1+1"
    assert csv_safe("@SUM(A1)") == "'@SUM(A1)"
    assert csv_safe("Professor") == "Professor"


def test_same_place_written_differently_merges(api):
    csv = (b"title,organisation,location\nLecturer in AI,Example University,\"Leeds, UK\"\n"
           b"Lecturer in AI,The Example University,\"Leeds, United Kingdom\"\n"
           b"Lecturer in AI,Example University,\"London, UK\"\n")
    s = _commit(api, _upload(api, "p.csv", csv))
    assert (s["created_count"], s["merged_count"]) == (2, 1)
