from app.db import SessionLocal
from app.jobstore import IncomingJob, upsert_job
from app.fixtures.synthetic_cv import synthetic_cv_docx


def _job(api, desc="A PhD is essential. Please submit a cover letter, research statement and references."):
    uid = api.get("/api/auth/me").json()["id"]
    with SessionLocal() as db:
        res = upsert_job(db, uid, IncomingJob(title="Lecturer in Neuroengineering", employer="Demo Uni (SYNTHETIC)",
                                              fields={"description": desc}, source_key="test",
                                              source_url="https://example.com/demo/app"))
        db.commit()
        return res.job.id


def test_kanban_flow_and_required_documents(api):
    jid = _job(api)
    a = api.post("/api/applications", json={"job_id": jid}).json()
    assert a["stage"] == "interested"
    assert {d["name"] for d in a["required_documents"]} == {"cover letter", "research statement", "references"}
    for stage in ("shortlisted", "preparing", "applied", "interview"):
        a = api.patch(f"/api/applications/{a['id']}", json={"stage": stage}).json()
    assert a["applied_at"] and [h["stage"] for h in a["history"]] == \
        ["interested", "shortlisted", "preparing", "applied", "interview"]
    assert api.patch(f"/api/applications/{a['id']}", json={"stage": "hired"}).status_code == 422


def test_drafts_are_grounded_and_flag_missing_info(api):
    api.post("/api/profile/cv", files={"file": ("cv.docx", synthetic_cv_docx(), "x")})
    jid = _job(api)
    d = api.post("/api/drafts", json={"job_id": jid, "kind": "cover_letter"}).json()
    assert "Ph.D. in Computer Science" in d["content"]
    assert "never sends" in d["notice"]
    d2 = api.post("/api/drafts", json={"job_id": jid, "kind": "research_statement_outline"}).json()
    assert "grants" in d2["missing_info"]  # synthetic CV has no grants: flagged, not invented


def test_approved_draft_is_frozen_and_nothing_can_be_sent(api):
    jid = _job(api)
    d = api.post("/api/drafts", json={"job_id": jid, "kind": "application_email"}).json()
    a = api.post(f"/api/drafts/{d['id']}/approve").json()
    assert a["approved"] and a["approved_sha256"]
    assert api.put(f"/api/drafts/{d['id']}", json={"content": "changed"}).status_code == 409
    # No route exists that can submit or send anything externally.
    from app.main import create_app
    paths = set(create_app().openapi()["paths"])
    assert "/api/drafts/{draft_id}/approve" in paths
    assert not any(w in p for p in paths for w in ("send", "submit", "email", "apply"))
