# Starts CareerRadar for public access through a Cloudflare Quick Tunnel (trycloudflare.com).
#
#   powershell -ExecutionPolicy Bypass -File deploy\start-public.ps1            # server + tunnel
#   powershell -ExecutionPolicy Bypass -File deploy\start-public.ps1 -NoTunnel  # server only (local check)
#
# - Uses its OWN database and file store (backend\data\public.db, backend\data\public-files),
#   separate from local development data.
# - Generates deploy\.env.public (encryption key + operator secret) on first run. That file is
#   git-ignored. Back it up: losing the encryption key makes stored CVs unreadable.
# - Binds the server to 127.0.0.1 only; the tunnel is the only way in from outside.
# - Quick Tunnels: random URL per run, no uptime guarantee, no Server-Sent Events, testing use.
param([switch]$NoTunnel, [int]$Port = 8000)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Backend = Join-Path $Root "backend"
$Frontend = Join-Path $Root "frontend"
$Python = Join-Path $Backend ".venv\Scripts\python.exe"
$EnvFile = Join-Path $PSScriptRoot ".env.public"
$Data = Join-Path $Backend "data"

function Fail($msg) { Write-Host "ERROR: $msg" -ForegroundColor Red; exit 1 }

if (-not (Test-Path $Python)) { Fail "Backend environment missing. Run:  cd backend; uv sync" }

# 1. Secrets (created once, never printed)
if (-not (Test-Path $EnvFile)) {
    # Single quotes inside: Windows PowerShell 5.1 strips embedded double quotes from native-exe arguments.
    $gen = "import base64,os,secrets;print('CR_ENCRYPTION_KEY='+base64.urlsafe_b64encode(os.urandom(32)).decode());print('CRON_SECRET='+secrets.token_urlsafe(32))"
    $lines = & $Python -c $gen
    if ($LASTEXITCODE -ne 0) { Fail "Could not generate secrets" }
    [IO.File]::WriteAllLines($EnvFile, $lines, (New-Object Text.UTF8Encoding $false))
    Write-Host "Created deploy\.env.public with new secrets. BACK THIS FILE UP (it is not in git)." -ForegroundColor Yellow
}
foreach ($line in Get-Content $EnvFile) {
    if ($line -match '^\s*([A-Z_][A-Z0-9_]*)=(.*)$') { Set-Item -Path "Env:$($Matches[1])" -Value $Matches[2] }
}
if (-not $env:CR_ENCRYPTION_KEY -or -not $env:CRON_SECRET) { Fail "deploy\.env.public is missing CR_ENCRYPTION_KEY or CRON_SECRET" }

# 2. Production settings for this mode
New-Item -ItemType Directory -Force -Path $Data | Out-Null
$env:CR_ENV = "prod"
$env:CR_COOKIE_SECURE = "true"                 # tunnel URL is HTTPS
$env:CR_LIVE_UPDATES = "false"                 # quick tunnels don't support SSE -> 1-minute polling
$env:CR_RUN_WORKER_IN_PROCESS = "true"         # background refreshes while this PC runs
$env:CR_TRUST_CF_CONNECTING_IP = "true"        # per-visitor rate limits behind the tunnel
$env:CR_DATABASE_URL = "sqlite:///" + (Join-Path $Data "public.db").Replace('\', '/')
$env:CR_STORAGE_DIR = Join-Path $Data "public-files"

# 3. Database migrations
Push-Location $Backend
try {
    & $Python -m alembic upgrade head
    if ($LASTEXITCODE -ne 0) { Fail "Database migration failed" }
} finally { Pop-Location }

# 4. Frontend build (only if missing)
if (-not (Test-Path (Join-Path $Frontend "dist\index.html"))) {
    Write-Host "Building frontend..."
    Push-Location $Frontend
    try {
        if (-not (Test-Path "node_modules")) { npm ci --no-audit --no-fund; if ($LASTEXITCODE -ne 0) { Fail "npm ci failed" } }
        npm run build; if ($LASTEXITCODE -ne 0) { Fail "Frontend build failed" }
    } finally { Pop-Location }
}

# 5. Start the API (localhost only)
$busy = Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue
if ($busy) { Fail "Port $Port is already in use. Stop the other server or pass -Port 8010" }
$Log = Join-Path $Data "public-server.log"
$server = Start-Process -FilePath $Python -WorkingDirectory $Backend -PassThru -WindowStyle Hidden `
    -ArgumentList @("-m", "uvicorn", "app.main:app", "--host", "127.0.0.1", "--port", "$Port") `
    -RedirectStandardOutput $Log -RedirectStandardError "$Log.err"
try {
    $ready = $false
    for ($i = 0; $i -lt 30; $i++) {
        Start-Sleep -Seconds 1
        if ($server.HasExited) { Fail "Server exited. See $Log.err" }
        try {
            $r = Invoke-RestMethod -Uri "http://127.0.0.1:$Port/api/health/ready" -TimeoutSec 3
            if ($r.status -eq "ok") { $ready = $true; break }
        } catch { }
    }
    if (-not $ready) { Fail "Server did not become ready. See $Log.err" }
    Write-Host "Server is up on http://127.0.0.1:$Port (logs: $Log)" -ForegroundColor Green

    if ($NoTunnel) {
        Write-Host "Server running (no quick tunnel). If you set up the workers.dev Worker + tunnel (DEPLOY.md), your site is live now. Keep this window open; Ctrl+C stops it."
        Wait-Process -Id $server.Id
    } else {
        $cf = Get-Command cloudflared -ErrorAction SilentlyContinue
        if (-not $cf) { Fail "cloudflared is not installed. Run:  winget install --id Cloudflare.cloudflared  (then open a NEW terminal)" }
        Write-Host ""
        Write-Host "Starting Cloudflare Quick Tunnel. Your public address is the https://....trycloudflare.com line below." -ForegroundColor Cyan
        Write-Host "Keep this window open. Press Ctrl+C to stop both the tunnel and the server." -ForegroundColor Cyan
        & $cf.Source tunnel --no-autoupdate --url "http://127.0.0.1:$Port"
    }
} finally {
    if (-not $server.HasExited) { Stop-Process -Id $server.Id -Force }
    Write-Host "Server stopped."
}
