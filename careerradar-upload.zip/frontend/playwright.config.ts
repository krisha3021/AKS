import { defineConfig } from "@playwright/test";

// Runs against the FastAPI server serving the built SPA (npm run build first).
export default defineConfig({
  testDir: "./e2e",
  use: { baseURL: process.env.CR_BASE_URL ?? "http://localhost:8000" },
  webServer: process.env.CR_BASE_URL ? undefined : {
    command: "cd ../backend && .venv/Scripts/python -m uvicorn app.main:app --port 8000",
    url: "http://localhost:8000/api/health/ready",
    reuseExistingServer: true,
    timeout: 60_000,
  },
});
