import { expect, test } from "@playwright/test";

const csv = "scope,title,organisation,location,url\n" +
  "national,Assistant Professor (E2E TEST),Synthetic Institute (DEMO),\"Patiala, India\",https://example.com/e2e/1\n" +
  "international,,Missing Title (DEMO),\"Leeds, UK\",https://example.com/e2e/2\n";

test("register, import the standard CSV, see unverified leads and row errors", async ({ page }) => {
  const email = `e2e-${Date.now()}@careerradar.test`;
  await page.goto("/");
  await page.getByText("New here? Create an account").click();
  await page.getByLabel("Email").fill(email);
  await page.getByLabel(/Password/).fill(`e2e-${Date.now()}-pass`);
  await page.getByRole("button", { name: "Create account" }).click();
  await expect(page.getByText("Live updates")).toBeVisible();

  await page.goto("/#/import");
  await page.getByLabel("Job list file").setInputFiles({ name: "jobs.csv", mimeType: "text/csv", buffer: Buffer.from(csv) });
  await expect(page.getByText(/Map columns/)).toBeVisible();
  await page.getByRole("button", { name: /Import 2 rows/ }).click();
  await expect(page.getByText("missing required 'title'")).toBeVisible();

  await page.getByRole("button", { name: "View jobs" }).click();
  await expect(page.getByText("Assistant Professor (E2E TEST)")).toBeVisible();
  await expect(page.getByText("Imported · not verified")).toBeVisible();
  await expect(page.getByText(/not your chance of selection/)).toBeVisible();

  await page.goto("/#/sources");
  await expect(page.getByText("No — manual import / link-out only").first()).toBeVisible();
});
