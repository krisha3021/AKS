import { useEffect, useRef, useState } from "react";
import type { Notice } from "./types";

export type LiveState = "connecting" | "live" | "reconnecting" | "polling";
interface RuntimeConfig { live_updates: boolean; poll_seconds: number; background: string }

/** Dashboard updates. With a persistent server: SSE with automatic reconnect (refetch on every
 *  (re)connect, so missed events are never lost data). On serverless hosting: poll /api/tick,
 *  which also runs this user's due background work, then refetch. */
export function useEvents(enabled: boolean, onChange: () => void, onNotice: (n: Notice) => void): LiveState {
  const [state, setState] = useState<LiveState>("connecting");
  const cb = useRef({ onChange, onNotice });
  cb.current = { onChange, onNotice };

  useEffect(() => {
    if (!enabled) return;
    let es: EventSource | null = null;
    let retry = 1000;
    let timer: number | undefined;
    let closed = false;
    let debounce: number | undefined;
    const changed = () => {
      window.clearTimeout(debounce);
      debounce = window.setTimeout(() => cb.current.onChange(), 300);
    };
    const connect = () => {
      es = new EventSource("/api/events", { withCredentials: true });
      es.addEventListener("hello", () => { retry = 1000; setState("live"); changed(); });
      es.addEventListener("jobs_changed", changed);
      es.addEventListener("source_health", changed);
      es.addEventListener("notification", (e) => cb.current.onNotice(JSON.parse((e as MessageEvent).data)));
      es.onerror = () => {
        es?.close();
        if (closed) return;
        setState("reconnecting");
        timer = window.setTimeout(connect, retry + Math.random() * 500);
        retry = Math.min(retry * 2, 30000);
      };
    };
    const poll = async (seconds: number) => {
      if (closed) return;
      if (document.visibilityState === "visible") {
        try {
          await fetch("/api/tick", { method: "POST", credentials: "same-origin", headers: { "x-cr-csrf": "1" } });
        } catch { /* offline; try again next round */ }
        changed();
      }
      timer = window.setTimeout(() => poll(seconds), seconds * 1000);
    };
    fetch("/api/config").then((r) => r.json()).then((cfg: RuntimeConfig) => {
      if (closed) return;
      if (cfg.live_updates && typeof EventSource !== "undefined") connect();
      else { setState("polling"); poll(cfg.poll_seconds); }
    }).catch(() => { if (!closed) { setState("polling"); poll(60); } });
    return () => {
      closed = true;
      es?.close();
      window.clearTimeout(timer);
      window.clearTimeout(debounce);
    };
  }, [enabled]);
  return state;
}
