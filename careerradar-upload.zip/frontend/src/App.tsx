import { useCallback, useEffect, useState } from "react";
import { api } from "./api";
import type { Me, Notice } from "./types";
import { useEvents } from "./useEvents";
import { ErrorBox, Spinner } from "./components/ui";
import JobsPage from "./pages/Jobs";
import ProfilePage from "./pages/Profile";
import ImportPage from "./pages/Import";
import SourcesPage from "./pages/Sources";
import ApplicationsPage from "./pages/Applications";
import SettingsPage from "./pages/Settings";

const ROUTES = [
  ["jobs", "Jobs"], ["profile", "Profile & CV"], ["import", "Import list"], ["sources", "Sources"],
  ["applications", "Applications"], ["settings", "Settings"],
] as const;
type Route = (typeof ROUTES)[number][0];

function useHashRoute(): [Route, (r: Route) => void] {
  const read = () => ((location.hash.slice(2) || "jobs") as Route);
  const [route, setRoute] = useState<Route>(read);
  useEffect(() => {
    const on = () => setRoute(read());
    addEventListener("hashchange", on);
    return () => removeEventListener("hashchange", on);
  }, []);
  return [route, (r) => { location.hash = `/${r}`; }];
}

export default function App() {
  const [me, setMe] = useState<Me | null | undefined>(undefined);
  const [route, go] = useHashRoute();
  const [tick, setTick] = useState(0);
  const [toasts, setToasts] = useState<Notice[]>([]);
  const [unread, setUnread] = useState<Notice[]>([]);
  const [showNotices, setShowNotices] = useState(false);

  useEffect(() => {
    api.get<Me>("/api/auth/me").then(setMe).catch(() => setMe(null));
  }, []);
  const refreshNotices = useCallback(() => {
    api.get<Notice[]>("/api/notifications?unread=true").then(setUnread).catch(() => {});
  }, []);
  const live = useEvents(!!me, () => { setTick((t) => t + 1); refreshNotices(); }, (n) => {
    setToasts((t) => [...t.slice(-3), n]);
    setUnread((u) => [n, ...u]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== n.id)), 8000);
  });

  if (me === undefined) return <div className="p-6"><Spinner /></div>;
  if (me === null) return <AuthScreen onDone={setMe} />;

  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/90 backdrop-blur dark:border-slate-800 dark:bg-slate-950/90">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-2 px-4 py-2">
          <span className="mr-2 font-semibold">CareerRadar</span>
          <nav className="flex flex-wrap gap-1" aria-label="Main">
            {ROUTES.map(([key, label]) => (
              <a key={key} href={`#/${key}`} aria-current={route === key ? "page" : undefined}
                 className={`rounded px-2 py-1 text-sm ${route === key ? "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/50 dark:text-indigo-200" : "hover:bg-slate-100 dark:hover:bg-slate-800"}`}>
                {label}
              </a>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2 text-xs">
            <span title={live === "polling"
                    ? "Checks for updates every minute while this page is open; sources are also refreshed at least once a day"
                    : "Dashboard push connection (upstream sources refresh on their own schedules)"}
                  className={live === "live" || live === "polling" ? "text-emerald-600" : "text-amber-600"}>
              ● {live === "live" ? "Live updates" : live === "polling" ? "Auto-refresh · every minute"
                : live === "reconnecting" ? "Reconnecting…" : "Connecting…"}
            </span>
            <button className="btn-ghost relative" onClick={() => { setShowNotices((s) => !s); }}
                    aria-expanded={showNotices} aria-label={`Notifications, ${unread.length} unread`}>
              🔔 {unread.length > 0 && <span className="badge bg-rose-600 text-white">{unread.length}</span>}
            </button>
          </div>
        </div>
        {showNotices && (
          <div className="mx-auto max-w-6xl px-4 pb-3">
            <div className="card max-h-72 overflow-auto text-sm">
              {unread.length === 0 ? <p className="text-slate-500">No unread notifications.</p> : (
                <ul className="space-y-1">{unread.map((n) => <li key={n.id}>• {n.message}</li>)}</ul>
              )}
              {unread.length > 0 && <button className="btn-ghost mt-2" onClick={async () => {
                await api.post("/api/notifications/read"); setUnread([]);
              }}>Mark all read</button>}
            </div>
          </div>
        )}
      </header>
      <main className="mx-auto max-w-6xl px-4 py-4">
        {route === "jobs" && <JobsPage tick={tick} />}
        {route === "profile" && <ProfilePage />}
        {route === "import" && <ImportPage onDone={() => go("jobs")} />}
        {route === "sources" && <SourcesPage tick={tick} />}
        {route === "applications" && <ApplicationsPage tick={tick} />}
        {route === "settings" && <SettingsPage me={me} onMe={setMe} />}
      </main>
      <div className="fixed bottom-4 right-4 z-30 space-y-2" aria-live="polite">
        {toasts.map((t) => <div key={t.id} className="card max-w-sm text-sm shadow-lg">{t.message}</div>)}
      </div>
    </div>
  );
}

function AuthScreen({ onDone }: { onDone: (m: Me) => void }) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  return (
    <div className="mx-auto mt-16 max-w-sm px-4">
      <h1 className="mb-1 text-2xl font-semibold">CareerRadar</h1>
      <p className="mb-6 text-sm text-slate-500">Find, verify and track national and international jobs against your CV.</p>
      <form className="card space-y-3" onSubmit={async (e) => {
        e.preventDefault(); setBusy(true); setErr(null);
        try { onDone(await api.post<Me>(`/api/auth/${mode}`, { email, password })); }
        catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
      }}>
        <label className="block"><span className="label">Email</span>
          <input className="input" type="email" autoComplete="email" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label className="block"><span className="label">Password (min 10 characters)</span>
          <input className="input" type="password" minLength={10} required autoComplete={mode === "login" ? "current-password" : "new-password"}
                 value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        <ErrorBox error={err} />
        <button className="btn w-full justify-center" disabled={busy}>{mode === "login" ? "Sign in" : "Create account"}</button>
        <button type="button" className="w-full text-center text-sm text-indigo-600 underline"
                onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "New here? Create an account" : "Have an account? Sign in"}
        </button>
      </form>
    </div>
  );
}
