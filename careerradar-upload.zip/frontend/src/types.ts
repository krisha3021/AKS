export interface Me { id: string; email: string; ai_consent: boolean; retention_days: number }

export interface JobCard {
  id: string; title: string; employer: string | null; location: string | null; country: string | null;
  city: string | null; scope: string | null; work_arrangement: string | null; status: string;
  is_synthetic: boolean; deadline_at: string | null; deadline_kind: string; deadline_text: string | null;
  posted_date: string | null; first_seen_at: string; last_verified_at: string | null; last_checked_at: string | null;
  application_url: string | null; canonical_url: string | null; sources: string[]; score: number | null;
  deal_breaker: boolean; summary: string | null; visa_sponsorship: string; salary: string | null;
  stale_warning: string | null;
}

export interface Evidence { field_id: string; kind: string; quote: string; confirmed: boolean }
export interface Req {
  key: string; label: string; mandatory: boolean | null; status: "supported" | "not_supported" | "unknown";
  vacancy_quote: string; cv_evidence: Evidence[]; note: string;
}
export interface Explanation {
  summary: string; why: string[]; requirements: Req[]; gaps: Req[]; unknowns: Req[]; deal_breakers: string[];
  hard_constraints: { label: string; status: string; quote?: string; note: string }[];
  visa_sponsorship: string; required_documents: string[]; disclaimer: string;
}
export interface JobDetail {
  job: JobCard; fields: Record<string, unknown>;
  match: { score: number; components: Record<string, number>; explanation: Explanation; computed_at: string } | null;
  provenance: { source_key: string; source_url: string | null; import_row: number | null; seen_at: string;
                original_values: Record<string, unknown> }[];
  changes: { field: string; old: string | null; new: string | null; material: boolean; at: string }[];
}

export interface ProfileField {
  id: string; kind: string; value: any; confidence: number; origin: "rules" | "llm" | "user";
  evidence: { document_id: string; page: number; start: number; end: number; quote: string }[];
  flags: string[]; confirmed: boolean; rejected?: boolean; edited_by_user?: boolean;
}
export interface Preferences {
  home_country: string; academic_mode: boolean; target_titles: string[]; title_synonyms: string[];
  countries: string[]; cities: string[]; work_arrangements: string[]; salary_min: number | null;
  salary_currency: string | null; employment_types: string[]; appointment_types: string[]; disciplines: string[];
  research_areas: string[]; needs_visa_sponsorship: boolean | null; open_to_relocation: boolean | null;
  excluded_employers: string[]; excluded_locations: string[]; excluded_keywords: string[];
  alert_frequency: string; languages: string[];
}
export interface Profile {
  fields: ProfileField[]; preferences: Preferences; version: number; extraction_notes: string[];
  experience: { total_months: number; total_years: number; academic_months: number; overlap_months_removed: number;
                ambiguous_field_ids: string[] };
  documents: { id: string; kind: string; filename: string; size_bytes: number; created_at: string }[];
}

export interface Capability {
  key: string; name: string; access: string; automated: boolean; default_enabled: boolean;
  min_interval_minutes: number; requires: string[]; notes: string; evidence_url: string;
}
export interface SourceRow {
  id: string; connector_key: string; connector_name: string; name: string; config: Record<string, string>;
  enabled: boolean; interval_minutes: number; last_checked_at: string | null; last_success_at: string | null;
  last_error: string | null; consecutive_failures: number; health: string; stale: boolean;
}
export interface AppRow {
  id: string; job_id: string; stage: string; notes: string; applied_at: string | null; reminder_at: string | null;
  required_documents: { name: string; done: boolean }[]; contacts: { name: string; role?: string; email?: string }[];
  history: { stage: string; at: string }[];
  job: { title: string; employer: string | null; deadline_at: string | null; status: string;
         application_url: string | null; is_synthetic: boolean };
}
export interface Draft {
  id: string; job_id: string; kind: string; content: string; missing_info: string[]; approved: boolean;
  approved_sha256: string | null; notice: string;
}
export interface Notice { id: string; kind: string; message: string; job_id: string | null; created_at?: string; read?: boolean }

export const STATUS_LABEL: Record<string, string> = {
  open_verified: "Open · recently verified",
  imported_unverified: "Imported · not verified",
  deadline_passed: "Deadline passed",
  closed_explicit: "Closed",
  removed: "Removed by source",
  verification_unavailable: "Verification unavailable",
  stale: "Stale · needs recheck",
};
export const STAGES = ["interested", "shortlisted", "preparing", "applied", "interview", "offer", "rejected", "withdrawn"];
