import { useEffect, useState } from "react";
import { api } from "../api";
import type { AppRow, Draft } from "../types";
import { STAGES } from "../types";
import { DemoBadge, Empty, ErrorBox, fmtDeadline, Spinner, StatusBadge } from "../components/ui";

const DRAFT_KINDS: [string, string][] = [
  ["application_email", "Application email"], ["cover_letter", "Cover letter"],
  ["research_statement_outline", "Research statement outline"], ["teaching_statement_outline", "Teaching statement outline"],
  ["selection_criteria", "Selection-criteria responses"],
];

export default function ApplicationsPage({ tick }: { tick: number }) {
  const [apps, setApps] = useState<AppRow[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [open, setOpen] = useState<AppRow | null>(null);
  const load = () => api.get<AppRow[]>("/api/applications").then(setApps).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, [tick]);
  const move = async (a: AppRow, stage: string) => { await api.patch(`/api/applications/${a.id}`, { stage }); load(); };

  if (!apps) return err ? <ErrorBox error={err} /> : <Spinner />;
  if (apps.length === 0) return <Empty title="No saved jobs yet">Use “Save” on a job card to start tracking it.</Empty>;
  return (
    <div>
      <ErrorBox error={err} />
      <div className="flex gap-3 overflow-x-auto pb-2" aria-label="Application board">
        {STAGES.map((stage) => (
          <section key={stage} className="w-64 shrink-0" aria-label={stage}
                   onDragOver={(e) => e.preventDefault()}
                   onDrop={(e) => { const a = apps.find((x) => x.id === e.dataTransfer.getData("text/plain")); if (a) move(a, stage); }}>
            <h2 className="mb-2 text-sm font-semibold capitalize">{stage} ({apps.filter((a) => a.stage === stage).length})</h2>
            <ul className="space-y-2">
              {apps.filter((a) => a.stage === stage).map((a) => (
                <li key={a.id} draggable onDragStart={(e) => e.dataTransfer.setData("text/plain", a.id)} className="card p-3 text-sm">
                  <button className="text-left font-medium hover:underline" onClick={() => setOpen(a)}>{a.job.title}</button>
                  <p className="text-xs text-slate-500">{a.job.employer}</p>
                  <div className="mt-1 flex flex-wrap gap-1"><StatusBadge status={a.job.status} />{a.job.is_synthetic && <DemoBadge />}</div>
                  <p className="mt-1 text-xs">Deadline: {fmtDeadline(a.job.deadline_at)}</p>
                  <label className="mt-1 block text-xs"><span className="sr-only">Move to stage</span>
                    <select className="input" value={a.stage} onChange={(e) => move(a, e.target.value)}>
                      {STAGES.map((s) => <option key={s} value={s}>{s}</option>)}</select></label>
                </li>
              ))}
            </ul>
          </section>
        ))}
      </div>
      {open && <AppDetail a={open} onClose={() => { setOpen(null); load(); }} />}
    </div>
  );
}

function AppDetail({ a, onClose }: { a: AppRow; onClose: () => void }) {
  const [notes, setNotes] = useState(a.notes);
  const [docs, setDocs] = useState(a.required_documents);
  const [reminder, setReminder] = useState(a.reminder_at?.slice(0, 10) ?? "");
  const [contacts, setContacts] = useState(a.contacts);
  const [drafts, setDrafts] = useState<Draft[]>([]);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { api.get<Draft[]>(`/api/drafts?job_id=${a.job_id}`).then(setDrafts); }, [a.job_id]);
  const save = () => api.patch(`/api/applications/${a.id}`, { notes, required_documents: docs, contacts,
    reminder_at: reminder ? `${reminder}T09:00:00` : null }).then(onClose).catch((e) => setErr(e.message));

  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/30" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label="Application details" onClick={(e) => e.stopPropagation()}
             className="h-full w-full max-w-2xl space-y-4 overflow-auto bg-white p-5 dark:bg-slate-900">
        <div className="flex justify-between"><h2 className="text-lg font-semibold">{a.job.title}</h2><button className="btn-ghost" onClick={onClose}>Close</button></div>
        <ErrorBox error={err} />
        {a.job.application_url && <a className="btn-ghost" href={a.job.application_url} target="_blank" rel="noopener noreferrer nofollow">Open original listing ↗</a>}
        <label className="block"><span className="label">Notes</span><textarea className="input h-24" value={notes} onChange={(e) => setNotes(e.target.value)} /></label>
        <label className="block"><span className="label">Reminder date</span><input className="input w-auto" type="date" value={reminder} onChange={(e) => setReminder(e.target.value)} /></label>
        <section>
          <h3 className="label">Required documents</h3>
          {docs.map((d, i) => (
            <label key={i} className="flex items-center gap-2 text-sm"><input type="checkbox" checked={d.done}
              onChange={(e) => setDocs(docs.map((x, j) => (j === i ? { ...x, done: e.target.checked } : x)))} />{d.name}</label>
          ))}
          <button className="btn-ghost mt-1" onClick={() => { const n = prompt("Document name"); if (n) setDocs([...docs, { name: n, done: false }]); }}>+ Add document</button>
        </section>
        <section>
          <h3 className="label">Contacts (entered by you)</h3>
          {contacts.map((c, i) => <p key={i} className="text-sm">{c.name}{c.role ? ` · ${c.role}` : ""}{c.email ? ` · ${c.email}` : ""}</p>)}
          <button className="btn-ghost mt-1" onClick={() => { const n = prompt("Contact name"); if (n) setContacts([...contacts, { name: n, role: prompt("Role (optional)") ?? "" }]); }}>+ Add contact</button>
        </section>
        <button className="btn" onClick={save}>Save</button>

        <section className="border-t border-slate-200 pt-3 dark:border-slate-800">
          <h3 className="font-semibold">Draft application materials</h3>
          <p className="text-xs text-slate-500">Drafts use only your profile and this vacancy. Gaps appear as [brackets] — never invented. CareerRadar never sends or submits anything; copy the text and send it yourself.</p>
          <div className="mt-2 flex flex-wrap gap-2">
            {DRAFT_KINDS.map(([k, l]) => <button key={k} className="btn-ghost" onClick={async () => {
              const d = await api.post<Draft>("/api/drafts", { job_id: a.job_id, kind: k }); setDrafts([d, ...drafts]);
            }}>{l}</button>)}
          </div>
          {drafts.map((d) => <DraftEditor key={d.id} d={d} onChange={(nd) => setDrafts(drafts.map((x) => (x.id === nd.id ? nd : x)))} />)}
        </section>
      </aside>
    </div>
  );
}

function DraftEditor({ d, onChange }: { d: Draft; onChange: (d: Draft) => void }) {
  const [text, setText] = useState(d.content);
  return (
    <div className="mt-3 rounded border border-slate-200 p-2 dark:border-slate-700">
      <p className="text-sm font-medium">{d.kind.replace(/_/g, " ")} {d.approved && <span className="badge bg-emerald-100 text-emerald-800">approved · frozen</span>}</p>
      {d.missing_info.length > 0 && <p className="text-xs text-amber-700">Missing from your profile: {d.missing_info.join(", ")}</p>}
      <textarea className="input mt-1 h-48 font-mono text-xs" readOnly={d.approved} value={text} onChange={(e) => setText(e.target.value)} />
      <div className="mt-1 flex gap-2">
        {!d.approved && <button className="btn-ghost" onClick={async () => onChange(await api.put<Draft>(`/api/drafts/${d.id}`, { content: text }))}>Save edits</button>}
        {!d.approved && <button className="btn-ghost" onClick={async () => {
          if (!confirm("Approve and freeze this text? You will still need to send it yourself.")) return;
          await api.put(`/api/drafts/${d.id}`, { content: text }); onChange(await api.post<Draft>(`/api/drafts/${d.id}/approve`));
        }}>Approve (freeze)</button>}
        <button className="btn-ghost" onClick={() => navigator.clipboard.writeText(text)}>Copy</button>
      </div>
    </div>
  );
}
