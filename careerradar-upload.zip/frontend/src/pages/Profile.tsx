import { useEffect, useState } from "react";
import { api } from "../api";
import type { Preferences, Profile, ProfileField } from "../types";
import { Empty, ErrorBox, ListInput, Spinner } from "../components/ui";

const KIND_LABEL: Record<string, string> = {
  degree: "Qualifications", employment: "Employment history", academic_rank: "Academic ranks", skill: "Skills",
  research_interest: "Research interests", teaching_area: "Teaching areas", publication: "Publications",
  patent: "Patents", grant: "Grants & funding", project: "Projects", supervision: "Supervision",
};

function show(f: ProfileField): string {
  const v = f.value;
  if (typeof v !== "object" || v === null) return String(v);
  if (f.kind === "employment") return `${v.text} — ${v.start ?? "?"} to ${v.current ? "present" : v.end ?? "?"}`;
  if (f.kind === "degree") return v.text ?? `${v.level}`;
  return JSON.stringify(v);
}

export default function ProfilePage() {
  const [p, setP] = useState<Profile | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const load = () => api.get<Profile>("/api/profile").then(setP).catch((e) => setErr(e.message));
  useEffect(() => { load(); }, []);

  const patch = async (id: string, body: object) => {
    try { setP(await api.patch<Profile>(`/api/profile/fields/${id}`, body)); } catch (e) { setErr((e as Error).message); }
  };
  if (!p) return err ? <ErrorBox error={err} /> : <Spinner />;
  const groups = Object.keys(KIND_LABEL).map((k) => [k, p.fields.filter((f) => f.kind === k)] as const);

  return (
    <div className="space-y-4">
      <section className="card">
        <h2 className="font-semibold">Upload your CV</h2>
        <p className="mb-2 text-sm text-slate-500">PDF or DOCX, max 10 MB. Files are encrypted at rest. Every extracted fact links to the exact CV text it came from; nothing is invented. Review and confirm below.</p>
        <input type="file" accept=".pdf,.docx" aria-label="CV file" disabled={busy} onChange={async (e) => {
          const file = e.target.files?.[0]; if (!file) return;
          setBusy(true); setErr(null);
          try { setP(await api.upload<Profile>("/api/profile/cv", file)); } catch (x) { setErr((x as Error).message); }
          finally { setBusy(false); e.target.value = ""; }
        }} />
        {busy && <Spinner label="Reading your CV…" />}
        {p.extraction_notes.map((n) => <p key={n} className="mt-2 text-sm text-slate-600 dark:text-slate-400">ℹ {n}</p>)}
        <ErrorBox error={err} />
      </section>

      <section className="card text-sm">
        <h2 className="font-semibold">Experience summary</h2>
        <p>{p.experience.total_years} years total (overlapping periods merged — {p.experience.overlap_months_removed} overlapping months not double-counted); {Math.round(p.experience.academic_months / 12 * 10) / 10} years in academic ranks.</p>
        {p.experience.ambiguous_field_ids.length > 0 && <p className="text-amber-700 dark:text-amber-400">⚠ {p.experience.ambiguous_field_ids.length} employment entr{p.experience.ambiguous_field_ids.length === 1 ? "y has" : "ies have"} unclear dates — fix them below for accurate eligibility checks.</p>}
      </section>

      {p.fields.length === 0 && <Empty title="No profile data yet">Upload a CV, or add entries manually below.</Empty>}
      {groups.filter(([, fs]) => fs.length).map(([kind, fs]) => (
        <section key={kind} className="card">
          <h2 className="mb-2 font-semibold">{KIND_LABEL[kind]} <span className="text-sm font-normal text-slate-500">({fs.filter((f) => !f.rejected).length})</span></h2>
          <ul className="space-y-2">
            {fs.map((f) => (
              <li key={f.id} className={`rounded border p-2 text-sm dark:border-slate-700 ${f.rejected ? "opacity-50 line-through" : ""}`}>
                {editing === f.id ? (
                  <EditField f={f} onSave={async (value) => { await patch(f.id, { value, confirmed: true }); setEditing(null); }} onCancel={() => setEditing(null)} />
                ) : (
                  <>
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <span>{show(f)}</span>
                      <span className="text-xs text-slate-500">{f.origin === "user" ? "entered by you" : `${f.origin === "llm" ? "AI" : "rules"} · confidence ${Math.round(f.confidence * 100)}%`}{f.confirmed ? " · ✓ confirmed" : ""}</span>
                    </div>
                    {f.evidence[0] && <p className="mt-1 text-xs text-slate-500">Evidence (page {f.evidence[0].page}): “{f.evidence[0].quote}”</p>}
                    {f.flags.map((fl) => <p key={fl} className="text-xs text-amber-700 dark:text-amber-400">⚠ {fl}</p>)}
                    <div className="mt-1 flex gap-2">
                      {!f.confirmed && !f.rejected && <button className="btn-ghost" onClick={() => patch(f.id, { confirmed: true })}>Confirm</button>}
                      <button className="btn-ghost" onClick={() => setEditing(f.id)}>Edit</button>
                      <button className="btn-ghost" onClick={() => patch(f.id, { rejected: !f.rejected })}>{f.rejected ? "Restore" : "Not correct"}</button>
                    </div>
                  </>
                )}
              </li>
            ))}
          </ul>
        </section>
      ))}

      <AddField onAdd={async (kind, value) => setP(await api.post<Profile>("/api/profile/fields", { kind, value }))} />
      <PreferencesForm prefs={p.preferences} onSave={async (pr) => setP(await api.put<Profile>("/api/profile/preferences", pr))} />
    </div>
  );
}

function EditField({ f, onSave, onCancel }: { f: ProfileField; onSave: (v: unknown) => void; onCancel: () => void }) {
  const [v, setV] = useState<any>(f.value);
  if (f.kind === "employment") {
    return (
      <div className="grid gap-2 md:grid-cols-4">
        <input className="input md:col-span-2" aria-label="Role" value={v.text ?? ""} onChange={(e) => setV({ ...v, text: e.target.value })} />
        <input className="input" type="date" aria-label="Start date" value={v.start ?? ""} onChange={(e) => setV({ ...v, start: e.target.value })} />
        <input className="input" type="date" aria-label="End date" value={v.end ?? ""} onChange={(e) => setV({ ...v, end: e.target.value })} />
        <div className="flex gap-2"><button className="btn" onClick={() => onSave(v)}>Save</button><button className="btn-ghost" onClick={onCancel}>Cancel</button></div>
      </div>
    );
  }
  if (f.kind === "degree") {
    return (
      <div className="grid gap-2 md:grid-cols-4">
        <select className="input" aria-label="Level" value={v.level} onChange={(e) => setV({ ...v, level: e.target.value })}>
          <option value="bachelors">Bachelor's</option><option value="masters">Master's</option><option value="doctorate">Doctorate</option></select>
        <input className="input md:col-span-2" aria-label="Degree" value={v.text ?? ""} onChange={(e) => setV({ ...v, text: e.target.value })} />
        <input className="input" aria-label="Year" value={v.year ?? ""} onChange={(e) => setV({ ...v, year: e.target.value })} />
        <div className="flex gap-2"><button className="btn" onClick={() => onSave(v)}>Save</button><button className="btn-ghost" onClick={onCancel}>Cancel</button></div>
      </div>
    );
  }
  return (
    <div className="flex gap-2">
      <input className="input" aria-label="Value" value={typeof v === "string" ? v : JSON.stringify(v)} onChange={(e) => setV(e.target.value)} />
      <button className="btn" onClick={() => onSave(v)}>Save</button><button className="btn-ghost" onClick={onCancel}>Cancel</button>
    </div>
  );
}

function AddField({ onAdd }: { onAdd: (kind: string, value: unknown) => Promise<void> }) {
  const [kind, setKind] = useState("skill");
  const [text, setText] = useState("");
  return (
    <section className="card">
      <h2 className="mb-2 font-semibold">Add something the CV missed</h2>
      <form className="flex flex-wrap gap-2" onSubmit={async (e) => {
        e.preventDefault(); if (!text.trim()) return;
        const value = kind === "degree" ? { level: "masters", text } : kind === "employment" ? { text, start: null, end: null } : text;
        await onAdd(kind, value); setText("");
      }}>
        <select className="input w-auto" aria-label="Kind" value={kind} onChange={(e) => setKind(e.target.value)}>
          {Object.entries(KIND_LABEL).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select>
        <input className="input max-w-md" aria-label="Value" value={text} onChange={(e) => setText(e.target.value)} placeholder="Only add things that are true and verifiable" />
        <button className="btn">Add</button>
      </form>
    </section>
  );
}

function PreferencesForm({ prefs, onSave }: { prefs: Preferences; onSave: (p: Preferences) => Promise<void> }) {
  const [p, setP] = useState(prefs);
  const [saved, setSaved] = useState(false);
  const set = <K extends keyof Preferences>(k: K, v: Preferences[K]) => { setP((x) => ({ ...x, [k]: v })); setSaved(false); };
  const tri = (v: boolean | null) => (v === null ? "" : v ? "yes" : "no");
  const fromTri = (s: string) => (s === "" ? null : s === "yes");
  return (
    <section className="card">
      <h2 className="mb-2 font-semibold">Search preferences</h2>
      <div className="grid gap-3 md:grid-cols-3">
        <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={p.academic_mode} onChange={(e) => set("academic_mode", e.target.checked)} /> Academic mode</label>
        <ListInput label="Target job titles" value={p.target_titles} onChange={(v) => set("target_titles", v)} placeholder="Assistant Professor, Lecturer" />
        <ListInput label="Title synonyms" value={p.title_synonyms} onChange={(v) => set("title_synonyms", v)} />
        <ListInput label="Countries" value={p.countries} onChange={(v) => set("countries", v)} placeholder="India, United Arab Emirates" />
        <ListInput label="Cities" value={p.cities} onChange={(v) => set("cities", v)} />
        <ListInput label="Disciplines" value={p.disciplines} onChange={(v) => set("disciplines", v)} />
        <ListInput label="Research areas" value={p.research_areas} onChange={(v) => set("research_areas", v)} />
        <ListInput label="Employment types" value={p.employment_types} onChange={(v) => set("employment_types", v)} placeholder="Full-time, Tenure-track" />
        <ListInput label="Work arrangements (remote, hybrid, onsite)" value={p.work_arrangements} onChange={(v) => set("work_arrangements", v.filter((x) => ["remote", "hybrid", "onsite"].includes(x)))} />
        <label><span className="label">Minimum salary</span><input className="input" type="number" value={p.salary_min ?? ""} onChange={(e) => set("salary_min", e.target.value ? Number(e.target.value) : null)} /></label>
        <label><span className="label">Salary currency (ISO, e.g. INR)</span><input className="input" maxLength={3} value={p.salary_currency ?? ""} onChange={(e) => set("salary_currency", e.target.value.toUpperCase() || null)} /></label>
        <label><span className="label">I need visa sponsorship</span><select className="input" value={tri(p.needs_visa_sponsorship)} onChange={(e) => set("needs_visa_sponsorship", fromTri(e.target.value))}><option value="">Not specified</option><option value="yes">Yes</option><option value="no">No</option></select></label>
        <label><span className="label">Open to relocation</span><select className="input" value={tri(p.open_to_relocation)} onChange={(e) => set("open_to_relocation", fromTri(e.target.value))}><option value="">Not specified</option><option value="yes">Yes</option><option value="no">No</option></select></label>
        <ListInput label="Excluded employers" value={p.excluded_employers} onChange={(v) => set("excluded_employers", v)} />
        <ListInput label="Excluded locations" value={p.excluded_locations} onChange={(v) => set("excluded_locations", v)} />
        <ListInput label="Excluded keywords" value={p.excluded_keywords} onChange={(v) => set("excluded_keywords", v)} />
        <label><span className="label">Alerts</span><select className="input" value={p.alert_frequency} onChange={(e) => set("alert_frequency", e.target.value)}>
          <option value="instant">Instant (in-app)</option><option value="daily">Daily digest</option><option value="weekly">Weekly digest</option><option value="off">Off</option></select></label>
        <ListInput label="Languages" value={p.languages} onChange={(v) => set("languages", v)} />
      </div>
      <button className="btn mt-3" onClick={async () => { await onSave(p); setSaved(true); }}>Save preferences</button>
      {saved && <span className="ml-2 text-sm text-emerald-600">Saved — scores are being recalculated.</span>}
    </section>
  );
}
