import { useEffect, useState } from "react";
import { api } from "../api";
import type { Capability, SourceRow } from "../types";
import { ago, Empty, ErrorBox, Spinner } from "../components/ui";

const CONFIG_FIELDS: Record<string, { key: string; label: string; placeholder?: string }[]> = {
  greenhouse: [{ key: "board_token", label: "Board token", placeholder: "from boards.greenhouse.io/<token>" },
               { key: "employer", label: "Employer name" }],
  lever: [{ key: "site", label: "Lever site", placeholder: "from jobs.lever.co/<site>" }, { key: "employer", label: "Employer name" },
          { key: "region", label: "Region (blank or 'eu')" }],
  rss: [{ key: "url", label: "Feed URL", placeholder: "https://jobs.example.ac.uk/RSS" }, { key: "employer", label: "Employer (optional)" },
        { key: "default_location", label: "Default location (optional)" }],
  higheredjobs: [{ key: "cat_id", label: "Category ID", placeholder: "number from higheredjobs.com/rss" }],
  adzuna: [{ key: "country", label: "Country code", placeholder: "in" }, { key: "what", label: "Keywords" }, { key: "where", label: "Location (optional)" }],
};

export default function SourcesPage({ tick }: { tick: number }) {
  const [caps, setCaps] = useState<Capability[] | null>(null);
  const [rows, setRows] = useState<SourceRow[] | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [adding, setAdding] = useState<string>("greenhouse");
  const [cfg, setCfg] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const load = () => api.get<SourceRow[]>("/api/sources").then(setRows).catch((e) => setErr(e.message));
  useEffect(() => { api.get<Capability[]>("/api/sources/capabilities").then(setCaps); }, []);
  useEffect(() => { load(); }, [tick]);
  const automated = caps?.filter((c) => c.automated) ?? [];
  const manual = caps?.filter((c) => !c.automated) ?? [];

  return (
    <div className="space-y-4">
      <section className="card">
        <h2 className="font-semibold">Your sources</h2>
        <p className="text-sm text-slate-500">Sources refresh on their own schedules — CareerRadar never claims a board is real-time. Dashboard updates are pushed as soon as new data is processed.</p>
        <ErrorBox error={err} />
        {!rows && <Spinner />}
        {rows && rows.length === 0 && <Empty title="No sources yet">Add an employer board or feed below, or import a spreadsheet.</Empty>}
        <ul className="mt-2 space-y-2">
          {rows?.map((s) => (
            <li key={s.id} className="rounded border border-slate-200 p-2 text-sm dark:border-slate-700">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <span><strong>{s.name}</strong> · {s.connector_name}</span>
                <span className={`badge ${s.health === "ok" ? "bg-emerald-100 text-emerald-800" : s.health === "failing" ? "bg-rose-100 text-rose-800" : "bg-slate-100"}`}>
                  {s.health === "ok" ? "Healthy" : s.health === "failing" ? "Failing" : "Not run yet"}</span>
              </div>
              <p className="text-xs text-slate-500">Refresh every {Math.round(s.interval_minutes / 60 * 10) / 10} h · last checked {ago(s.last_checked_at)} · last success {ago(s.last_success_at)}{s.enabled ? "" : " · paused"}</p>
              {s.stale && <p className="text-xs text-amber-700">⚠ Data from this source is stale — no successful refresh for a long time.</p>}
              {s.last_error && <p className="text-xs text-rose-700">Last error: {s.last_error}{s.last_error.startsWith("temporary") ? " (jobs were not closed; will retry)" : ""}</p>}
              <div className="mt-1 flex gap-2">
                <button className="btn-ghost" onClick={() => api.post(`/api/sources/${s.id}/refresh`).then(load).catch((e) => setErr(e.message))}>Refresh now</button>
                <button className="btn-ghost" onClick={() => api.patch(`/api/sources/${s.id}`, { enabled: !s.enabled }).then(load)}>{s.enabled ? "Pause" : "Resume"}</button>
                <button className="btn-ghost" onClick={() => confirm("Remove this source? Jobs already found are kept.") && api.del(`/api/sources/${s.id}`).then(load)}>Remove</button>
              </div>
            </li>
          ))}
        </ul>
      </section>

      <section className="card">
        <h2 className="font-semibold">Add a source</h2>
        <form className="mt-2 grid gap-2 md:grid-cols-3" onSubmit={async (e) => {
          e.preventDefault(); setErr(null);
          try { await api.post("/api/sources", { connector_key: adding, name: name || adding, config: cfg }); setCfg({}); setName(""); load(); }
          catch (x) { setErr((x as Error).message); }
        }}>
          <label><span className="label">Type</span>
            <select className="input" value={adding} onChange={(e) => { setAdding(e.target.value); setCfg({}); }}>
              {automated.map((c) => <option key={c.key} value={c.key}>{c.name}{c.default_enabled ? "" : " (opt-in)"}</option>)}
            </select></label>
          <label><span className="label">Name</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label>
          {(CONFIG_FIELDS[adding] ?? []).map((f) => (
            <label key={f.key}><span className="label">{f.label}</span>
              <input className="input" placeholder={f.placeholder} value={cfg[f.key] ?? ""} onChange={(e) => setCfg({ ...cfg, [f.key]: e.target.value })} /></label>
          ))}
          <p className="text-xs text-slate-500 md:col-span-3">{caps?.find((c) => c.key === adding)?.notes}</p>
          <button className="btn w-fit">Add source</button>
        </form>
      </section>

      <section className="card">
        <h2 className="font-semibold">Source access matrix</h2>
        <p className="text-sm text-slate-500">What CareerRadar can and cannot do for each source, based on official documentation and terms checked on 2026-10-13.</p>
        <div className="overflow-x-auto">
          <table className="mt-2 min-w-full text-sm">
            <thead><tr className="text-left"><th className="p-1">Source</th><th className="p-1">Access</th><th className="p-1">Automated?</th><th className="p-1">Notes</th></tr></thead>
            <tbody>{[...automated, ...manual].map((c) => (
              <tr key={c.key} className="border-t border-slate-200 align-top dark:border-slate-800">
                <td className="p-1">{c.evidence_url ? <a className="text-indigo-600 underline" href={c.evidence_url} target="_blank" rel="noopener noreferrer">{c.name}</a> : c.name}</td>
                <td className="p-1">{c.access.replace(/_/g, " ")}</td>
                <td className="p-1">{c.automated ? (c.default_enabled ? "Yes" : "Yes, opt-in") : <strong>No — manual import / link-out only</strong>}</td>
                <td className="p-1 text-xs">{c.notes}</td>
              </tr>))}</tbody>
          </table>
        </div>
      </section>
    </div>
  );
}
