import { useEffect, useState } from "react";
import { api, qs } from "../api";
import type { JobCard, JobDetail } from "../types";
import { STATUS_LABEL } from "../types";
import { ago, DemoBadge, Empty, ErrorBox, fmtDate, fmtDeadline, ReqStatus, ScorePill, Spinner, StatusBadge } from "../components/ui";

interface Filters {
  q: string; scope: "" | "national" | "international"; academic: boolean; country: string; city: string;
  arrangement: string; employer: string; status: string[]; deadline_before: string; seen_after: string;
  min_score: string; visa_stated: boolean; salary_min: string; employment_type: string; rank: string;
  discipline: string; include_closed: boolean; sort: string;
}
const EMPTY: Filters = { q: "", scope: "", academic: false, country: "", city: "", arrangement: "", employer: "",
  status: [], deadline_before: "", seen_after: "", min_score: "", visa_stated: false, salary_min: "",
  employment_type: "", rank: "", discipline: "", include_closed: false, sort: "score" };

export default function JobsPage({ tick }: { tick: number }) {
  const [f, setF] = useState<Filters>(EMPTY);
  const [data, setData] = useState<{ total: number; items: JobCard[] } | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);
  const [showFilters, setShowFilters] = useState(false);
  const [saved, setSaved] = useState<Set<string>>(new Set());

  useEffect(() => {
    const t = setTimeout(() => {
      api.get<{ total: number; items: JobCard[] }>(`/api/jobs${qs({ ...f, limit: 100 })}`)
        .then((d) => { setData(d); setErr(null); }).catch((e) => setErr(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [f, tick]);
  const set = <K extends keyof Filters>(k: K, v: Filters[K]) => setF((x) => ({ ...x, [k]: v }));

  return (
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <div role="tablist" className="flex rounded-md border border-slate-300 dark:border-slate-700">
          {(["", "national", "international"] as const).map((s) => (
            <button key={s || "all"} role="tab" aria-selected={f.scope === s} onClick={() => set("scope", s)}
                    className={`px-3 py-1.5 text-sm ${f.scope === s ? "bg-indigo-600 text-white" : ""}`}>
              {s === "" ? "All" : s === "national" ? "National" : "International"}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-1 text-sm">
          <input type="checkbox" checked={f.academic} onChange={(e) => set("academic", e.target.checked)} /> Academic mode
        </label>
        <input className="input max-w-xs" placeholder="Search title, employer, description…" aria-label="Search"
               value={f.q} onChange={(e) => set("q", e.target.value)} />
        <select className="input w-auto" aria-label="Sort" value={f.sort} onChange={(e) => set("sort", e.target.value)}>
          <option value="score">Best match</option><option value="relevance">Search relevance</option>
          <option value="deadline">Deadline soonest</option><option value="newest">Newest first-seen</option>
        </select>
        <button className="btn-ghost" onClick={() => setShowFilters((s) => !s)} aria-expanded={showFilters}>Filters</button>
        <a className="btn-ghost" href="/api/jobs/export/csv">Export CSV</a>
      </div>

      {showFilters && (
        <div className="card mb-3 grid grid-cols-2 gap-3 md:grid-cols-4">
          {f.academic && <Field label="Rank (e.g. Assistant Professor)" v={f.rank} on={(v) => set("rank", v)} />}
          <Field label="Discipline" v={f.discipline} on={(v) => set("discipline", v)} />
          <Field label="Country" v={f.country} on={(v) => set("country", v)} />
          <Field label="City" v={f.city} on={(v) => set("city", v)} />
          <Field label="Employer" v={f.employer} on={(v) => set("employer", v)} />
          <Field label="Employment type" v={f.employment_type} on={(v) => set("employment_type", v)} />
          <label><span className="label">Work arrangement</span>
            <select className="input" value={f.arrangement} onChange={(e) => set("arrangement", e.target.value)}>
              <option value="">Any</option><option value="remote">Remote</option><option value="hybrid">Hybrid</option>
              <option value="onsite">On-site</option></select></label>
          <Field label="Min relevance score" type="number" v={f.min_score} on={(v) => set("min_score", v)} />
          <Field label="Min salary (job's currency)" type="number" v={f.salary_min} on={(v) => set("salary_min", v)} />
          <Field label="Deadline before" type="date" v={f.deadline_before} on={(v) => set("deadline_before", v)} />
          <Field label="First seen after" type="date" v={f.seen_after} on={(v) => set("seen_after", v)} />
          <label><span className="label">Verification status</span>
            <select className="input" multiple size={3} value={f.status}
                    onChange={(e) => set("status", Array.from(e.target.selectedOptions).map((o) => o.value))}>
              {Object.entries(STATUS_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select></label>
          <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={f.visa_stated}
            onChange={(e) => set("visa_stated", e.target.checked)} /> Visa sponsorship explicitly stated</label>
          <label className="flex items-center gap-1 text-sm"><input type="checkbox" checked={f.include_closed}
            onChange={(e) => set("include_closed", e.target.checked)} /> Include closed / removed</label>
          <button className="btn-ghost" onClick={() => setF(EMPTY)}>Reset</button>
        </div>
      )}

      <ErrorBox error={err} />
      {!data && !err && <Spinner />}
      {data && data.total === 0 && (
        <Empty title="No jobs match.">
          Import a spreadsheet, add a trusted source, or loosen your filters.{" "}
          <a className="text-indigo-600 underline" href="#/import">Import a job list</a>
        </Empty>
      )}
      {data && data.total > 0 && <p className="mb-2 text-sm text-slate-500">{data.total} job(s). Scores show relevance to your profile — not your chance of selection.</p>}
      <ul className="grid gap-3 md:grid-cols-2">
        {data?.items.map((j) => (
          <li key={j.id} className="card flex flex-col gap-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <button className="text-left font-semibold hover:underline" onClick={() => setOpenId(j.id)}>{j.title}</button>
                <p className="text-sm text-slate-600 dark:text-slate-400">{j.employer ?? "Employer not stated"} · {j.location ?? "Location not stated"}</p>
              </div>
              <ScorePill score={j.score} dealBreaker={j.deal_breaker} />
            </div>
            <div className="flex flex-wrap gap-1">
              <StatusBadge status={j.status} />
              {j.is_synthetic && <DemoBadge />}
              {j.scope && <span className="badge bg-slate-100 dark:bg-slate-800">{j.scope}</span>}
            </div>
            {j.summary && <p className="text-sm">{j.summary}</p>}
            {j.stale_warning && <p className="text-xs text-amber-700 dark:text-amber-400">⚠ {j.stale_warning}</p>}
            <dl className="grid grid-cols-2 gap-x-3 text-xs text-slate-600 dark:text-slate-400">
              <dt>Deadline</dt><dd>{deadlineLabel(j)}</dd>
              <dt>Last verified</dt><dd>{ago(j.last_verified_at)}</dd>
              <dt>Source</dt><dd>{j.sources.join(", ")}</dd>
              <dt>Visa sponsorship</dt><dd>{j.visa_sponsorship === "stated_yes" ? "Stated: yes" : j.visa_sponsorship === "stated_no" ? "Stated: no" : "Not stated"}</dd>
            </dl>
            <div className="mt-auto flex gap-2">
              {j.application_url && <a className="btn-ghost" href={j.application_url} target="_blank" rel="noopener noreferrer nofollow">Open original listing ↗</a>}
              <button className="btn-ghost" onClick={() => setOpenId(j.id)}>Evidence</button>
              <button className="btn-ghost" disabled={saved.has(j.id)}
                      onClick={() => api.post("/api/applications", { job_id: j.id })
                        .then(() => setSaved((s) => new Set(s).add(j.id))).catch((e) => setErr(e.message))}>
                {saved.has(j.id) ? "Saved ✓" : "Save"}</button>
            </div>
          </li>
        ))}
      </ul>
      {openId && <JobDrawer id={openId} onClose={() => setOpenId(null)} />}
    </div>
  );
}

/** Shows the source's own wording; a converted local time is shown only when the source gave a timezone. */
export function deadlineLabel(j: Pick<JobCard, "deadline_kind" | "deadline_at" | "deadline_text"> & { deadline_tz?: string | null }): string {
  if (j.deadline_kind === "open_until_filled") return "Open until filled";
  if (!j.deadline_at && !j.deadline_text) return "Not stated";
  const kind = j.deadline_kind !== "closing" && j.deadline_kind !== "unknown" ? ` (${j.deadline_kind.replace(/_/g, " ")})` : "";
  if (j.deadline_text) return `${j.deadline_text}${kind && !j.deadline_text.toLowerCase().includes("review") ? kind : ""}`;
  return `${fmtDeadline(j.deadline_at)}${kind}`;
}

function Field({ label, v, on, type = "text" }: { label: string; v: string; on: (v: string) => void; type?: string }) {
  return <label><span className="label">{label}</span><input className="input" type={type} value={v} onChange={(e) => on(e.target.value)} /></label>;
}

export function JobDrawer({ id, onClose }: { id: string; onClose: () => void }) {
  const [d, setD] = useState<JobDetail | null>(null);
  const [err, setErr] = useState<string | null>(null);
  useEffect(() => { api.get<JobDetail>(`/api/jobs/${id}`).then(setD).catch((e) => setErr(e.message)); }, [id]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    addEventListener("keydown", k); return () => removeEventListener("keydown", k);
  }, [onClose]);
  const ex = d?.match?.explanation;
  return (
    <div className="fixed inset-0 z-40 flex justify-end bg-black/30" onClick={onClose}>
      <aside role="dialog" aria-modal="true" aria-label="Job evidence" onClick={(e) => e.stopPropagation()}
             className="h-full w-full max-w-2xl overflow-auto bg-white p-5 dark:bg-slate-900">
        <button className="btn-ghost float-right" onClick={onClose}>Close</button>
        <ErrorBox error={err} />
        {!d && !err && <Spinner />}
        {d && (
          <div className="space-y-4">
            <div>
              <h2 className="text-lg font-semibold">{d.job.title}</h2>
              <p className="text-sm text-slate-500">{d.job.employer} · {d.job.location}</p>
              <div className="mt-1 flex flex-wrap gap-1"><StatusBadge status={d.job.status} />{d.job.is_synthetic && <DemoBadge />}
                <ScorePill score={d.job.score} dealBreaker={d.job.deal_breaker} /></div>
              <p className="mt-1 text-xs text-slate-500">Last checked {ago(d.job.last_checked_at)} · last verified {ago(d.job.last_verified_at)} · first seen {fmtDate(d.job.first_seen_at)} · posted {d.job.posted_date ? fmtDate(d.job.posted_date) : "not stated by source"}</p>
            </div>
            {ex && (
              <>
                {ex.deal_breakers.length > 0 && (
                  <div className="rounded-md border border-rose-300 bg-rose-50 p-3 text-sm dark:border-rose-800 dark:bg-rose-950">
                    <p className="font-semibold">Possible deal-breakers</p>
                    <ul className="list-disc pl-5">{ex.deal_breakers.map((x) => <li key={x}>{x}</li>)}</ul>
                  </div>
                )}
                <section>
                  <h3 className="font-semibold">Why it matches</h3>
                  {ex.why.length ? <ul className="list-disc pl-5 text-sm">{ex.why.map((w) => <li key={w}>{w}</li>)}</ul>
                    : <p className="text-sm text-slate-500">No strong positive signals.</p>}
                  <p className="mt-1 text-xs text-slate-500">Components: {Object.entries(d.match!.components).map(([k, v]) => `${k} ${v}`).join(" · ")}. {ex.disclaimer}</p>
                </section>
                <section>
                  <h3 className="font-semibold">Requirements stated in the vacancy</h3>
                  {ex.requirements.length === 0 && <p className="text-sm text-slate-500">{ex.summary}. Read the original listing for full criteria.</p>}
                  <ul className="space-y-2">
                    {ex.requirements.map((r) => (
                      <li key={r.key} className="rounded border border-slate-200 p-2 text-sm dark:border-slate-700">
                        <div className="flex justify-between"><span className="font-medium">{r.label}{r.mandatory ? " (mandatory)" : r.mandatory === false ? " (preferred)" : ""}</span><ReqStatus status={r.status} /></div>
                        <p className="mt-1 text-xs"><span className="text-slate-500">Vacancy says:</span> “{r.vacancy_quote}”</p>
                        {r.cv_evidence.map((e) => <p key={e.field_id} className="text-xs"><span className="text-slate-500">Your CV:</span> “{e.quote}”{e.confirmed ? " ✓ confirmed" : ""}</p>)}
                        {r.note && <p className="text-xs text-amber-700 dark:text-amber-400">{r.note}</p>}
                      </li>
                    ))}
                  </ul>
                </section>
                <section className="text-sm">
                  <h3 className="font-semibold">Visa & documents</h3>
                  <p>Visa sponsorship: {ex.visa_sponsorship === "not_stated" ? "Unknown — not stated in the vacancy" : ex.visa_sponsorship === "stated_yes" ? "Stated as available" : "Stated as not available"}</p>
                  <p>Required documents mentioned: {ex.required_documents.length ? ex.required_documents.join(", ") : "none detected"}</p>
                </section>
              </>
            )}
            <section className="text-sm">
              <h3 className="font-semibold">Provenance ({d.provenance.length} source record{d.provenance.length === 1 ? "" : "s"})</h3>
              <ul className="space-y-1 text-xs">
                {d.provenance.map((p, i) => (
                  <li key={i}>{p.source_key}{p.import_row ? ` · row ${p.import_row}` : ""} · {fmtDate(p.seen_at, true)}
                    {p.source_url && <> · <a className="text-indigo-600 underline" href={p.source_url} target="_blank" rel="noopener noreferrer nofollow">link</a></>}</li>
                ))}
              </ul>
            </section>
            {d.changes.length > 0 && (
              <section className="text-sm">
                <h3 className="font-semibold">Change history</h3>
                <ul className="text-xs">{d.changes.map((c, i) => <li key={i}>{fmtDate(c.at, true)} · {c.field}: {c.old ?? "—"} → {c.new ?? "—"}</li>)}</ul>
              </section>
            )}
            {typeof d.fields.description === "string" && (
              <section><h3 className="font-semibold">Description (from source)</h3>
                <p className="whitespace-pre-wrap text-sm text-slate-700 dark:text-slate-300">{d.fields.description as string}</p></section>
            )}
          </div>
        )}
      </aside>
    </div>
  );
}
