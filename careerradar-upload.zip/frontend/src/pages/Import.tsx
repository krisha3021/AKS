import { useState } from "react";
import { api } from "../api";
import { ErrorBox, Spinner } from "../components/ui";

interface Preview {
  document_id: string; filename: string; headers: string[]; suggested_mapping: Record<string, string | null>;
  target_fields: string[]; sample_rows: Record<string, string | null>[]; row_count: number;
}
interface Summary {
  id: string; filename: string; total_rows: number; created_count: number; merged_count: number; failed_count: number;
  errors: { row: number; raw: Record<string, unknown>; errors: string[] }[];
}

export default function ImportPage({ onDone }: { onDone: () => void }) {
  const [preview, setPreview] = useState<Preview | null>(null);
  const [mapping, setMapping] = useState<Record<string, string | null>>({});
  const [summary, setSummary] = useState<Summary | null>(null);
  const [err, setErr] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const mappedTitle = Object.values(mapping).includes("title");

  return (
    <div className="space-y-4">
      <section className="card">
        <h2 className="font-semibold">1 · Upload a job list (CSV or XLSX)</h2>
        <p className="mb-2 text-sm text-slate-500">Rows become <strong>leads</strong>, not verified vacancies. Formulas and macros are never run. A file with columns <code>scope,title,organisation,location,url</code> imports as-is.</p>
        <input type="file" accept=".csv,.xlsx" aria-label="Job list file" disabled={busy} onChange={async (e) => {
          const f = e.target.files?.[0]; if (!f) return;
          setBusy(true); setErr(null); setSummary(null);
          try { const p = await api.upload<Preview>("/api/imports/preview", f); setPreview(p); setMapping(p.suggested_mapping); }
          catch (x) { setErr((x as Error).message); setPreview(null); } finally { setBusy(false); e.target.value = ""; }
        }} />
        {busy && <Spinner label="Reading file…" />}
        <ErrorBox error={err} />
      </section>

      {preview && !summary && (
        <section className="card overflow-x-auto">
          <h2 className="font-semibold">2 · Map columns ({preview.row_count} rows in {preview.filename})</h2>
          <table className="mt-2 min-w-full text-sm">
            <thead><tr>{preview.headers.map((h) => (
              <th key={h} className="p-1 text-left align-bottom">
                <div className="text-xs text-slate-500">{h}</div>
                <select className="input mt-1" aria-label={`Map column ${h}`} value={mapping[h] ?? ""}
                        onChange={(e) => setMapping({ ...mapping, [h]: e.target.value || null })}>
                  <option value="">— ignore —</option>
                  {preview.target_fields.map((t) => <option key={t} value={t}>{t}</option>)}
                </select>
              </th>))}</tr></thead>
            <tbody>{preview.sample_rows.map((r, i) => (
              <tr key={i} className="border-t border-slate-200 dark:border-slate-800">
                {preview.headers.map((h) => <td key={h} className="max-w-xs truncate p-1">{r[h] ?? ""}</td>)}
              </tr>))}</tbody>
          </table>
          {!mappedTitle && <p className="mt-2 text-sm text-amber-700">Map one column to <strong>title</strong> to continue.</p>}
          <button className="btn mt-3" disabled={!mappedTitle || busy} onClick={async () => {
            setBusy(true); setErr(null);
            try { setSummary(await api.post<Summary>(`/api/imports/${preview.document_id}/commit`, { mapping })); }
            catch (x) { setErr((x as Error).message); } finally { setBusy(false); }
          }}>Import {preview.row_count} rows</button>
        </section>
      )}

      {summary && (
        <section className="card">
          <h2 className="font-semibold">3 · Result</h2>
          <p className="text-sm">{summary.created_count} new · {summary.merged_count} merged into existing jobs (provenance kept) · <span className={summary.failed_count ? "text-rose-700" : ""}>{summary.failed_count} failed</span> of {summary.total_rows} rows.</p>
          <p className="text-sm text-slate-500">Imported rows are marked “Imported · not verified” until a permitted source confirms them.</p>
          {summary.errors.length > 0 && (
            <table className="mt-2 text-sm">
              <thead><tr><th className="p-1 text-left">Row</th><th className="p-1 text-left">Problem</th><th className="p-1 text-left">Original values</th></tr></thead>
              <tbody>{summary.errors.map((e) => (
                <tr key={e.row} className="border-t border-slate-200 align-top dark:border-slate-800">
                  <td className="p-1">{e.row}</td><td className="p-1">{e.errors.join("; ")}</td>
                  <td className="p-1 text-xs text-slate-500">{Object.entries(e.raw).filter(([k]) => !k.startsWith("_")).map(([k, v]) => `${k}=${v ?? ""}`).join(" · ")}</td>
                </tr>))}</tbody>
            </table>
          )}
          <button className="btn mt-3" onClick={onDone}>View jobs</button>
        </section>
      )}
    </div>
  );
}
