import { useState } from "react";
import { api } from "../api";
import type { Me } from "../types";
import { ErrorBox } from "../components/ui";

export default function SettingsPage({ me, onMe }: { me: Me; onMe: (m: Me | null) => void }) {
  const [err, setErr] = useState<string | null>(null);
  return (
    <div className="space-y-4">
      <ErrorBox error={err} />
      <section className="card">
        <h2 className="font-semibold">AI-assisted CV extraction</h2>
        <p className="text-sm text-slate-500">When on, the text of CVs you upload is sent to Anthropic's Claude API to improve field extraction. Every AI-suggested field must quote your CV verbatim or it is discarded. Rule-based extraction always runs locally regardless. Off by default.</p>
        <label className="mt-2 flex items-center gap-2 text-sm">
          <input type="checkbox" checked={me.ai_consent} onChange={async (e) => {
            try { onMe(await api.post<Me>("/api/auth/consent", { ai_consent: e.target.checked })); } catch (x) { setErr((x as Error).message); }
          }} />
          I consent to sending my CV text to the external AI provider
        </label>
      </section>
      <section className="card">
        <h2 className="font-semibold">Your data</h2>
        <p className="text-sm text-slate-500">Signed in as {me.email}. Data retention: {me.retention_days} days.</p>
        <div className="mt-2 flex flex-wrap gap-2">
          <a className="btn-ghost" href="/api/auth/export" download="careerradar-export.json">Export all my data (JSON)</a>
          <button className="btn-ghost" onClick={async () => { await api.post("/api/auth/logout"); onMe(null); }}>Sign out</button>
          <button className="btn-ghost border-rose-400 text-rose-700" onClick={async () => {
            if (prompt('This permanently deletes your account, CVs, jobs and applications. Type DELETE to confirm.') !== "DELETE") return;
            try { await api.del("/api/auth/account"); onMe(null); } catch (x) { setErr((x as Error).message); }
          }}>Delete account and all data</button>
        </div>
      </section>
    </div>
  );
}
