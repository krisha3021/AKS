import { render, screen, fireEvent, waitFor } from "@testing-library/react";
import { ScorePill, StatusBadge, DemoBadge } from "./components/ui";
import { qs } from "./api";
import ImportPage from "./pages/Import";

describe("ui", () => {
  it("score pill says relevance, not probability", () => {
    render(<ScorePill score={82} dealBreaker={false} />);
    expect(screen.getByText("82").getAttribute("title")).toMatch(/not a probability/);
  });
  it("deal-breaker is visible on the score", () => {
    render(<ScorePill score={20} dealBreaker />);
    expect(screen.getByText(/deal-breaker/)).toBeInTheDocument();
  });
  it("imported jobs are labelled unverified", () => {
    render(<StatusBadge status="imported_unverified" />);
    expect(screen.getByText("Imported · not verified")).toBeInTheDocument();
  });
  it("demo records are labelled as not real", () => {
    render(<DemoBadge />);
    expect(screen.getByText(/not a real job/)).toBeInTheDocument();
  });
  it("qs drops empty values and repeats arrays", () => {
    expect(qs({ q: "ai", scope: "", academic: false, status: ["a", "b"], min: 0 })).toBe("?q=ai&status=a&status=b&min=0");
  });
});

describe("import wizard", () => {
  it("shows mapping preview and row-level errors", async () => {
    const preview = { document_id: "d1", filename: "jobs.csv", headers: ["scope", "title", "organisation", "location", "url"],
      suggested_mapping: { scope: "scope", title: "title", organisation: "organisation", location: "location", url: "url" },
      target_fields: ["scope", "title", "organisation", "location", "url"], sample_rows: [{ title: "Lecturer" }], row_count: 2 };
    const summary = { id: "i1", filename: "jobs.csv", total_rows: 2, created_count: 1, merged_count: 0, failed_count: 1,
      errors: [{ row: 3, raw: { title: "" }, errors: ["missing required 'title'"] }] };
    const fetchMock = vi.fn()
      .mockResolvedValueOnce(new Response(JSON.stringify(preview), { headers: { "content-type": "application/json" } }))
      .mockResolvedValueOnce(new Response(JSON.stringify(summary), { headers: { "content-type": "application/json" } }));
    vi.stubGlobal("fetch", fetchMock);
    render(<ImportPage onDone={() => {}} />);
    const file = new File(["scope,title,organisation,location,url\n"], "jobs.csv", { type: "text/csv" });
    fireEvent.change(screen.getByLabelText("Job list file"), { target: { files: [file] } });
    await waitFor(() => expect(screen.getByText(/Map columns/)).toBeInTheDocument());
    fireEvent.click(screen.getByText("Import 2 rows"));
    await waitFor(() => expect(screen.getByText("missing required 'title'")).toBeInTheDocument());
    expect(fetchMock.mock.calls[1][1].headers["x-cr-csrf"]).toBe("1");
  });
});
