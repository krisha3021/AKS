import type { ReactNode } from "react";
import { STATUS_LABEL } from "../types";

export function fmtDate(s: string | null | undefined, withTime = false): string {
  if (!s) return "—";
  const d = new Date(s.endsWith("Z") || s.includes("+") ? s : s + "Z");
  return withTime ? d.toLocaleString() : d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric" });
}

/** Deadlines are stored as UTC; a date-only deadline without a timezone must not shift a day in display. */
export function fmtDeadline(s: string | null | undefined): string {
  if (!s) return "Not stated";
  const d = new Date(s.endsWith("Z") || s.includes("+") ? s : s + "Z");
  return d.toLocaleDateString(undefined, { day: "numeric", month: "short", year: "numeric", timeZone: "UTC" });
}

export function ago(s: string | null | undefined): string {
  if (!s) return "never";
  const d = new Date(s.endsWith("Z") ? s : s + "Z").getTime();
  const m = Math.round((Date.now() - d) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  if (m < 1440) return `${Math.round(m / 60)} h ago`;
  return `${Math.round(m / 1440)} d ago`;
}

const STATUS_COLOR: Record<string, string> = {
  open_verified: "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-300",
  imported_unverified: "bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
  verification_unavailable: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  stale: "bg-amber-100 text-amber-800 dark:bg-amber-900/40 dark:text-amber-300",
  deadline_passed: "bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300",
  closed_explicit: "bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300",
  removed: "bg-rose-100 text-rose-800 dark:bg-rose-900/40 dark:text-rose-300",
};

export function StatusBadge({ status }: { status: string }) {
  return <span className={`badge ${STATUS_COLOR[status] ?? ""}`}>{STATUS_LABEL[status] ?? status}</span>;
}

export function DemoBadge() {
  return <span className="badge bg-fuchsia-100 text-fuchsia-800 dark:bg-fuchsia-900/40 dark:text-fuchsia-300"
               title="Synthetic demo record — not a real vacancy">DEMO · not a real job</span>;
}

export function ScorePill({ score, dealBreaker }: { score: number | null; dealBreaker: boolean }) {
  if (score === null) return <span className="badge bg-slate-100 dark:bg-slate-800">no score</span>;
  const c = dealBreaker ? "bg-rose-600" : score >= 70 ? "bg-emerald-600" : score >= 45 ? "bg-amber-500" : "bg-slate-500";
  return (
    <span className={`badge ${c} text-white`} title="Relevance to your profile — not a probability of selection">
      {Math.round(score)}{dealBreaker ? " · deal-breaker" : ""}
    </span>
  );
}

const REQ_STYLE: Record<string, string> = {
  supported: "text-emerald-700 dark:text-emerald-400",
  not_supported: "text-rose-700 dark:text-rose-400",
  unknown: "text-amber-700 dark:text-amber-400",
};
const REQ_ICON: Record<string, string> = { supported: "✓", not_supported: "✗", unknown: "?" };
export function ReqStatus({ status }: { status: string }) {
  return <span className={`font-semibold ${REQ_STYLE[status]}`} aria-label={status.replace("_", " ")}>
    {REQ_ICON[status]} {status.replace("_", " ")}</span>;
}

export function Empty({ title, children }: { title: string; children?: ReactNode }) {
  return (
    <div className="card text-center">
      <p className="font-medium">{title}</p>
      {children && <div className="mt-2 text-sm text-slate-500">{children}</div>}
    </div>
  );
}

export function ErrorBox({ error }: { error: string | null }) {
  if (!error) return null;
  return <div role="alert" className="rounded-md border border-rose-300 bg-rose-50 p-3 text-sm text-rose-800 dark:border-rose-800 dark:bg-rose-950 dark:text-rose-200">{error}</div>;
}

export function Spinner({ label = "Loading…" }: { label?: string }) {
  return <p className="animate-pulse text-sm text-slate-500" role="status">{label}</p>;
}

export function ListInput({ label, value, onChange, placeholder }:
  { label: string; value: string[]; onChange: (v: string[]) => void; placeholder?: string }) {
  return (
    <label className="block">
      <span className="label">{label}</span>
      <input className="input" defaultValue={value.join(", ")} placeholder={placeholder ?? "comma-separated"}
             onBlur={(e) => onChange(e.target.value.split(",").map((s) => s.trim()).filter(Boolean))} />
    </label>
  );
}
