# CareerRadar

CareerRadar finds, verifies, ranks and tracks national and international jobs (India, the Gulf and elsewhere; academic and industry) against your CV. It tells you where each listing came from and how fresh it is.

## What works today (tested)
- **Accounts and privacy:** sign-up and sign-in, separate data per user, data export, account deletion, retention clean-up, and opt-in consent before any CV text goes to an AI service.
- **CV upload (PDF/DOCX):** each extracted fact links to the CV text it came from, with a confidence level. You can confirm or correct it. Overlapping jobs are counted once, and unclear dates are flagged.
- **Spreadsheet import (CSV/XLSX):** a file with columns `scope,title,organisation,location,url` imports as-is. You get a column-mapping preview and an error message for each bad row; the good rows still import. Duplicates are merged and every source record is kept. Imported rows are **never** marked open or verified.
- **Matching and search:** search with every filter in the spec, plus scores you can check. Each requirement is shown as supported, not supported or unknown, quoting both the CV and the vacancy. Deal-breakers are shown clearly. Visa sponsorship stays "unknown" when the listing doesn't mention it.
- **Live sources:** official APIs for Greenhouse and Lever employer boards, RSS/Atom feeds, Adzuna (once you add keys), and a checker for single vacancy pages. A temporary outage never closes a job. Changed deadlines, closures and removals trigger alerts.
- **Live dashboard:** new and changed jobs, source health and alerts appear as soon as they're processed (via Server-Sent Events, with automatic reconnect). Upstream sources refresh on their own schedules, which are shown in the app.
- **Applications:** an 8-stage board, notes, reminders and document checklists. Draft emails and letters use only facts from your CV, and gaps are marked in [brackets] rather than invented. **CareerRadar never sends or submits anything.**

## Not done or not verified
- The Docker setup is written but **untested** (Docker isn't installed on the dev machine). The Playwright end-to-end test is written but **hasn't been run** (it needs a browser download).
- The live connectors were tested only against mocked responses; none has been run against a real job board yet.
- Naukri, LinkedIn, Naukrigulf, Bayt, GulfTalent, Nature Careers, EURAXESS and others are **manual import only**; see why in [docs/A-research.md](docs/A-research.md).
- Quality figures in [docs/H-evaluation.md](docs/H-evaluation.md) come from a small synthetic set and are not a claim about accuracy on real data.

## Documents
| | |
|---|---|
| A. Research and source-access matrix | [docs/A-research.md](docs/A-research.md) |
| B–C. Requirements, assumptions, architecture | [docs/B-C-requirements-architecture.md](docs/B-C-requirements-architecture.md) |
| D–F. Schema, API contract, UX flows | [docs/D-E-F-schema-api-ux.md](docs/D-E-F-schema-api-ux.md), [docs/E-openapi.json](docs/E-openapi.json) |
| H. Measured evaluation | [docs/H-evaluation.md](docs/H-evaluation.md) |
| I–K. Setup, deployment, limitations, security, runbook, roadmap | [docs/I-J-K-operations.md](docs/I-J-K-operations.md) |

## Quick start
Local development: see [docs/I-J-K-operations.md](docs/I-J-K-operations.md#i-setup). **Publishing on GitHub + Cloudflare (free, permanent workers.dev address): see [DEPLOY.md](DEPLOY.md).**

## Repository layout
```
backend/
  app/            FastAPI app: routers/, cv/ (extraction), connectors/, matching.py, jobstore.py,
                  verify.py, pipeline.py (task handlers), tasks.py (queue), net.py (SSRF-safe HTTP)
  migrations/     Alembic
  scripts/        seed_demo.py (SYNTHETIC demo), evaluate.py (metrics report)
  tests/          pytest suite (+ fixtures/)
frontend/         Vite + React + TypeScript + Tailwind SPA, vitest, Playwright e2e/
docs/             deliverables A–K
docker-compose.yml, .env.example
```
