/**
 * CareerRadar public front door (Cloudflare Workers, free plan).
 *
 * https://careerradar.<your-subdomain>.workers.dev  →  this Worker  →  Workers VPC service
 *   →  Cloudflare Tunnel (cloudflared on your PC)  →  http://127.0.0.1:8000 (CareerRadar)
 *
 * The app itself runs on your PC (deploy/start-public.ps1 -NoTunnel). This Worker holds no data.
 */
interface Env {
  CAREERRADAR_APP: Fetcher; // vpc_services binding (wrangler.jsonc)
}

// Must match the VPC service created with:  --ipv4 127.0.0.1 --http-port 8000
const ORIGIN = "http://127.0.0.1:8000";

const OFFLINE_PAGE = `<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>CareerRadar is offline</title>
<style>body{font-family:system-ui,sans-serif;max-width:32rem;margin:4rem auto;padding:0 1rem;line-height:1.5}</style>
</head><body><h1>CareerRadar is offline right now</h1>
<p>The server that hosts CareerRadar isn't reachable at the moment. Please try again later.</p>
</body></html>`;

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    const target = new URL(url.pathname + url.search, ORIGIN);

    const headers = new Headers(request.headers);
    // Visitor IP for per-visitor rate limits. Overwrite anything the client sent.
    headers.set("x-cr-client-ip", request.headers.get("cf-connecting-ip") ?? "");
    headers.delete("host");

    // duplex "half" is required by the Fetch spec for streamed request bodies (uploads).
    const init: RequestInit & { duplex?: "half" } = { method: request.method, headers, redirect: "manual" };
    if (request.method !== "GET" && request.method !== "HEAD") {
      init.body = request.body;
      init.duplex = "half";
    }

    try {
      return await env.CAREERRADAR_APP.fetch(new Request(target, init));
    } catch (err) {
      console.error("CareerRadar origin unreachable:", err instanceof Error ? err.message : String(err));
      return new Response(OFFLINE_PAGE, {
        status: 503,
        headers: { "content-type": "text/html; charset=utf-8", "retry-after": "60" },
      });
    }
  },
} satisfies ExportedHandler<Env>;
