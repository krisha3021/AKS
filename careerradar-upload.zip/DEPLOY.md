# Deploying CareerRadar: GitHub + Cloudflare (free)

**Result:** CareerRadar at a permanent address, `https://careerradar.<your-subdomain>.workers.dev` (for your account: `https://careerradar.shubhalok30.workers.dev`).

**How it works:**
```
Visitor ──HTTPS──▶ Cloudflare Worker "careerradar" (free) ──Workers VPC──▶ Cloudflare Tunnel
        ──▶ cloudflared on your PC ──▶ CareerRadar at http://127.0.0.1:8000 (your PC)
```
- **Free:** Workers Free plan, Cloudflare Tunnel, and Workers VPC (beta, free on all plans).
- **The app and its data stay on your PC.** The site is online while the PC is on and CareerRadar is running. When it isn't, visitors see an "offline" page.
- **Dashboard updates every minute.** Live push updates are turned off in this mode.
- Your existing `aks.shubhalok30.workers.dev` (OmniConvert) is **not touched**.

> Workers VPC is in beta, so Cloudflare may change it. If a dashboard label below looks slightly different, look for the closest match; the commands are exact.

---

## Part A: Put all the files on GitHub (one time)

1. Go to https://github.com and click **+ → New repository**.
   - Name: `careerradar`
   - Visibility: **Private** (recommended)
   - **Do not** tick "Add a README", ".gitignore" or "license". The repository must start empty.
   - Click **Create repository**.
2. Open **PowerShell** and run (replace `YOUR-USERNAME`):
   ```powershell
   cd C:\Users\hp\Downloads\BCI\CareerRadar
   git remote add origin https://github.com/YOUR-USERNAME/careerradar.git
   git push -u origin main
   ```
   A GitHub sign-in window opens the first time. Approve it.
3. Refresh the GitHub page. You should see `backend/`, `frontend/`, `src/`, `deploy/`, `docs/`, `wrangler.jsonc`, `README.md` and `DEPLOY.md`.

Why `git push` and not drag-and-drop: the project has more than 100 files, and GitHub's browser upload accepts at most 100 at a time. It also keeps the folder structure and history intact.

**Never uploaded** (git-ignored): `deploy\.env.public` (your secrets), `backend\data\` (database, encrypted CVs, logs), `.venv`, `node_modules`. The repository was scanned and contains no keys or passwords.

---

## Part B: Publish on Cloudflare

### B1. Start CareerRadar on your PC
```powershell
cd C:\Users\hp\Downloads\BCI\CareerRadar
powershell -ExecutionPolicy Bypass -File deploy\start-public.ps1 -NoTunnel
```
Wait for `Server is up on http://127.0.0.1:8000` and **leave this window open**.
The first run creates `deploy\.env.public` (encryption key + operator secret). **Back it up** (password manager or USB stick): without it, stored CVs can't be decrypted.

### B2. Create the tunnel (Cloudflare dashboard)
1. Log in at https://dash.cloudflare.com.
2. In the dashboard search box type **Workers VPC** and open it. Go to the **Tunnels** tab and click **Create**.
3. Name it `careerradar` and click **Save tunnel**.
4. Choose **Windows** and **64-bit**. The dashboard shows install commands, including one with your unique token.
5. Open **PowerShell as Administrator** (Start menu → right-click PowerShell → *Run as administrator*) and run the commands **exactly as the dashboard shows them**. This installs `cloudflared` as a Windows service that starts automatically with Windows.
6. Wait until the dashboard shows the tunnel as **Connected / Healthy**.
7. Copy the **Tunnel ID** (looks like `a1b2c3d4-…`).

### B3. Create the VPC service (one command)
In a normal PowerShell window:
```powershell
cd C:\Users\hp\Downloads\BCI\CareerRadar
npm ci
npx wrangler login
```
Approve the browser page that opens. Then run (paste your Tunnel ID):
```powershell
npx wrangler vpc service create careerradar-app --type http --tunnel-id PASTE-TUNNEL-ID-HERE --ipv4 127.0.0.1 --http-port 8000
```
Copy the **service ID** it prints.

### B4. Put the service ID in `wrangler.jsonc` and deploy
1. Open `wrangler.jsonc` in Notepad and replace `REPLACE_WITH_VPC_SERVICE_ID` with the service ID. Keep the quotes. Save.
2. Deploy:
   ```powershell
   npm run deploy
   ```
   It refuses to run if the placeholder is still there. When it finishes it prints `https://careerradar.shubhalok30.workers.dev`.
3. Open that address, click **Create an account**, and you're live.

### B5. Save the change to GitHub
```powershell
git add wrangler.jsonc
git commit -m "Set Workers VPC service ID"
git push
```
(The service ID isn't secret; it only works inside your Cloudflare account.)

### B6. Optional: start CareerRadar automatically when you log in
```powershell
schtasks /Create /TN "CareerRadar" /SC ONLOGON /RL LIMITED /TR "powershell -ExecutionPolicy Bypass -WindowStyle Hidden -File C:\Users\hp\Downloads\BCI\CareerRadar\deploy\start-public.ps1 -NoTunnel"
```
To remove it: `schtasks /Delete /TN "CareerRadar" /F`. The tunnel already starts with Windows (step B2).
Also set **Settings → System → Power → "put my device to sleep" → Never** while hosting.

---

## Updating later
- **App changes:** commit and `git push`, then restart B1 (Ctrl+C, run it again).
- **Worker changes** (`src/index.ts`, `wrangler.jsonc`): `npm run deploy`, then `git push`.

## Troubleshooting
| What you see | Fix |
|---|---|
| "CareerRadar is offline right now" | Is the B1 window running? Is the tunnel connected (dashboard, or **services.msc → Cloudflared** = Running)? |
| `npm run deploy` says to replace `REPLACE_WITH_VPC_SERVICE_ID` | Do B4 step 1 |
| `wrangler` says you aren't logged in | `npx wrangler login` |
| `Backend environment missing` | `cd backend; uv sync` |
| `Port 8000 is already in use` | Close the other server. The VPC service points at port 8000, so keep using 8000 |
| Sign-in doesn't stick | Use the `https://…workers.dev` address. Sign-in needs HTTPS in this mode |
| Server error details | `backend\data\public-server.log.err` |

## Moving to another PC
`git clone` the repo, run `cd backend; uv sync` and `cd ..; npm ci`, then copy **together** `deploy\.env.public`, `backend\data\public.db` and `backend\data\public-files\` from the old PC. Then run B1 and B2 (a new tunnel token). If the tunnel ID changes, also redo B3–B4.

## Alternative without a Cloudflare account setup
`powershell -ExecutionPolicy Bypass -File deploy\start-public.ps1` (no `-NoTunnel`) starts a temporary `https://….trycloudflare.com` address after `winget install --id Cloudflare.cloudflared --exact`. The address changes every run; testing only.
