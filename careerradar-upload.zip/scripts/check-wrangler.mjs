// Fails fast if wrangler.jsonc still contains the placeholder VPC service ID.
import { readFileSync } from "node:fs";
const cfg = readFileSync(new URL("../wrangler.jsonc", import.meta.url), "utf8");
if (cfg.includes("REPLACE_WITH_VPC_SERVICE_ID")) {
  console.error("wrangler.jsonc: replace REPLACE_WITH_VPC_SERVICE_ID with your VPC service ID (see DEPLOY.md, step B3).");
  process.exit(1);
}
console.log("wrangler.jsonc: VPC service ID set.");
