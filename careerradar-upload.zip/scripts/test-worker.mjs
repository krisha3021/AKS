// Exercises src/index.ts with a stand-in VPC binding that forwards to a real local CareerRadar.
// Usage: node scripts/test-worker.mjs http://127.0.0.1:8010
import assert from "node:assert/strict";
import worker from "../src/index.ts";

const backend = process.argv[2] ?? "http://127.0.0.1:8010";
const seen = [];
const env = {
  CAREERRADAR_APP: {
    fetch: async (req) => {
      const u = new URL(req.url);
      assert.equal(u.origin, "http://127.0.0.1:8000"); // Worker targets the VPC service origin
      seen.push(req.headers.get("x-cr-client-ip"));
      const body = ["GET", "HEAD"].includes(req.method) ? undefined : await req.arrayBuffer();
      return fetch(backend + u.pathname + u.search, { method: req.method, headers: req.headers, body, redirect: "manual" });
    },
  },
};
const edge = (path, init = {}) =>
  worker.fetch(new Request("https://careerradar.example.workers.dev" + path, {
    ...init, headers: { "cf-connecting-ip": "203.0.113.50", ...(init.headers ?? {}) },
  }), env);

let r = await edge("/");
assert.equal(r.status, 200);
assert.match(await r.text(), /CareerRadar/);
console.log("ok  GET / serves the app");

r = await edge("/api/health/ready");
assert.deepEqual(await r.json(), { status: "ok", database: "ok" });
console.log("ok  API reachable through the Worker");

const email = `worker-test-${Date.now()}@careerradar.test`;
r = await edge("/api/auth/register", {
  method: "POST",
  headers: { "content-type": "application/json", "x-cr-csrf": "1", "x-cr-client-ip": "6.6.6.6" },
  body: JSON.stringify({ email, password: "worker-test-password-1" }),
});
assert.equal(r.status, 200, await r.clone().text());
const cookie = r.headers.get("set-cookie");
assert.match(cookie, /cr_session=.*HttpOnly.*Secure/i);
console.log("ok  POST body forwarded, Secure session cookie passed back");
assert.equal(seen.at(-1), "203.0.113.50");
console.log("ok  visitor IP forwarded; spoofed x-cr-client-ip overwritten");

const session = cookie.split(";")[0];
r = await edge("/api/auth/me", { headers: { cookie: session } });
assert.equal((await r.json()).email, email);
r = await edge("/api/auth/account", { method: "DELETE", headers: { cookie: session, "x-cr-csrf": "1" } });
assert.equal((await r.json()).deleted, true);
console.log("ok  signed-in requests work; test account deleted");

const offline = await worker.fetch(new Request("https://x.workers.dev/"), {
  CAREERRADAR_APP: { fetch: async () => { throw new Error("tunnel down"); } },
});
assert.equal(offline.status, 503);
assert.match(await offline.text(), /offline/);
console.log("ok  friendly 503 page when the PC/tunnel is offline");
console.log("ALL WORKER CHECKS PASSED");
